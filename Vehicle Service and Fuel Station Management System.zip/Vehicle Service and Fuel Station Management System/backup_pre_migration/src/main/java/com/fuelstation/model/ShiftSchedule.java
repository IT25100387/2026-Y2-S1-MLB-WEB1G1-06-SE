package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class ShiftSchedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long staffId;
    private String staffName;
    
    private LocalDate shiftDate;
    private String shiftTiming; // e.g. Morning (08:00 - 16:00), Evening (16:00 - 00:00)
    private String station; // e.g. Service Bay A
    private String status; // Scheduled, Completed, Cancelled
}
