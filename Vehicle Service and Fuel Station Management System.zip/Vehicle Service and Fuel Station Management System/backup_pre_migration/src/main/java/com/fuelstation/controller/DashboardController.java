package com.fuelstation.controller;

import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelPump;
import com.fuelstation.model.FuelSale;
import com.fuelstation.model.FuelPrice;
import com.fuelstation.repository.*;
import com.fuelstation.service.FuelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import java.util.UUID;

@Controller
public class DashboardController {

    @Autowired
    private FuelPumpRepository pumpRepository;
    @Autowired
    private FuelInventoryRepository inventoryRepository;
    @Autowired
    private FuelSaleRepository saleRepository;
    @Autowired
    private SparePartRepository partRepository;
    @Autowired
    private SupplierRepository supplierRepository;
    @Autowired
    private FuelPriceRepository priceRepository;
    @Autowired
    private FuelService fuelService;
    @Autowired
    private VehicleRepository vehicleRepository;
    @Autowired
    private ServiceBookingRepository bookingRepository;
    @Autowired
    private NotificationRepository notificationRepository;
    @Autowired
    private InvoiceRepository invoiceRepository;
    @Autowired
    private PaymentRecordRepository paymentRecordRepository;
    
    // HR Repositories
    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private ShiftScheduleRepository shiftRepository;
    @Autowired
    private AttendanceRecordRepository attendanceRepository;
    @Autowired
    private LeaveRequestRepository leaveRepository;
    
    // Member 1 & 3 Repositories
    @Autowired
    private AppUserRepository userRepository;
    @Autowired
    private ServiceBayRepository bayRepository;
    @Autowired
    private JobCardRepository jobCardRepository;
    @Autowired
    private CustomerFeedbackRepository feedbackRepository;
    
    @Autowired
    private jakarta.servlet.http.HttpSession session;

    @GetMapping("/")
    public String dashboard(Model model) {
        List<FuelSale> allSales = saleRepository.findAll();
        double totalRevenue = allSales.stream().mapToDouble(FuelSale::getTotalAmount).sum();
        long pendingBookings = bookingRepository.findAll().stream().filter(b -> "Pending".equals(b.getStatus())).count();
        long completedBookings = bookingRepository.findAll().stream().filter(b -> "Completed".equals(b.getStatus())).count();
        long pendingLeaves = leaveRepository.findAll().stream().filter(l -> "Pending".equals(l.getStatus())).count();
        
        model.addAttribute("pumpsCount", pumpRepository.count());
        model.addAttribute("sales", allSales);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("pendingBookings", pendingBookings);
        model.addAttribute("completedBookings", completedBookings);
        model.addAttribute("pendingLeaves", pendingLeaves);
        model.addAttribute("inventories", inventoryRepository.findAll());
        return "index";
    }

    // --- PUMPS ---
    @GetMapping("/pumps")
    public String pumps(Model model) {
        model.addAttribute("pumps", pumpRepository.findAll());
        model.addAttribute("newPump", new FuelPump());
        return "pumps";
    }
    
    @PostMapping("/pumps/add")
    public String addPump(@ModelAttribute FuelPump pump) {
        pumpRepository.save(pump);
        return "redirect:/pumps";
    }

    // --- INVENTORY ---
    @GetMapping("/inventory")
    public String inventory(Model model) {
        model.addAttribute("inventories", inventoryRepository.findAll());
        model.addAttribute("newInventory", new FuelInventory());
        return "inventory";
    }

    @PostMapping("/inventory/add")
    public String addInventory(@ModelAttribute FuelInventory inv) {
        inventoryRepository.save(inv);
        return "redirect:/inventory";
    }

    // --- SALES ---
    @GetMapping("/sales")
    public String sales(Model model) {
        model.addAttribute("sales", saleRepository.findAll());
        model.addAttribute("newSale", new FuelSale());
        model.addAttribute("pumps", pumpRepository.findAll());
        model.addAttribute("prices", priceRepository.findAll());
        return "sales";
    }

    @PostMapping("/sales/add")
    public String addSale(@ModelAttribute FuelSale sale) {
        sale.setReceiptNumber("REC-" + UUID.randomUUID().toString().substring(0,8).toUpperCase());
        fuelService.recordSale(sale);
        return "redirect:/sales";
    }
    
    // --- PRICES ---
    @GetMapping("/prices")
    public String prices(Model model) {
        model.addAttribute("prices", priceRepository.findAll());
        return "prices";
    }
    
    // Setup some dummy data if needed
    @GetMapping("/setup")
    @ResponseBody
    public String setupData() {
        if(inventoryRepository.count() == 0) {
            FuelInventory i1 = new FuelInventory();
            i1.setFuelType("Lanka Petrol 92");
            i1.setCurrentStockLitres(5000.0);
            i1.setMaxCapacityLitres(10000.0);
            i1.setMinStockWarning(1000.0);
            i1.setStatus("Normal");
            inventoryRepository.save(i1);
            
            FuelPrice p1 = new FuelPrice();
            p1.setFuelType("Lanka Petrol 92");
            p1.setCurrentPrice(340.0);
            p1.setPreviousPrice(350.0);
            p1.setLastUpdated(LocalDateTime.now());
            priceRepository.save(p1);
            
            FuelPump pump1 = new FuelPump();
            pump1.setPumpName("Pump 1");
            pump1.setFuelType("Lanka Petrol 92");
            pump1.setStatus("Active");
            pumpRepository.save(pump1);
            
            return "Setup complete";
        }
        return "Already setup";
    }

    // --- DELETE MAPPINGS ---
    @PostMapping("/inventory/delete/{id}")
    public String deleteInventory(@PathVariable Long id) {
        inventoryRepository.deleteById(id);
        return "redirect:/inventory";
    }

    @PostMapping("/pumps/delete/{id}")
    public String deletePump(@PathVariable Long id) {
        pumpRepository.deleteById(id);
        return "redirect:/pumps";
    }

    // --- SPARE PARTS ---
    @GetMapping("/spare-parts")
    public String spareParts(Model model) {
        model.addAttribute("parts", partRepository.findAll());
        model.addAttribute("newPart", new com.fuelstation.model.SparePart());
        return "spare_parts";
    }
    
    @PostMapping("/spare-parts/add")
    public String addSparePart(@ModelAttribute com.fuelstation.model.SparePart part) {
        partRepository.save(part);
        return "redirect:/spare-parts";
    }
    
    @PostMapping("/spare-parts/delete/{id}")
    public String deleteSparePart(@PathVariable Long id) {
        partRepository.deleteById(id);
        return "redirect:/spare-parts";
    }

    // --- SUPPLIERS ---
    @GetMapping("/suppliers")
    public String suppliers(Model model) {
        model.addAttribute("suppliers", supplierRepository.findAll());
        model.addAttribute("newSupplier", new com.fuelstation.model.Supplier());
        return "suppliers";
    }
    
    @PostMapping("/suppliers/add")
    public String addSupplier(@ModelAttribute com.fuelstation.model.Supplier supplier) {
        supplierRepository.save(supplier);
        return "redirect:/suppliers";
    }
    
    @PostMapping("/suppliers/delete/{id}")
    public String deleteSupplier(@PathVariable Long id) {
        supplierRepository.deleteById(id);
        return "redirect:/suppliers";
    }

    // --- SETTINGS ---
    @GetMapping("/settings")
    public String settings() {
        return "settings";
    }

    // --- VEHICLES ---
    @GetMapping("/vehicles")
    public String vehicles(Model model) {
        model.addAttribute("vehicles", vehicleRepository.findAll());
        model.addAttribute("newVehicle", new com.fuelstation.model.Vehicle());
        return "vehicles";
    }
    
    @PostMapping("/vehicles/add")
    public String addVehicle(@ModelAttribute com.fuelstation.model.Vehicle vehicle) {
        if(vehicle.getRegisteredDate() == null || vehicle.getRegisteredDate().isEmpty()) {
            vehicle.setRegisteredDate(java.time.LocalDate.now().toString());
        }
        vehicleRepository.save(vehicle);
        return "redirect:/vehicles";
    }
    
    @PostMapping("/vehicles/delete/{id}")
    public String deleteVehicle(@PathVariable Long id) {
        vehicleRepository.deleteById(id);
        return "redirect:/vehicles";
    }

    // --- SERVICE BOOKINGS ---
    @GetMapping("/bookings")
    public String bookings(Model model, @RequestParam(required = false) String error) {
        model.addAttribute("bookings", bookingRepository.findAll());
        model.addAttribute("newBooking", new com.fuelstation.model.ServiceBooking());
        model.addAttribute("vehicles", vehicleRepository.findAll());
        if (error != null) {
            model.addAttribute("errorMessage", "That time slot is already booked! Please select a different time.");
        }
        return "bookings";
    }
    
    @PostMapping("/bookings/add")
    public String addBooking(@ModelAttribute com.fuelstation.model.ServiceBooking booking) {
        // Business Rule: No double booking
        boolean isBooked = bookingRepository.existsByServiceDateAndTimeSlotAndStatusNot(
                booking.getServiceDate(), booking.getTimeSlot(), "Cancelled");
                
        if (isBooked) {
            return "redirect:/bookings?error=double_booking";
        }
        
        if(booking.getStatus() == null || booking.getStatus().isEmpty()) {
            booking.setStatus("Pending");
        }
        com.fuelstation.model.ServiceBooking saved = bookingRepository.save(booking);
        
        // Automated Notification
        com.fuelstation.model.Notification notif = new com.fuelstation.model.Notification();
        notif.setTitle("Booking Confirmed");
        notif.setMessage("Service booked for " + saved.getCustomerName() + " (Vehicle: " + saved.getLicensePlate() + ") on " + saved.getServiceDate() + " at " + saved.getTimeSlot());
        notif.setType("Booking");
        notif.setStatus("Unread");
        notif.setCreatedDate(LocalDateTime.now());
        notificationRepository.save(notif);
        
        // Advance Payment Logic for Major Services
        if ("Full Service".equalsIgnoreCase(saved.getServiceType()) || "Repair".equalsIgnoreCase(saved.getServiceType())) {
            com.fuelstation.model.Invoice inv = new com.fuelstation.model.Invoice();
            inv.setInvoiceNo("INV-" + UUID.randomUUID().toString().substring(0,6).toUpperCase());
            inv.setInvoiceName("Advance Payment: " + saved.getServiceType());
            inv.setReferenceNo("BKG-" + saved.getId());
            inv.setCustomerName(saved.getCustomerName());
            inv.setInvoiceDate(java.time.LocalDate.now());
            inv.setDueDate(saved.getServiceDate());
            inv.setGrossTotalAmount(5000.0); // Predefined advance
            inv.setConvenienceFee(0.0);
            inv.setNetTotal(5000.0);
            inv.setAmountPaid(0.0);
            inv.setStatus("OVERDUE"); // Needs immediate payment
            invoiceRepository.save(inv);
        }
        
        return "redirect:/bookings";
    }
    
    @PostMapping("/bookings/delete/{id}")
    public String deleteBooking(@PathVariable Long id) {
        bookingRepository.deleteById(id);
        return "redirect:/bookings";
    }

    @PostMapping("/bookings/cancel/{id}")
    public String cancelBooking(@PathVariable Long id) {
        com.fuelstation.model.ServiceBooking booking = bookingRepository.findById(id).orElse(null);
        if(booking != null) {
            booking.setStatus("Cancelled");
            bookingRepository.save(booking);
            
            // Automated Notification
            com.fuelstation.model.Notification notif = new com.fuelstation.model.Notification();
            notif.setTitle("Booking Cancelled");
            notif.setMessage("The service booking for vehicle " + booking.getLicensePlate() + " on " + booking.getServiceDate() + " has been cancelled.");
            notif.setType("Alert");
            notif.setStatus("Unread");
            notif.setCreatedDate(LocalDateTime.now());
            notificationRepository.save(notif);
        }
        return "redirect:/bookings";
    }

    // --- SERVICE HISTORY ---
    @GetMapping("/service-history")
    public String serviceHistory(Model model, @RequestParam(required = false) String licensePlate) {
        if (licensePlate != null && !licensePlate.isEmpty()) {
            model.addAttribute("history", bookingRepository.findByLicensePlateOrderByServiceDateDesc(licensePlate));
            model.addAttribute("searchedPlate", licensePlate);
        }
        return "service_history";
    }

    // --- NOTIFICATIONS ---
    @GetMapping("/notifications")
    public String notifications(Model model) {
        model.addAttribute("notifications", notificationRepository.findAllByOrderByCreatedDateDesc());
        return "notifications";
    }
    
    @PostMapping("/notifications/read/{id}")
    public String markNotificationRead(@PathVariable Long id) {
        com.fuelstation.model.Notification notif = notificationRepository.findById(id).orElse(null);
        if(notif != null) {
            notif.setStatus("Read");
            notificationRepository.save(notif);
        }
        return "redirect:/notifications";
    }

    @PostMapping("/notifications/delete/{id}")
    public String deleteNotification(@PathVariable Long id) {
        notificationRepository.deleteById(id);
        return "redirect:/notifications";
    }

    // --- REPORTS ---
    @GetMapping("/reports")
    public String reports(Model model) {
        model.addAttribute("sales", saleRepository.findAll());
        model.addAttribute("inventories", inventoryRepository.findAll());
        model.addAttribute("bookings", bookingRepository.findAll());
        return "reports";
    }

    // --- BILLING & INVOICES (Member 5) ---
    @GetMapping("/invoices")
    public String invoices(Model model) {
        model.addAttribute("invoices", invoiceRepository.findAll());
        model.addAttribute("newPayment", new com.fuelstation.model.PaymentRecord());
        return "invoices";
    }
    
    @PostMapping("/invoices/pay")
    public String processPayment(@ModelAttribute com.fuelstation.model.PaymentRecord payment) {
        if(payment.getPaymentDate() == null) {
            payment.setPaymentDate(java.time.LocalDate.now());
        }
        paymentRecordRepository.save(payment);
        
        // Update Invoice status (Split Payment logic)
        com.fuelstation.model.Invoice inv = invoiceRepository.findById(payment.getInvoiceId()).orElse(null);
        if (inv != null) {
            double newAmountPaid = (inv.getAmountPaid() != null ? inv.getAmountPaid() : 0.0) + payment.getAmount();
            inv.setAmountPaid(newAmountPaid);
            
            if (newAmountPaid >= inv.getNetTotal()) {
                inv.setStatus("PAID");
            } else {
                inv.setStatus("PARTIAL");
            }
            invoiceRepository.save(inv);
        }
        
        return "redirect:/invoices";
    }

    // --- HR & STAFFING (Member 6) ---
    @GetMapping("/staff")
    public String staff(Model model) {
        model.addAttribute("staffList", staffRepository.findAll());
        model.addAttribute("newStaff", new com.fuelstation.model.Staff());
        return "staff";
    }
    
    @PostMapping("/staff/add")
    public String addStaff(@ModelAttribute com.fuelstation.model.Staff staff) {
        if(staff.getEmploymentStatus() == null) {
            staff.setEmploymentStatus("Active");
        }
        staffRepository.save(staff);
        return "redirect:/staff";
    }
    
    @PostMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id) {
        com.fuelstation.model.Staff staff = staffRepository.findById(id).orElse(null);
        if(staff != null) {
            staff.setEmploymentStatus("Inactive"); // Soft delete
            staffRepository.save(staff);
        }
        return "redirect:/staff";
    }

    @GetMapping("/shifts")
    public String shifts(Model model) {
        model.addAttribute("shifts", shiftRepository.findAll());
        model.addAttribute("newShift", new com.fuelstation.model.ShiftSchedule());
        model.addAttribute("staffList", staffRepository.findAll());
        model.addAttribute("attendances", attendanceRepository.findAll());
        return "shifts";
    }

    @PostMapping("/shifts/add")
    public String addShift(@ModelAttribute com.fuelstation.model.ShiftSchedule shift) {
        if(shift.getStatus() == null) shift.setStatus("Scheduled");
        com.fuelstation.model.Staff staff = staffRepository.findById(shift.getStaffId()).orElse(null);
        if(staff != null) shift.setStaffName(staff.getName());
        shiftRepository.save(shift);
        return "redirect:/shifts";
    }
    
    @PostMapping("/shifts/delete/{id}")
    public String deleteShift(@PathVariable Long id) {
        shiftRepository.deleteById(id);
        return "redirect:/shifts";
    }

    @PostMapping("/attendance/clockin/{staffId}")
    public String clockIn(@PathVariable Long staffId) {
        com.fuelstation.model.Staff staff = staffRepository.findById(staffId).orElse(null);
        if(staff != null) {
            com.fuelstation.model.AttendanceRecord record = new com.fuelstation.model.AttendanceRecord();
            record.setStaffId(staff.getId());
            record.setStaffName(staff.getName());
            record.setAttendanceDate(java.time.LocalDate.now());
            record.setClockInTime(java.time.LocalTime.now());
            record.setStatus("Present");
            attendanceRepository.save(record);
        }
        return "redirect:/shifts";
    }

    @GetMapping("/leave")
    public String leave(Model model) {
        model.addAttribute("leaves", leaveRepository.findAll());
        model.addAttribute("newLeave", new com.fuelstation.model.LeaveRequest());
        model.addAttribute("staffList", staffRepository.findAll());
        return "leave";
    }
    
    @PostMapping("/leave/add")
    public String addLeave(@ModelAttribute com.fuelstation.model.LeaveRequest leave) {
        leave.setStatus("Pending");
        com.fuelstation.model.Staff staff = staffRepository.findById(leave.getStaffId()).orElse(null);
        if(staff != null) leave.setStaffName(staff.getName());
        leaveRepository.save(leave);
        return "redirect:/leave";
    }
    
    @PostMapping("/leave/action/{id}")
    public String leaveAction(@PathVariable Long id, @RequestParam String action) {
        com.fuelstation.model.LeaveRequest leave = leaveRepository.findById(id).orElse(null);
        if(leave != null) {
            leave.setStatus(action);
            leaveRepository.save(leave);
            
            // Notification
            com.fuelstation.model.Notification notif = new com.fuelstation.model.Notification();
            notif.setTitle("Leave " + action);
            notif.setMessage("Leave request for " + leave.getStaffName() + " has been " + action + ".");
            notif.setType("Alert");
            notif.setStatus("Unread");
            notif.setCreatedDate(LocalDateTime.now());
            notificationRepository.save(notif);
        }
        return "redirect:/leave";
    }

    // --- MEMBER 1 & 3: ROLE SWITCHER ---
    @PostMapping("/switch-role")
    public String switchRole(@RequestParam String role, jakarta.servlet.http.HttpServletRequest request) {
        session.setAttribute("currentRole", role);
        String referer = request.getHeader("Referer");
        return "redirect:" + (referer != null ? referer : "/");
    }

    // --- MEMBER 1: USER & CUSTOMER MANAGEMENT ---
    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("newUser", new com.fuelstation.model.AppUser());
        return "users";
    }
    
    @PostMapping("/users/add")
    public String addUser(@ModelAttribute com.fuelstation.model.AppUser user) {
        if(user.getStatus() == null) user.setStatus("Active");
        userRepository.save(user);
        return "redirect:/users";
    }
    
    @PostMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        com.fuelstation.model.AppUser user = userRepository.findById(id).orElse(null);
        if(user != null) {
            user.setStatus("Deactivated");
            userRepository.save(user);
        }
        return "redirect:/users";
    }

    // --- MEMBER 3: VEHICLE SERVICE MANAGEMENT (WORKSHOP) ---
    @GetMapping("/workshop")
    public String workshop(Model model) {
        model.addAttribute("jobCards", jobCardRepository.findAll());
        model.addAttribute("bays", bayRepository.findAll());
        model.addAttribute("mechanics", staffRepository.findAll().stream().filter(s -> "Mechanic".equals(s.getRole())).toList());
        model.addAttribute("bookings", bookingRepository.findAll().stream().filter(b -> "Pending".equals(b.getStatus())).toList());
        return "workshop";
    }

    @PostMapping("/workshop/bay/add")
    public String addBay(@ModelAttribute com.fuelstation.model.ServiceBay bay) {
        if(bay.getStatus() == null) bay.setStatus("Available");
        bayRepository.save(bay);
        return "redirect:/workshop";
    }

    @PostMapping("/workshop/job/create")
    public String createJobCard(@RequestParam Long bookingId, @RequestParam Long mechanicId, @RequestParam Long bayId) {
        com.fuelstation.model.ServiceBooking booking = bookingRepository.findById(bookingId).orElse(null);
        com.fuelstation.model.Staff mechanic = staffRepository.findById(mechanicId).orElse(null);
        com.fuelstation.model.ServiceBay bay = bayRepository.findById(bayId).orElse(null);
        
        if (booking != null && mechanic != null && bay != null) {
            com.fuelstation.model.JobCard job = new com.fuelstation.model.JobCard();
            job.setBookingId(booking.getId());
            job.setLicensePlate(booking.getLicensePlate());
            job.setCustomerName(booking.getCustomerName());
            job.setServiceType(booking.getServiceType());
            
            job.setMechanicId(mechanic.getId());
            job.setMechanicName(mechanic.getName());
            
            job.setBayId(bay.getId());
            job.setBayName(bay.getBayName());
            
            job.setStatus("In Progress");
            jobCardRepository.save(job);
            
            // Update Booking Status
            booking.setStatus("In Progress");
            bookingRepository.save(booking);
            
            // Update Bay Status
            bay.setStatus("Occupied");
            bayRepository.save(bay);
        }
        return "redirect:/workshop";
    }

    @PostMapping("/workshop/job/update/{id}")
    public String updateJobCard(@PathVariable Long id, @RequestParam String status, @RequestParam(required=false) String mechanicNotes, @RequestParam(required=false) String partsUsed) {
        com.fuelstation.model.JobCard job = jobCardRepository.findById(id).orElse(null);
        if(job != null) {
            job.setStatus(status);
            if(mechanicNotes != null) job.setMechanicNotes(mechanicNotes);
            if(partsUsed != null) job.setPartsUsed(partsUsed);
            jobCardRepository.save(job);
            
            if ("Completed".equals(status)) {
                // Free the bay
                if (job.getBayId() != null) {
                    com.fuelstation.model.ServiceBay bay = bayRepository.findById(job.getBayId()).orElse(null);
                    if (bay != null) {
                        bay.setStatus("Available");
                        bayRepository.save(bay);
                    }
                }
                
                // Update Booking Status
                com.fuelstation.model.ServiceBooking booking = bookingRepository.findById(job.getBookingId()).orElse(null);
                if (booking != null) {
                    booking.setStatus("Completed");
                    bookingRepository.save(booking);
                }
                
                // Notification
                com.fuelstation.model.Notification notif = new com.fuelstation.model.Notification();
                notif.setTitle("Job Completed");
                notif.setMessage("Service completed for vehicle " + job.getLicensePlate());
                notif.setType("Service");
                notif.setStatus("Unread");
                notif.setCreatedDate(LocalDateTime.now());
                notificationRepository.save(notif);
            }
        }
        return "redirect:/workshop";
    }

    // --- CUSTOMER FEEDBACK ---
    @GetMapping("/feedback")
    public String feedback(Model model) {
        model.addAttribute("feedbacks", feedbackRepository.findAllByOrderBySubmissionDateDesc());
        return "feedback";
    }

    @PostMapping("/feedback/submit")
    public String submitFeedback(@ModelAttribute com.fuelstation.model.CustomerFeedback feedback) {
        feedback.setSubmissionDate(LocalDateTime.now());
        feedback.setNeedsAttention(feedback.getRating() != null && feedback.getRating() < 3);
        feedbackRepository.save(feedback);
        
        if (feedback.getNeedsAttention()) {
            com.fuelstation.model.Notification notif = new com.fuelstation.model.Notification();
            notif.setTitle("Low Rating Alert");
            notif.setMessage("Customer " + feedback.getCustomerName() + " submitted a rating of " + feedback.getRating() + ".");
            notif.setType("Alert");
            notif.setStatus("Unread");
            notif.setCreatedDate(LocalDateTime.now());
            notificationRepository.save(notif);
        }
        return "redirect:/feedback";
    }
}
