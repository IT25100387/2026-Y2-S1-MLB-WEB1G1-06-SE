package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class FuelPump {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String pumpName;
    private String pumpNumber;
    private String fuelType;
    private String location;
    private String status; // Active, Maintenance, Disabled
    private String assignedOperator;
    
    private Double currentMeterReading;
    private Double openingReading;
    private Double closingReading;
    private Double todaysSales;
}
