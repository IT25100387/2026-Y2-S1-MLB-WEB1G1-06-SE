package com.fuelstation.config;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.awt.Desktop;
import java.net.URI;

@Component
public class BrowserOpener {
    @EventListener({ApplicationReadyEvent.class})
    public void applicationReadyEvent() {
        System.out.println("Application started... launching browser");
        try {
            String os = System.getProperty("os.name").toLowerCase();
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                System.setProperty("java.awt.headless", "false");
                Desktop.getDesktop().browse(new URI("http://localhost:8080"));
            } else if (os.contains("win")) {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler http://localhost:8080");
            }
        } catch (Exception e) {
            System.err.println("Failed to auto-open browser: " + e.getMessage());
        }
    }
}
