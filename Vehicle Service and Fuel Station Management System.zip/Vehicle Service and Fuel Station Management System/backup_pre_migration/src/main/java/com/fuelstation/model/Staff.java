package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Staff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String role; // e.g. HR Officer, Mechanic, Attendant, Cashier
    private String contactDetails;
    private String assignedStation; // e.g. Fuel Pump 1, Service Bay A
    private String employmentStatus; // Active, On Leave, Inactive
}
