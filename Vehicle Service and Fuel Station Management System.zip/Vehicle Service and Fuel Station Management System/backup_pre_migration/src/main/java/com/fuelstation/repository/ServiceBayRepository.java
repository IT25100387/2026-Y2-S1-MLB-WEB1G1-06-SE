package com.fuelstation.repository;

import com.fuelstation.model.ServiceBay;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceBayRepository extends JpaRepository<ServiceBay, Long> {
}
