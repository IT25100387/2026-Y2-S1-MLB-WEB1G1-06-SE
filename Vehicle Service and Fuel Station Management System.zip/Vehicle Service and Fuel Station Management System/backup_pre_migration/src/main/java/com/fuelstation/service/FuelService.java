package com.fuelstation.service;

import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelSale;
import com.fuelstation.repository.FuelInventoryRepository;
import com.fuelstation.repository.FuelSaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class FuelService {

    @Autowired
    private FuelSaleRepository saleRepository;

    @Autowired
    private FuelInventoryRepository inventoryRepository;

    @Transactional
    public FuelSale recordSale(FuelSale sale) {
        sale.setSaleDate(LocalDateTime.now());
        
        // Find inventory for this fuel type
        FuelInventory inventory = inventoryRepository.findByFuelType(sale.getFuelType())
                .orElseThrow(() -> new RuntimeException("Fuel type not found in inventory"));

        // Reduce stock
        if (inventory.getCurrentStockLitres() < sale.getQuantityLitres()) {
            throw new RuntimeException("Insufficient fuel stock");
        }
        
        inventory.setCurrentStockLitres(inventory.getCurrentStockLitres() - sale.getQuantityLitres());
        
        // Update status
        if (inventory.getCurrentStockLitres() <= inventory.getMinStockWarning()) {
            inventory.setStatus("Low Stock");
        }
        
        inventoryRepository.save(inventory);
        return saleRepository.save(sale);
    }
}
