package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class LeaveRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long staffId;
    private String staffName;
    
    private String leaveType; // Annual, Sick, Casual
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;
    
    private String status; // Pending, Approved, Rejected
}
