package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class FuelInventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String fuelType; // Petrol 92, Petrol 95, Auto Diesel, Super Diesel, Kerosene
    private Double currentStockLitres;
    private Double minStockWarning;
    private Double maxCapacityLitres;
    
    private String supplier;
    private LocalDateTime lastDeliveryDate;
    private String status; // Normal, Low Stock, Critical
}
