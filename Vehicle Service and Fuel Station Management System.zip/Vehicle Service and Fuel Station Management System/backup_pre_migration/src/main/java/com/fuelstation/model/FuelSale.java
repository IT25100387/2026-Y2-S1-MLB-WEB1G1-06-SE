package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class FuelSale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String receiptNumber;
    private LocalDateTime saleDate;
    private String pumpName;
    private String fuelType;
    
    private Double quantityLitres;
    private Double currentPrice;
    private Double totalAmount;
    
    private String customerName;
    private String vehicleNumber;
    private String paymentMethod;
    private String cashier;
}
