package com.fuelstation.repository;

import com.fuelstation.model.FuelSale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FuelSaleRepository extends JpaRepository<FuelSale, Long> {
}
