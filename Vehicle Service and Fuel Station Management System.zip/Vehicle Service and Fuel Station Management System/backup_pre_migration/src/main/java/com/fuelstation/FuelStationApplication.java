package com.fuelstation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import java.awt.Desktop;
import java.net.URI;

@SpringBootApplication
public class FuelStationApplication {

    public static void main(String[] args) {
        // Set headless property to false so Desktop works
        System.setProperty("java.awt.headless", "false");
        SpringApplication.run(FuelStationApplication.class, args);
    }

    @EventListener({ApplicationReadyEvent.class})
    public void applicationReadyEvent() {
        System.out.println("Application started ... launching browser now");
        browse("http://localhost:8080");
    }

    public static void browse(String url) {
        if(Desktop.isDesktopSupported()){
            Desktop desktop = Desktop.getDesktop();
            try {
                desktop.browse(new URI(url));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Runtime runtime = Runtime.getRuntime();
            try {
                // Windows specific fallback just in case
                runtime.exec("rundll32 url.dll,FileProtocolHandler " + url);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
