package com.fuelstation.repository;

import com.fuelstation.model.FuelInventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FuelInventoryRepository extends JpaRepository<FuelInventory, Long> {
    Optional<FuelInventory> findByFuelType(String fuelType);
}
