package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class JobCard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long bookingId;
    private String licensePlate;
    private String customerName;
    
    private Long mechanicId;
    private String mechanicName;
    
    private Long bayId;
    private String bayName;
    
    private String serviceType;
    private String status; // Pending, In Progress, Waiting for Parts, Quality Check, Completed
    
    private String mechanicNotes;
    private String partsUsed;
}
