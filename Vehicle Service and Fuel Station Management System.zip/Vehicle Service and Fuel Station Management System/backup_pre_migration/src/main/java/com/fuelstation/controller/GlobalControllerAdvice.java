package com.fuelstation.controller;

import com.fuelstation.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private jakarta.servlet.http.HttpSession session;

    @ModelAttribute
    public void addGlobalAttributes(Model model) {
        long unreadCount = notificationRepository.countByStatus("Unread");
        model.addAttribute("unreadCount", unreadCount);
        model.addAttribute("topNotifications", notificationRepository.findAllByOrderByCreatedDateDesc().stream().limit(5).toList());
        
        // Simulated Login Role
        String role = (String) session.getAttribute("currentRole");
        if (role == null) {
            role = "Admin"; // Default role
            session.setAttribute("currentRole", role);
        }
        model.addAttribute("currentRole", role);
    }
}
