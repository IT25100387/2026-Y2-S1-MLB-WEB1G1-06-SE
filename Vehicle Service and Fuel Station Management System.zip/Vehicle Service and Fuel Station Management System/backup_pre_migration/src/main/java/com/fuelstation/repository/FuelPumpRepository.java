package com.fuelstation.repository;

import com.fuelstation.model.FuelPump;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FuelPumpRepository extends JpaRepository<FuelPump, Long> {
}
