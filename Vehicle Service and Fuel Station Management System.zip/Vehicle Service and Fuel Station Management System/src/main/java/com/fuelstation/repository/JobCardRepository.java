package com.fuelstation.repository;

import com.fuelstation.model.JobCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JobCardRepository extends JpaRepository<JobCard, Long> {
    Optional<JobCard> findByBookingId(Long bookingId);
    Optional<JobCard> findFirstByBookingIdOrderByIdDesc(Long bookingId);
}
