package com.fuelstation.repository;

import com.fuelstation.model.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Long> {
    List<Promotion> findByActiveTrue();
    List<Promotion> findByCategoryAndActiveTrue(String category);
    Optional<Promotion> findByCodeIgnoreCase(String code);
}
