package com.fuelstation.repository;

import com.fuelstation.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findByCustomerUsernameOrderByInvoiceDateDesc(String customerUsername);
    List<Invoice> findByCustomerUsernameAndStatusOrderByInvoiceDateDesc(String customerUsername, String status);
    Optional<Invoice> findByInvoiceNo(String invoiceNo);
    List<Invoice> findByBookingId(Long bookingId);
    List<Invoice> findByStatus(String status);
}
