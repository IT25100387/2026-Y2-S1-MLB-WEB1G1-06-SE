package com.fuelstation.controller;

import com.fuelstation.model.LoyaltyReward;
import com.fuelstation.model.LoyaltyTransaction;
import com.fuelstation.model.Promotion;
import com.fuelstation.service.LoyaltyService;
import com.fuelstation.service.PromotionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerOffersController {

    @Autowired
    private PromotionService promotionService;

    @Autowired
    private LoyaltyService loyaltyService;

    // --- 1. SPECIAL OFFERS & COUPONS ---
    @GetMapping("/offers")
    public String offers(
            @RequestParam(required = false) String category,
            Model model,
            Authentication auth
    ) {
        List<Promotion> allPromos = promotionService.getActivePromotions();
        List<Promotion> displayed = allPromos;

        if (category != null && !category.equalsIgnoreCase("ALL") && !category.isBlank()) {
            displayed = allPromos.stream()
                    .filter(p -> category.equalsIgnoreCase(p.getCategory()))
                    .toList();
        }

        model.addAttribute("promotions", displayed);
        model.addAttribute("totalOffers", allPromos.size());
        model.addAttribute("currentCategory", category != null ? category.toUpperCase() : "ALL");
        model.addAttribute("activeTab", "offers");

        return "customer/offers";
    }

    // --- 2. LOYALTY & REWARDS PROGRAM ---
    @GetMapping("/loyalty")
    public String loyalty(
            @RequestParam(required = false) String voucher,
            @RequestParam(required = false) String error,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        int points = loyaltyService.getCustomerPoints(username);
        String tier = loyaltyService.getCustomerTier(username);
        List<LoyaltyReward> rewards = loyaltyService.getActiveRewards();
        List<LoyaltyTransaction> history = loyaltyService.getCustomerHistory(username);

        // Next tier calculation
        int nextTierTarget = 300;
        String nextTierName = "Silver Member";
        if (points >= 700) {
            nextTierTarget = 1500;
            nextTierName = "Platinum VIP";
        } else if (points >= 300) {
            nextTierTarget = 700;
            nextTierName = "Gold Executive";
        }
        int pointsNeeded = Math.max(0, nextTierTarget - points);
        int progressPercent = Math.min(100, (int) ((points / (double) nextTierTarget) * 100));

        model.addAttribute("points", points);
        model.addAttribute("tier", tier);
        model.addAttribute("nextTierTarget", nextTierTarget);
        model.addAttribute("nextTierName", nextTierName);
        model.addAttribute("pointsNeeded", pointsNeeded);
        model.addAttribute("progressPercent", progressPercent);
        model.addAttribute("rewards", rewards);
        model.addAttribute("history", history);
        model.addAttribute("activeTab", "loyalty");

        if (voucher != null && !voucher.isBlank()) {
            model.addAttribute("successMessage", "Reward successfully redeemed! Your instant redemption voucher code is: " + voucher);
            model.addAttribute("voucherCode", voucher);
        }
        if ("insufficient_points".equals(error)) {
            model.addAttribute("errorMessage", "Insufficient loyalty points balance to redeem this reward.");
        } else if ("failed".equals(error)) {
            model.addAttribute("errorMessage", "Could not complete reward redemption. Please try again.");
        }

        return "customer/loyalty";
    }

    @PostMapping("/loyalty/redeem/{rewardId}")
    public String redeemReward(@PathVariable Long rewardId, Authentication auth) {
        String username = getUsername(auth);
        String voucher = loyaltyService.redeemReward(username, rewardId);

        if (voucher != null) {
            return "redirect:/customer/loyalty?voucher=" + voucher;
        } else {
            return "redirect:/customer/loyalty?error=insufficient_points";
        }
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }
}
