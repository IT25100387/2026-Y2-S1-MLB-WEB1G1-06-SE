package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping({"/customer/vehicles", "/customer/garage"})
public class CustomerGarageController {

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String garage(Model model, Authentication auth,
                         @RequestParam(required = false) String success,
                         @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        List<Vehicle> vehicles = vehicleService.getVehiclesByOwner(username);

        model.addAttribute("vehicles", vehicles);
        model.addAttribute("newVehicle", new Vehicle());
        model.addAttribute("activeTab", "vehicles");

        if ("added".equals(success)) {
            model.addAttribute("successMessage", "Vehicle successfully registered to your garage!");
        } else if ("updated".equals(success)) {
            model.addAttribute("successMessage", "Vehicle specifications updated successfully!");
        } else if ("deleted".equals(success)) {
            model.addAttribute("successMessage", "Vehicle removed from your garage.");
        }

        if ("access_denied".equals(error)) {
            model.addAttribute("errorMessage", "Access Denied: You are not authorized to view or modify this vehicle.");
        } else if ("invalid_data".equals(error)) {
            model.addAttribute("errorMessage", "Please ensure all required vehicle fields are properly filled.");
        } else if ("duplicate_plate".equals(error)) {
            model.addAttribute("errorMessage", "A vehicle with this license plate is already registered in the system.");
        } else if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "The requested vehicle could not be found in your garage.");
        }

        return "customer/garage";
    }

    @PostMapping("/add")
    public String addVehicle(@ModelAttribute Vehicle vehicle, Authentication auth) {
        String username = getUsername(auth);

        if (vehicle.getLicensePlate() == null || vehicle.getLicensePlate().trim().isEmpty() ||
            vehicle.getMake() == null || vehicle.getMake().trim().isEmpty() ||
            vehicle.getModel() == null || vehicle.getModel().trim().isEmpty()) {
            return "redirect:/customer/vehicles?error=invalid_data";
        }

        String cleanPlate = vehicle.getLicensePlate().trim().toUpperCase();
        if (vehicleService.getVehicleByLicensePlate(cleanPlate).isPresent()) {
            return "redirect:/customer/vehicles?error=duplicate_plate";
        }

        String fullName = username;
        String phone = "";
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent()) {
            AppUser u = userOpt.get();
            if (u.getFullName() != null && !u.getFullName().isBlank()) {
                fullName = u.getFullName();
            }
        }

        vehicle.setLicensePlate(cleanPlate);
        vehicle.setMake(vehicle.getMake().trim());
        vehicle.setModel(vehicle.getModel().trim());

        vehicleService.saveCustomerVehicle(vehicle, username, fullName, phone);
        return "redirect:/customer/vehicles?success=added";
    }

    @GetMapping("/view/{id}")
    public String viewVehicle(@PathVariable Long id, Model model, Authentication auth) {
        String username = getUsername(auth);
        Optional<Vehicle> vehicleOpt = vehicleService.getVehicleForCustomer(id, username);
        if (vehicleOpt.isEmpty()) {
            return "redirect:/customer/vehicles?error=access_denied";
        }
        model.addAttribute("vehicle", vehicleOpt.get());
        model.addAttribute("serviceHistory", vehicleService.getServiceHistory(vehicleOpt.get().getLicensePlate()));
        model.addAttribute("activeTab", "vehicles");
        return "customer/vehicle_view";
    }

    @GetMapping("/edit/{id}")
    public String editVehicle(@PathVariable Long id, Model model, Authentication auth,
                              @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        Optional<Vehicle> vehicleOpt = vehicleService.getVehicleForCustomer(id, username);
        if (vehicleOpt.isEmpty()) {
            return "redirect:/customer/vehicles?error=access_denied";
        }
        model.addAttribute("vehicle", vehicleOpt.get());
        model.addAttribute("activeTab", "vehicles");
        if (error != null) {
            model.addAttribute("errorMessage", "Please provide valid vehicle specifications.");
        }
        return "customer/vehicle_edit";
    }

    @PostMapping({"/update/{id}", "/edit/{id}"})
    public String updateVehicle(@PathVariable Long id, @ModelAttribute Vehicle formVehicle, Authentication auth) {
        String username = getUsername(auth);
        Optional<Vehicle> vehicleOpt = vehicleService.getVehicleForCustomer(id, username);
        if (vehicleOpt.isEmpty()) {
            return "redirect:/customer/vehicles?error=access_denied";
        }

        if (formVehicle.getMake() == null || formVehicle.getMake().trim().isEmpty() ||
            formVehicle.getModel() == null || formVehicle.getModel().trim().isEmpty()) {
            return "redirect:/customer/vehicles/edit/" + id + "?error=invalid_data";
        }

        Vehicle existing = vehicleOpt.get();
        existing.setMake(formVehicle.getMake().trim());
        existing.setModel(formVehicle.getModel().trim());
        existing.setManufactureYear(formVehicle.getManufactureYear());
        existing.setFuelType(formVehicle.getFuelType());
        existing.setMileage(formVehicle.getMileage());
        existing.setEngineNumber(formVehicle.getEngineNumber() != null ? formVehicle.getEngineNumber().trim() : null);
        existing.setChassisNumber(formVehicle.getChassisNumber() != null ? formVehicle.getChassisNumber().trim() : null);

        vehicleService.saveVehicle(existing);
        return "redirect:/customer/vehicles?success=updated";
    }

    @PostMapping("/delete/{id}")
    public String deleteVehicle(@PathVariable Long id, Authentication auth) {
        String username = getUsername(auth);
        boolean deleted = vehicleService.deleteCustomerVehicle(id, username);
        if (!deleted) {
            return "redirect:/customer/vehicles?error=access_denied";
        }
        return "redirect:/customer/vehicles?success=deleted";
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }
}
