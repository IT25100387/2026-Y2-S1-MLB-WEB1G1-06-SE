package com.fuelstation.controller;

import com.fuelstation.model.CustomerFeedback;
import com.fuelstation.model.ServiceBay;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.WorkshopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class WorkshopController {

    @Autowired
    private WorkshopService workshopService;

    @Autowired
    private BookingService bookingService;

    // --- WORKSHOP MANAGEMENT ---
    @GetMapping("/workshop")
    public String workshop(Model model) {
        model.addAttribute("jobCards", workshopService.getAllJobCards());
        model.addAttribute("bays", workshopService.getAllBays());
        model.addAttribute("mechanics", workshopService.getAvailableMechanics());
        model.addAttribute("bookings", bookingService.getPendingBookings());
        return "workshop";
    }

    @PostMapping("/workshop/bay/add")
    public String addBay(@ModelAttribute ServiceBay bay) {
        workshopService.addBay(bay);
        return "redirect:/workshop";
    }

    @PostMapping("/workshop/job/create")
    public String createJobCard(@RequestParam Long bookingId, @RequestParam Long mechanicId, @RequestParam Long bayId) {
        workshopService.createJobCard(bookingId, mechanicId, bayId);
        return "redirect:/workshop";
    }

    @PostMapping("/workshop/job/update/{id}")
    public String updateJobCard(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String mechanicNotes,
            @RequestParam(required = false) String partsUsed
    ) {
        workshopService.updateJobCard(id, status, mechanicNotes, partsUsed);
        return "redirect:/workshop";
    }

    // --- CUSTOMER FEEDBACK ---
    @GetMapping({"/feedback", "/customer/feedback"})
    public String feedback(Model model) {
        model.addAttribute("feedbacks", workshopService.getAllFeedbacks());
        model.addAttribute("activeTab", "feedback");
        return "feedback";
    }

    @PostMapping({"/feedback/submit", "/customer/feedback/submit"})
    public String submitFeedback(@ModelAttribute CustomerFeedback feedback) {
        workshopService.submitFeedback(feedback);
        return "redirect:/feedback?success=true";
    }
}
