package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.FuelService;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/customer")
public class CustomerProfileController {

    @Autowired
    private UserService userService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private FuelService fuelService;

    private String getUsername(Authentication auth) {
        return (auth != null && auth.isAuthenticated()) ? auth.getName() : "customer";
    }

    // --- VIEW PROFILE ---
    @GetMapping("/profile")
    public String profile(Model model, Authentication auth,
                          @RequestParam(required = false) String success,
                          @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        AppUser user = userService.getUserByUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer profile not found"));

        int vehicleCount = vehicleService.getVehiclesByOwner(username).size();
        int bookingCount = bookingService.getBookingsByCustomer(username).size();
        int fuelPurchaseCount = fuelService.getCustomerFuelPurchases(username).size();

        model.addAttribute("user", user);
        model.addAttribute("vehicleCount", vehicleCount);
        model.addAttribute("bookingCount", bookingCount);
        model.addAttribute("fuelPurchaseCount", fuelPurchaseCount);
        model.addAttribute("activeTab", "profile");

        if ("updated".equals(success)) {
            model.addAttribute("successMessage", "Profile information updated successfully!");
        } else if ("password_changed".equals(success)) {
            model.addAttribute("successMessage", "Security credentials updated! Your new password is now active.");
        }

        if ("invalid_current".equals(error)) {
            model.addAttribute("errorMessage", "Current password verification failed. Please re-enter your password.");
        } else if ("mismatch".equals(error)) {
            model.addAttribute("errorMessage", "New password and confirmation password do not match.");
        } else if ("length".equals(error)) {
            model.addAttribute("errorMessage", "New password must be at least 6 characters long.");
        }

        return "customer/profile";
    }

    // --- UPDATE PROFILE ---
    @PostMapping("/profile/update")
    public String updateProfile(
            @RequestParam("fullName") String fullName,
            @RequestParam("email") String email,
            @RequestParam(value = "phoneNumber", required = false) String phoneNumber,
            @RequestParam(value = "address", required = false) String address,
            @RequestParam(value = "city", required = false) String city,
            Authentication auth
    ) {
        String username = getUsername(auth);
        userService.updateProfile(username, fullName, email, phoneNumber, address, city);
        return "redirect:/customer/profile?success=updated";
    }

    // --- CHANGE PASSWORD (EXISTING TAB / POST) ---
    @PostMapping("/security/password")
    public String changePassword(
            @RequestParam("currentPassword") String currentPassword,
            @RequestParam("newPassword") String newPassword,
            @RequestParam("confirmPassword") String confirmPassword,
            Authentication auth
    ) {
        String username = getUsername(auth);

        if (newPassword == null || newPassword.trim().length() < 6) {
            return "redirect:/customer/profile?error=length";
        }

        if (!newPassword.trim().equals(confirmPassword != null ? confirmPassword.trim() : "")) {
            return "redirect:/customer/profile?error=mismatch";
        }

        boolean changed = userService.changePassword(username, currentPassword, newPassword);
        if (!changed) {
            return "redirect:/customer/profile?error=invalid_current";
        }

        return "redirect:/customer/profile?success=password_changed";
    }

    // --- DEDICATED CHANGE PASSWORD PAGE (GET) ---
    @GetMapping("/change-password")
    public String changePasswordPage(Model model, Authentication auth,
                                     @RequestParam(required = false) String success,
                                     @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        AppUser user = userService.getUserByUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer profile not found"));

        model.addAttribute("user", user);
        model.addAttribute("activeTab", "change-password");

        if ("password_changed".equals(success)) {
            model.addAttribute("successMessage", "Security credentials updated! Your new password has been verified and encrypted with BCrypt.");
        }

        if ("invalid_current".equals(error)) {
            model.addAttribute("errorMessage", "Current password verification failed. Please enter your valid existing password.");
        } else if ("mismatch".equals(error)) {
            model.addAttribute("errorMessage", "New password and confirmation password do not match.");
        } else if ("length".equals(error)) {
            model.addAttribute("errorMessage", "New password must contain at least 6 characters.");
        }

        return "customer/change_password";
    }

    // --- DEDICATED CHANGE PASSWORD ACTION (POST) ---
    @PostMapping("/change-password")
    public String processChangePassword(
            @RequestParam("currentPassword") String currentPassword,
            @RequestParam("newPassword") String newPassword,
            @RequestParam("confirmPassword") String confirmPassword,
            Authentication auth
    ) {
        String username = getUsername(auth);

        if (newPassword == null || newPassword.trim().length() < 6) {
            return "redirect:/customer/change-password?error=length";
        }

        if (!newPassword.trim().equals(confirmPassword != null ? confirmPassword.trim() : "")) {
            return "redirect:/customer/change-password?error=mismatch";
        }

        boolean changed = userService.changePassword(username, currentPassword, newPassword);
        if (!changed) {
            return "redirect:/customer/change-password?error=invalid_current";
        }

        return "redirect:/customer/change-password?success=password_changed";
    }

    // --- SETTINGS & NOTIFICATION PREFERENCES ---
    @GetMapping("/settings")
    public String settings(Model model, Authentication auth,
                           @RequestParam(required = false) String success) {
        String username = getUsername(auth);
        AppUser user = userService.getUserByUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer account not found"));

        model.addAttribute("user", user);
        model.addAttribute("activeTab", "settings");

        if ("saved".equals(success)) {
            model.addAttribute("successMessage", "Account settings and notification preferences saved.");
        }

        return "customer/settings";
    }

    @PostMapping("/settings/update")
    public String updateSettings(
            @RequestParam(value = "emailNotifications", defaultValue = "false") boolean emailNotifications,
            @RequestParam(value = "smsNotifications", defaultValue = "false") boolean smsNotifications,
            Authentication auth
    ) {
        String username = getUsername(auth);
        userService.updateSettings(username, emailNotifications, smsNotifications);
        return "redirect:/customer/settings?success=saved";
    }
}
