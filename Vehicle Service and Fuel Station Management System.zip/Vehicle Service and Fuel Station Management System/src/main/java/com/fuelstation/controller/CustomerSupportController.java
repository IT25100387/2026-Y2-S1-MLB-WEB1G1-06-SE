package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.SupportTicket;
import com.fuelstation.service.SupportTicketService;
import com.fuelstation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class CustomerSupportController {

    @Autowired
    private SupportTicketService supportTicketService;

    @Autowired
    private UserService userService;

    // --- CUSTOMER SUPPORT DESK ---
    @GetMapping("/customer/support")
    public String customerSupport(
            @RequestParam(required = false) String created,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        List<SupportTicket> customerTickets = supportTicketService.getTicketsForCustomer(username);
        long openCount = customerTickets.stream().filter(t -> "OPEN".equalsIgnoreCase(t.getStatus()) || "IN_PROGRESS".equalsIgnoreCase(t.getStatus())).count();

        SupportTicket formTicket = new SupportTicket();
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent()) {
            AppUser u = userOpt.get();
            formTicket.setCustomerName(u.getFullName());
            formTicket.setCustomerEmail(u.getEmail());
            formTicket.setCustomerPhone(u.getPhoneNumber());
        }

        model.addAttribute("tickets", customerTickets);
        model.addAttribute("openCount", openCount);
        model.addAttribute("formTicket", formTicket);
        model.addAttribute("activeTab", "support");

        if ("true".equals(created)) {
            model.addAttribute("successMessage", "Support ticket opened successfully. A workshop manager will inspect and update your case.");
        }

        return "customer/support";
    }

    @PostMapping("/customer/support/create")
    public String createCustomerTicket(@ModelAttribute SupportTicket ticket, Authentication auth) {
        String username = getUsername(auth);
        supportTicketService.createTicket(ticket, username);
        return "redirect:/customer/support?created=true";
    }

    // --- ADMIN / MANAGER SUPPORT DESK ---
    @GetMapping("/admin/support")
    public String adminSupport(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String resolved,
            Model model
    ) {
        List<SupportTicket> allTickets = supportTicketService.getAllTickets();
        List<SupportTicket> displayed = allTickets;

        if (status != null && !status.equalsIgnoreCase("ALL") && !status.isBlank()) {
            displayed = allTickets.stream()
                    .filter(t -> status.equalsIgnoreCase(t.getStatus()))
                    .toList();
        }

        long openCount = allTickets.stream().filter(t -> "OPEN".equalsIgnoreCase(t.getStatus())).count();
        long inProgressCount = allTickets.stream().filter(t -> "IN_PROGRESS".equalsIgnoreCase(t.getStatus())).count();
        long resolvedCount = allTickets.stream().filter(t -> "RESOLVED".equalsIgnoreCase(t.getStatus()) || "CLOSED".equalsIgnoreCase(t.getStatus())).count();

        model.addAttribute("tickets", displayed);
        model.addAttribute("totalTickets", allTickets.size());
        model.addAttribute("openCount", openCount);
        model.addAttribute("inProgressCount", inProgressCount);
        model.addAttribute("resolvedCount", resolvedCount);
        model.addAttribute("currentStatusFilter", status != null ? status.toUpperCase() : "ALL");
        model.addAttribute("activeTab", "support");

        if ("true".equals(resolved)) {
            model.addAttribute("successMessage", "Support ticket resolution and reply logged. Customer notified via portal.");
        }

        return "admin_support";
    }

    @PostMapping("/admin/support/reply/{id}")
    public String replyTicket(
            @PathVariable Long id,
            @RequestParam String adminReply,
            @RequestParam(defaultValue = "RESOLVED") String status
    ) {
        supportTicketService.resolveTicket(id, adminReply, status);
        return "redirect:/admin/support?resolved=true";
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }
}
