package com.fuelstation.controller;

import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelPump;
import com.fuelstation.model.FuelSale;
import com.fuelstation.service.FuelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class FuelController {

    @Autowired
    private FuelService fuelService;

    // --- PUMPS ---
    @GetMapping("/pumps")
    public String pumps(Model model) {
        model.addAttribute("pumps", fuelService.getAllPumps());
        model.addAttribute("newPump", new FuelPump());
        return "pumps";
    }

    @PostMapping("/pumps/add")
    public String addPump(@ModelAttribute FuelPump pump) {
        fuelService.savePump(pump);
        return "redirect:/pumps";
    }

    @PostMapping("/pumps/delete/{id}")
    public String deletePump(@PathVariable Long id) {
        fuelService.deletePump(id);
        return "redirect:/pumps";
    }

    // --- INVENTORY ---
    @GetMapping("/inventory")
    public String inventory(Model model) {
        model.addAttribute("inventories", fuelService.getAllInventories());
        model.addAttribute("newInventory", new FuelInventory());
        return "inventory";
    }

    @PostMapping("/inventory/add")
    public String addInventory(@ModelAttribute FuelInventory inv) {
        fuelService.saveInventory(inv);
        return "redirect:/inventory";
    }

    @PostMapping("/inventory/update/{id}")
    public String updateInventory(@PathVariable Long id, @ModelAttribute FuelInventory inv) {
        inv.setId(id);
        fuelService.saveInventory(inv);
        return "redirect:/inventory?updated=true";
    }

    @PostMapping("/inventory/delete/{id}")
    public String deleteInventory(@PathVariable Long id) {
        fuelService.deleteInventory(id);
        return "redirect:/inventory";
    }

    // --- SALES ---
    @GetMapping("/sales")
    public String sales(Model model) {
        model.addAttribute("sales", fuelService.getAllSales());
        model.addAttribute("newSale", new FuelSale());
        model.addAttribute("pumps", fuelService.getAllPumps());
        model.addAttribute("prices", fuelService.getAllPrices());
        return "sales";
    }

    @PostMapping("/sales/add")
    public String addSale(@ModelAttribute FuelSale sale) {
        fuelService.recordSale(sale);
        return "redirect:/sales";
    }

    // --- PRICES ---
    @GetMapping("/prices")
    public String prices(Model model, org.springframework.security.core.Authentication auth) {
        if (auth != null && auth.getAuthorities().stream().anyMatch(a ->
                a.getAuthority().equalsIgnoreCase("ROLE_CUSTOMER") || a.getAuthority().equalsIgnoreCase("Customer"))) {
            return "redirect:/customer/fuel-prices";
        }
        model.addAttribute("prices", fuelService.getAllPrices());
        return "prices";
    }

    @PostMapping("/prices/update/{id}")
    public String updatePrice(
            @PathVariable Long id,
            @RequestParam Double newPrice,
            org.springframework.security.core.Authentication auth
    ) {
        fuelService.getAllPrices().stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .ifPresent(p -> {
                    p.setPreviousPrice(p.getCurrentPrice());
                    p.setCurrentPrice(newPrice);
                    p.setLastUpdated(java.time.LocalDateTime.now());
                    p.setUpdatedBy(auth != null ? auth.getName() : "Admin");
                    fuelService.savePrice(p);
                });
        return "redirect:/prices?updated=true";
    }

    @PostMapping("/prices/add")
    public String addPrice(@ModelAttribute com.fuelstation.model.FuelPrice price, org.springframework.security.core.Authentication auth) {
        if (price.getLastUpdated() == null) {
            price.setLastUpdated(java.time.LocalDateTime.now());
        }
        if (price.getUpdatedBy() == null) {
            price.setUpdatedBy(auth != null ? auth.getName() : "Admin");
        }
        fuelService.savePrice(price);
        return "redirect:/prices?added=true";
    }

    @PostMapping("/prices/delete/{id}")
    public String deletePrice(@PathVariable Long id) {
        fuelService.deletePrice(id);
        return "redirect:/prices?deleted=true";
    }
}
