package com.fuelstation.controller;

import com.fuelstation.model.Notification;
import com.fuelstation.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerNotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/notifications")
    public String myNotifications(
            @RequestParam(required = false) String filter,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        List<Notification> list = notificationService.getNotificationsForCustomer(username);

        // If no notifications exist yet, seed initial helpful customer welcome notifications
        if (list.isEmpty()) {
            notificationService.createCustomerNotification(
                    username,
                    "Welcome to FuelCore Station OS",
                    "Your smart automotive and fuel management portal is fully activated. Schedule bookings, inspect live bays, and review fuel invoices anytime.",
                    "General",
                    "/customer/vehicles",
                    "fa-shield-halved"
            );
            notificationService.createCustomerNotification(
                    username,
                    "Live Fuel Tariffs Active",
                    "Station fuel prices (Petrol 92, Petrol 95, Auto Diesel, Super Diesel) are calibrated in real-time.",
                    "Fuel",
                    "/customer/fuel-prices",
                    "fa-gas-pump"
            );
            list = notificationService.getNotificationsForCustomer(username);
        }

        List<Notification> displayed = list;
        if ("unread".equalsIgnoreCase(filter)) {
            displayed = list.stream().filter(n -> "Unread".equalsIgnoreCase(n.getStatus())).toList();
        } else if ("bookings".equalsIgnoreCase(filter)) {
            displayed = list.stream().filter(n -> "Booking".equalsIgnoreCase(n.getType()) || "Service".equalsIgnoreCase(n.getType())).toList();
        } else if ("billing".equalsIgnoreCase(filter)) {
            displayed = list.stream().filter(n -> "Billing".equalsIgnoreCase(n.getType()) || "Invoice".equalsIgnoreCase(n.getType())).toList();
        }

        long unreadCount = notificationService.getUnreadCountForCustomer(username);

        model.addAttribute("notifications", displayed);
        model.addAttribute("totalCount", list.size());
        model.addAttribute("unreadCount", unreadCount);
        model.addAttribute("currentFilter", filter != null ? filter.toLowerCase() : "all");
        model.addAttribute("activeTab", "notifications");

        return "customer/notifications";
    }

    @PostMapping("/notifications/read/{id}")
    public String markRead(@PathVariable Long id, Authentication auth) {
        notificationService.markAsRead(id);
        return "redirect:/customer/notifications";
    }

    @PostMapping("/notifications/read-all")
    public String markAllRead(Authentication auth) {
        String username = getUsername(auth);
        notificationService.markAllReadForCustomer(username);
        return "redirect:/customer/notifications";
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }
}
