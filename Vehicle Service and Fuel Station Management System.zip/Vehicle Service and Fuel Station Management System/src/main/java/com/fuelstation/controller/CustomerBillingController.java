package com.fuelstation.controller;

import com.fuelstation.model.Invoice;
import com.fuelstation.model.PaymentRecord;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.AuditLogService;
import com.fuelstation.service.BillingService;
import com.fuelstation.service.PdfReceiptService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/customer")
public class CustomerBillingController {

    @Autowired
    private BillingService billingService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private PdfReceiptService pdfReceiptService;

    @Autowired
    private AuditLogService auditLogService;

    // --- 1. CUSTOMER INVOICES LIST ---
    @GetMapping("/invoices")
    public String myInvoices(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String success,
            @RequestParam(required = false) String error,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        List<Invoice> allInvoices = billingService.getInvoicesByCustomer(username);

        // Filter by status if specified
        List<Invoice> displayedInvoices = allInvoices;
        if (status != null && !status.equalsIgnoreCase("ALL") && !status.isBlank()) {
            displayedInvoices = allInvoices.stream()
                    .filter(inv -> status.equalsIgnoreCase(inv.getStatus()))
                    .toList();
        }

        long paidCount = allInvoices.stream().filter(i -> "PAID".equalsIgnoreCase(i.getStatus())).count();
        long pendingCount = allInvoices.stream().filter(i -> "PENDING".equalsIgnoreCase(i.getStatus()) || "OVERDUE".equalsIgnoreCase(i.getStatus()) || "PARTIAL".equalsIgnoreCase(i.getStatus())).count();

        double totalAmountDue = allInvoices.stream()
                .filter(i -> !"PAID".equalsIgnoreCase(i.getStatus()))
                .mapToDouble(i -> {
                    double net = i.getNetTotal() != null ? i.getNetTotal() : 0.0;
                    double paid = i.getAmountPaid() != null ? i.getAmountPaid() : 0.0;
                    return Math.max(0.0, net - paid);
                })
                .sum();

        double totalBilled = allInvoices.stream()
                .mapToDouble(i -> i.getNetTotal() != null ? i.getNetTotal() : 0.0)
                .sum();

        model.addAttribute("invoices", displayedInvoices);
        model.addAttribute("totalInvoices", allInvoices.size());
        model.addAttribute("paidCount", paidCount);
        model.addAttribute("pendingCount", pendingCount);
        model.addAttribute("totalAmountDue", totalAmountDue);
        model.addAttribute("totalBilled", totalBilled);
        model.addAttribute("currentStatusFilter", status != null ? status.toUpperCase() : "ALL");
        model.addAttribute("activeTab", "invoices");

        if ("paid".equals(success)) {
            model.addAttribute("successMessage", "Payment processed successfully! Your invoice status has been updated.");
        }
        if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "Invoice could not be found.");
        } else if ("unauthorized".equals(error)) {
            model.addAttribute("errorMessage", "Access Denied: You do not have permission to view or pay this invoice.");
        }

        return "customer/invoices";
    }

    // --- 2. SINGLE INVOICE VIEW ---
    @GetMapping("/invoices/{id}")
    public String viewInvoice(
            @PathVariable Long id,
            @RequestParam(required = false) String success,
            @RequestParam(required = false) String error,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        Optional<Invoice> invOpt = billingService.getInvoiceForCustomer(id, username);

        if (invOpt.isEmpty()) {
            return "redirect:/customer/invoices?error=unauthorized";
        }

        Invoice invoice = invOpt.get();
        List<PaymentRecord> payments = billingService.getPaymentsByInvoiceId(invoice.getId());

        double net = invoice.getNetTotal() != null ? invoice.getNetTotal() : 0.0;
        double paid = invoice.getAmountPaid() != null ? invoice.getAmountPaid() : 0.0;
        double balanceDue = Math.max(0.0, net - paid);

        model.addAttribute("invoice", invoice);
        model.addAttribute("payments", payments);
        model.addAttribute("balanceDue", balanceDue);
        model.addAttribute("activeTab", "invoices");

        if ("paid".equals(success)) {
            model.addAttribute("successMessage", "Payment transaction completed successfully! Receipt generated.");
        }

        return "customer/invoice_view";
    }

    // --- 3. DOWNLOAD INVOICE PDF ---
    @GetMapping("/invoices/{id}/pdf")
    public ResponseEntity<byte[]> downloadInvoicePdf(@PathVariable Long id, Authentication auth) {
        String username = getUsername(auth);
        Optional<Invoice> invOpt = billingService.getInvoiceForCustomer(id, username);

        if (invOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Invoice invoice = invOpt.get();
        List<PaymentRecord> payments = billingService.getPaymentsByInvoiceId(invoice.getId());

        byte[] pdfBytes = pdfReceiptService.generateInvoicePdf(invoice, payments);
        String fileName = "Invoice_" + (invoice.getInvoiceNo() != null ? invoice.getInvoiceNo() : id) + ".pdf";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", fileName);
        headers.setContentLength(pdfBytes.length);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }

    // --- 4. PAY INVOICE (SIMULATED SECURE GATEWAY) ---
    @PostMapping("/invoices/{id}/pay")
    public String payInvoice(
            @PathVariable Long id,
            @RequestParam(defaultValue = "Credit Card") String paymentMethod,
            @RequestParam(required = false) Double amount,
            Authentication auth
    ) {
        String username = getUsername(auth);
        try {
            billingService.processCustomerPayment(id, username, paymentMethod, amount);
            auditLogService.record("CUSTOMER_PAYMENT", username, "ROLE_CUSTOMER", "Settled invoice #" + id + " via " + paymentMethod + (amount != null ? " (LKR " + amount + ")" : ""), "SUCCESS");
            return "redirect:/customer/invoices/" + id + "?success=paid";
        } catch (IllegalArgumentException e) {
            auditLogService.record("CUSTOMER_PAYMENT_UNAUTHORIZED", username, "ROLE_CUSTOMER", "Unauthorized attempt to settle invoice #" + id, "SECURITY_ALERT");
            return "redirect:/customer/invoices?error=unauthorized";
        } catch (Exception e) {
            auditLogService.record("CUSTOMER_PAYMENT_FAILED", username, "ROLE_CUSTOMER", "Failed payment attempt for invoice #" + id + ": " + e.getMessage(), "FAILURE");
            return "redirect:/customer/invoices/" + id + "?error=payment_failed";
        }
    }

    // --- 5. CUSTOMER PAYMENT TRANSACTIONS & UNSETTLED INVOICES ---
    @GetMapping("/payments")
    public String myPayments(
            @RequestParam(required = false) String success,
            @RequestParam(required = false) String error,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        List<PaymentRecord> payments = billingService.getPaymentsByCustomer(username);
        List<Invoice> allInvoices = billingService.getInvoicesByCustomer(username);

        List<Invoice> pendingInvoices = allInvoices.stream()
                .filter(i -> !"PAID".equalsIgnoreCase(i.getStatus()))
                .toList();

        double totalSettled = payments.stream()
                .filter(p -> "SUCCESS".equalsIgnoreCase(p.getStatus()))
                .mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                .sum();

        long successfulCount = payments.stream()
                .filter(p -> "SUCCESS".equalsIgnoreCase(p.getStatus()))
                .count();

        double totalPendingAmount = pendingInvoices.stream()
                .mapToDouble(i -> {
                    double net = i.getNetTotal() != null ? i.getNetTotal() : 0.0;
                    double paid = i.getAmountPaid() != null ? i.getAmountPaid() : 0.0;
                    return Math.max(0.0, net - paid);
                })
                .sum();

        model.addAttribute("payments", payments);
        model.addAttribute("pendingInvoices", pendingInvoices);
        model.addAttribute("pendingCount", pendingInvoices.size());
        model.addAttribute("totalPendingAmount", totalPendingAmount);
        model.addAttribute("totalSettled", totalSettled);
        model.addAttribute("successfulCount", successfulCount);
        model.addAttribute("activeTab", "payments");

        if ("paid".equals(success)) {
            model.addAttribute("successMessage", "Payment settlement processed successfully! Invoice updated to PAID.");
        }
        if ("failed".equals(error)) {
            model.addAttribute("errorMessage", "Payment transaction failed or authorization rejected. Please try again.");
        }

        return "customer/payments";
    }

    @PostMapping("/payments/pay/{id}")
    public String payFromPaymentsLedger(
            @PathVariable Long id,
            @RequestParam(defaultValue = "Credit Card") String paymentMethod,
            @RequestParam(required = false) Double amount,
            Authentication auth
    ) {
        String username = getUsername(auth);
        try {
            billingService.processCustomerPayment(id, username, paymentMethod, amount);
            auditLogService.record("CUSTOMER_PAYMENT", username, "ROLE_CUSTOMER", "Settled invoice #" + id + " via " + paymentMethod + (amount != null ? " (LKR " + amount + ")" : ""), "SUCCESS");
            return "redirect:/customer/payments?success=paid";
        } catch (Exception e) {
            auditLogService.record("CUSTOMER_PAYMENT_FAILED", username, "ROLE_CUSTOMER", "Failed payment attempt for invoice #" + id + ": " + e.getMessage(), "FAILURE");
            return "redirect:/customer/payments?error=failed";
        }
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }
}
