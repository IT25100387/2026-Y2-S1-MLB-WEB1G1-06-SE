package com.fuelstation.controller;

import com.fuelstation.model.LeaveRequest;
import com.fuelstation.model.ShiftSchedule;
import com.fuelstation.model.Staff;
import com.fuelstation.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class StaffController {

    @Autowired
    private StaffService staffService;

    // --- STAFF DIRECTORY ---
    @GetMapping("/staff")
    public String staff(Model model) {
        model.addAttribute("staffList", staffService.getAllStaff());
        model.addAttribute("newStaff", new Staff());
        return "staff";
    }

    @PostMapping("/staff/add")
    public String addStaff(@ModelAttribute Staff staff) {
        staffService.saveStaff(staff);
        return "redirect:/staff";
    }

    @PostMapping("/staff/update/{id}")
    public String updateStaff(@PathVariable Long id, @ModelAttribute Staff staff) {
        staff.setId(id);
        staffService.saveStaff(staff);
        return "redirect:/staff?updated=true";
    }

    @PostMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id) {
        staffService.deactivateStaff(id);
        return "redirect:/staff";
    }

    // --- SHIFTS & ATTENDANCE ---
    @GetMapping("/shifts")
    public String shifts(Model model) {
        model.addAttribute("shifts", staffService.getAllShifts());
        model.addAttribute("newShift", new ShiftSchedule());
        model.addAttribute("staffList", staffService.getAllStaff());
        model.addAttribute("attendances", staffService.getAllAttendanceRecords());
        return "shifts";
    }

    @PostMapping("/shifts/add")
    public String addShift(@ModelAttribute ShiftSchedule shift) {
        staffService.saveShift(shift);
        return "redirect:/shifts";
    }

    @PostMapping("/shifts/update/{id}")
    public String updateShift(@PathVariable Long id, @ModelAttribute ShiftSchedule shift) {
        shift.setId(id);
        staffService.saveShift(shift);
        return "redirect:/shifts?updated=true";
    }

    @PostMapping("/shifts/delete/{id}")
    public String deleteShift(@PathVariable Long id) {
        staffService.deleteShift(id);
        return "redirect:/shifts";
    }

    @PostMapping("/attendance/clockin/{staffId}")
    public String clockIn(@PathVariable Long staffId) {
        staffService.clockIn(staffId);
        return "redirect:/shifts";
    }

    // --- LEAVE MANAGEMENT ---
    @GetMapping("/leave")
    public String leave(Model model) {
        model.addAttribute("leaves", staffService.getAllLeaveRequests());
        model.addAttribute("newLeave", new LeaveRequest());
        model.addAttribute("staffList", staffService.getAllStaff());
        return "leave";
    }

    @PostMapping("/leave/add")
    public String addLeave(@ModelAttribute LeaveRequest leave) {
        staffService.submitLeaveRequest(leave);
        return "redirect:/leave";
    }

    @PostMapping("/leave/action/{id}")
    public String leaveAction(@PathVariable Long id, @RequestParam String action) {
        staffService.processLeaveAction(id, action);
        return "redirect:/leave";
    }
}
