package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.JobCard;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.ServicePackageInfo;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import com.fuelstation.service.WorkshopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/customer")
public class CustomerServiceBookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private WorkshopService workshopService;

    @Autowired
    private UserService userService;

    @Autowired
    private com.fuelstation.service.BillingService billingService;

    public static final List<String> TIME_SLOTS = List.of(
            "09:00 AM", "10:00 AM", "11:00 AM",
            "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"
    );

    public static final List<ServicePackageInfo> SERVICE_PACKAGES = List.of(
            ServicePackageInfo.builder()
                    .id("oil-change")
                    .name("Engine oil change")
                    .icon("fa-oil-can")
                    .category("Routine Maintenance")
                    .estimatedCost(6500.00)
                    .estimatedDuration("45 Minutes")
                    .shortDescription("Complete synthetic or mineral engine oil drain and refill with genuine OEM filter replacement.")
                    .highlights(List.of("Full oil drain & flush inspection", "New high-flow oil filter", "Fluid leak check", "Engine oil reset & mileage sticker"))
                    .popular(true)
                    .build(),
            ServicePackageInfo.builder()
                    .id("full-service")
                    .name("Full service")
                    .icon("fa-car-burst")
                    .category("Comprehensive Care")
                    .estimatedCost(18500.00)
                    .estimatedDuration("3 Hours")
                    .shortDescription("50-point bumper-to-bumper vehicle inspection, diagnostics, fluids top-up, and mechanical tune-up.")
                    .highlights(List.of("50-point mechanical & electrical inspection", "Spark plug & air filter check", "Coolant & transmission fluid top-up", "Brake clean & exterior wash included"))
                    .popular(true)
                    .build(),
            ServicePackageInfo.builder()
                    .id("brake-inspection")
                    .name("Brake inspection")
                    .icon("fa-shield-halved")
                    .category("Safety Systems")
                    .estimatedCost(4000.00)
                    .estimatedDuration("1 Hour")
                    .shortDescription("Precision measurement of pad thickness, rotor assessment, hydraulic line pressure, and fluid check.")
                    .highlights(List.of("Brake pad & shoe measurement", "Rotor & drum runout check", "Brake fluid boiling point test", "Caliper sliding pin lubrication"))
                    .popular(false)
                    .build(),
            ServicePackageInfo.builder()
                    .id("battery-check")
                    .name("Battery check")
                    .icon("fa-car-battery")
                    .category("Electrical & Starting")
                    .estimatedCost(2500.00)
                    .estimatedDuration("30 Minutes")
                    .shortDescription("Digital computerized cold-cranking amp load test, alternator voltage check, and terminal anti-corrosion.")
                    .highlights(List.of("CCA load test & health report", "Alternator charging ripple analysis", "Terminal cleaning & anti-acid spray", "Starter draw test"))
                    .popular(false)
                    .build(),
            ServicePackageInfo.builder()
                    .id("tire-service")
                    .name("Tire service")
                    .icon("fa-compact-disc")
                    .category("Wheels & Handling")
                    .estimatedCost(5000.00)
                    .estimatedDuration("45 Minutes")
                    .shortDescription("4-wheel dynamic computerized balancing, laser alignment audit, tread depth scan, and nitrogen fill.")
                    .highlights(List.of("Computerized dynamic balancing", "Laser wheel alignment check", "Tire tread depth audit", "High-purity nitrogen pressure fill"))
                    .popular(false)
                    .build(),
            ServicePackageInfo.builder()
                    .id("vehicle-wash")
                    .name("Vehicle wash")
                    .icon("fa-shower")
                    .category("Detailing & Wash")
                    .estimatedCost(3500.00)
                    .estimatedDuration("40 Minutes")
                    .shortDescription("High-pressure undercarriage wash, pH-neutral snow foam wash, interior vacuuming, and glass buffing.")
                    .highlights(List.of("High-pressure chassis power wash", "Snow foam contact wash", "Deep cabin vacuuming", "Dashboard & console conditioner"))
                    .popular(false)
                    .build(),
            ServicePackageInfo.builder()
                    .id("ac-service")
                    .name("AC service")
                    .icon("fa-snowflake")
                    .category("Climate Control")
                    .estimatedCost(8500.00)
                    .estimatedDuration("1.5 Hours")
                    .shortDescription("Refrigerant recovery and top-up, cabin pollen filter cleaning, condenser flush, and antibacterial misting.")
                    .highlights(List.of("R134a / R1234yf pressure check & top-up", "Cabin pollen filter cleaning", "Condenser coil cleaning", "Antibacterial evaporator sanitization"))
                    .popular(false)
                    .build(),
            ServicePackageInfo.builder()
                    .id("general-repairs")
                    .name("General repairs")
                    .icon("fa-wrench")
                    .category("Diagnostics & Mechanical")
                    .estimatedCost(7500.00)
                    .estimatedDuration("2 Hours")
                    .shortDescription("OBD-II computerized diagnostic scanning, noise troubleshooting, suspension assessment, and repair estimate.")
                    .highlights(List.of("Comprehensive OBD-II computer diagnostic", "Engine/transmission noise inspection", "Suspension & steering audit", "Detailed repair quotation"))
                    .popular(false)
                    .build()
    );

    // --- 1. SERVICE CATALOGUE ---
    @GetMapping("/services")
    public String services(Model model) {
        model.addAttribute("packages", SERVICE_PACKAGES);
        model.addAttribute("activeTab", "services");
        return "customer/services";
    }

    // --- 2. SERVICE BOOKING WIZARD ---
    @GetMapping("/book")
    public String bookForm(Model model, Authentication auth,
                           @RequestParam(required = false) String serviceType,
                           @RequestParam(required = false) String plate,
                           @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);

        ServiceBooking booking = new ServiceBooking();
        if (serviceType != null && !serviceType.isBlank()) {
            booking.setServiceType(serviceType.trim());
            ServicePackageInfo pkg = findPackageByName(serviceType);
            if (pkg != null) {
                booking.setEstimatedCost(pkg.getEstimatedCost());
                booking.setEstimatedDuration(pkg.getEstimatedDuration());
            }
        }
        if (plate != null && !plate.isBlank()) {
            booking.setLicensePlate(plate.trim().toUpperCase());
        } else if (customerVehicles.size() == 1) {
            booking.setLicensePlate(customerVehicles.get(0).getLicensePlate());
        }

        booking.setServiceDate(LocalDate.now().plusDays(1));
        booking.setTimeSlot("09:00 AM");

        model.addAttribute("booking", booking);
        model.addAttribute("vehicles", customerVehicles);
        model.addAttribute("packages", SERVICE_PACKAGES);
        model.addAttribute("timeSlots", TIME_SLOTS);
        model.addAttribute("minDate", LocalDate.now());
        model.addAttribute("activeTab", "book");

        if ("slot_taken".equals(error)) {
            model.addAttribute("errorMessage", "The selected time slot is already booked. Please choose another date or time slot.");
        } else if ("invalid_data".equals(error)) {
            model.addAttribute("errorMessage", "Please complete all mandatory booking details.");
        } else if ("vehicle_required".equals(error)) {
            model.addAttribute("errorMessage", "You must register a vehicle in My Garage before booking a service.");
        } else if ("unauthorized_vehicle".equals(error)) {
            model.addAttribute("errorMessage", "Access Denied: The selected vehicle is not registered under your account.");
        }

        return "customer/book";
    }

    @PostMapping("/book")
    public String submitBooking(@ModelAttribute ServiceBooking booking, Authentication auth) {
        String username = getUsername(auth);

        // Validation: Required fields
        if (booking.getLicensePlate() == null || booking.getLicensePlate().trim().isEmpty() ||
            booking.getServiceType() == null || booking.getServiceType().trim().isEmpty() ||
            booking.getServiceDate() == null ||
            booking.getTimeSlot() == null || booking.getTimeSlot().trim().isEmpty()) {
            return "redirect:/customer/book?error=invalid_data";
        }

        // Validation: Date cannot be in the past
        if (booking.getServiceDate().isBefore(LocalDate.now())) {
            return "redirect:/customer/book?error=invalid_data";
        }

        // Verify vehicle ownership
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);
        Optional<Vehicle> ownedOpt = customerVehicles.stream()
                .filter(v -> v.getLicensePlate().equalsIgnoreCase(booking.getLicensePlate().trim()))
                .findFirst();

        if (ownedOpt.isEmpty()) {
            return "redirect:/customer/book?error=unauthorized_vehicle";
        }

        // Validate slot availability
        if (!bookingService.isSlotAvailable(booking.getServiceDate(), booking.getTimeSlot().trim())) {
            return "redirect:/customer/book?error=slot_taken&serviceType=" + booking.getServiceType();
        }

        // Populate customer context
        String displayName = username;
        String phone = ownedOpt.get().getOwnerContact();
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent()) {
            AppUser u = userOpt.get();
            if (u.getFullName() != null && !u.getFullName().isBlank()) {
                displayName = u.getFullName();
            }
        }

        ServicePackageInfo pkg = findPackageByName(booking.getServiceType());
        if (pkg != null) {
            booking.setEstimatedCost(pkg.getEstimatedCost());
            booking.setEstimatedDuration(pkg.getEstimatedDuration());
        }

        booking.setCustomerUsername(username);
        booking.setCustomerName(displayName);
        booking.setCustomerPhone(phone);
        booking.setLicensePlate(booking.getLicensePlate().trim().toUpperCase());
        booking.setTimeSlot(booking.getTimeSlot().trim());
        booking.setStatus("Pending");
        booking.setTrackingStage("Vehicle Received");

        if (booking.getProblemDescription() != null && !booking.getProblemDescription().isBlank()) {
            booking.setNotes(booking.getProblemDescription().trim());
        }

        ServiceBooking saved = bookingService.createBooking(booking);
        if (saved.getEstimatedCost() != null && saved.getEstimatedCost() > 0) {
            try {
                billingService.createAdvanceInvoice(saved, saved.getEstimatedCost());
            } catch (Exception e) {
                // Log and continue gracefully
            }
        }
        return "redirect:/customer/appointments?success=booked";
    }

    // --- 3. APPOINTMENT MANAGEMENT ---
    @GetMapping("/appointments")
    public String appointments(Model model, Authentication auth,
                               @RequestParam(required = false) String success,
                               @RequestParam(required = false) String error) {
        String username = getUsername(auth);
        List<ServiceBooking> allCustomerBookings = bookingService.getBookingsByCustomer(username);

        LocalDate today = LocalDate.now();
        List<ServiceBooking> upcoming = new ArrayList<>();
        List<ServiceBooking> history = new ArrayList<>();

        for (ServiceBooking b : allCustomerBookings) {
            boolean isCompletedOrCancelled = "Completed".equalsIgnoreCase(b.getStatus()) || "Cancelled".equalsIgnoreCase(b.getStatus());
            if (!isCompletedOrCancelled && (b.getServiceDate() != null && !b.getServiceDate().isBefore(today))) {
                upcoming.add(b);
            } else {
                history.add(b);
            }
        }

        model.addAttribute("upcomingBookings", upcoming);
        model.addAttribute("historyBookings", history);
        model.addAttribute("timeSlots", TIME_SLOTS);
        model.addAttribute("minDate", today);
        model.addAttribute("activeTab", "appointments");

        if ("booked".equals(success)) {
            model.addAttribute("successMessage", "Service appointment scheduled successfully! We look forward to servicing your vehicle.");
        } else if ("rescheduled".equals(success)) {
            model.addAttribute("successMessage", "Appointment has been successfully rescheduled.");
        } else if ("cancelled".equals(success)) {
            model.addAttribute("successMessage", "Service appointment was cancelled. Your allocated bay slot has been freed.");
        }

        if ("access_denied".equals(error)) {
            model.addAttribute("errorMessage", "Access Denied: You are not authorized to view or modify this appointment.");
        } else if ("slot_taken".equals(error)) {
            model.addAttribute("errorMessage", "Selected reschedule slot is unavailable. Please select another date or time slot.");
        } else if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "Appointment record not found.");
        }

        return "customer/appointments";
    }

    @PostMapping("/appointments/reschedule/{id}")
    public String rescheduleAppointment(@PathVariable Long id,
                                         @RequestParam LocalDate serviceDate,
                                         @RequestParam String timeSlot,
                                         Authentication auth) {
        String username = getUsername(auth);
        if (!bookingService.isBookingOwnedByUser(id, username)) {
            return "redirect:/customer/appointments?error=access_denied";
        }

        if (serviceDate == null || serviceDate.isBefore(LocalDate.now()) || timeSlot == null || timeSlot.isBlank()) {
            return "redirect:/customer/appointments?error=invalid_data";
        }

        try {
            bookingService.rescheduleBooking(id, serviceDate, timeSlot.trim(), username);
            return "redirect:/customer/appointments?success=rescheduled";
        } catch (IllegalStateException e) {
            return "redirect:/customer/appointments?error=slot_taken";
        } catch (Exception e) {
            return "redirect:/customer/appointments?error=reschedule_failed";
        }
    }

    @PostMapping("/appointments/cancel/{id}")
    public String cancelAppointment(@PathVariable Long id, Authentication auth) {
        String username = getUsername(auth);
        if (!bookingService.isBookingOwnedByUser(id, username)) {
            return "redirect:/customer/appointments?error=access_denied";
        }

        try {
            bookingService.cancelBookingForCustomer(id, username);
            return "redirect:/customer/appointments?success=cancelled";
        } catch (Exception e) {
            return "redirect:/customer/appointments?error=cancel_failed";
        }
    }

    // --- 4. LIVE SERVICE TRACKING ---
    @GetMapping("/track/{bookingId}")
    public String trackBooking(@PathVariable Long bookingId, Model model, Authentication auth) {
        String username = getUsername(auth);
        boolean isAdmin = isAdmin(auth);

        Optional<ServiceBooking> bookingOpt = bookingService.getBookingById(bookingId);
        if (bookingOpt.isEmpty()) {
            return "redirect:/customer/appointments?error=not_found";
        }

        ServiceBooking booking = bookingOpt.get();
        // Strict ownership check (unless admin)
        if (!isAdmin && !bookingService.isBookingOwnedByUser(bookingId, username)) {
            return "redirect:/customer/appointments?error=access_denied";
        }

        Optional<JobCard> jobOpt = workshopService.getJobCardByBookingId(bookingId);
        JobCard jobCard = jobOpt.orElse(null);

        // Calculate visual progress (Stage 1 to 5)
        int currentStage = calculateStage(booking, jobCard);
        int progressPercent = Math.min(100, Math.max(20, currentStage * 20));

        // Vehicle info
        Optional<Vehicle> vehicleOpt = vehicleService.getAllVehicles().stream()
                .filter(v -> v.getLicensePlate().equalsIgnoreCase(booking.getLicensePlate()))
                .findFirst();

        model.addAttribute("booking", booking);
        model.addAttribute("jobCard", jobCard);
        model.addAttribute("vehicle", vehicleOpt.orElse(null));
        model.addAttribute("currentStage", currentStage);
        model.addAttribute("progressPercent", progressPercent);
        model.addAttribute("activeTab", "appointments");

        return "customer/track";
    }

    // --- 5. CUSTOMER SERVICE LIFECYCLE HISTORY ---
    @GetMapping("/service-history")
    public String customerServiceHistory(
            @RequestParam(required = false) String licensePlate,
            Model model,
            Authentication auth
    ) {
        String username = getUsername(auth);
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);
        List<ServiceBooking> allBookings = bookingService.getBookingsByCustomer(username);

        // Filter by licensePlate if provided
        String selectedPlate = null;
        if (licensePlate != null && !licensePlate.isBlank()) {
            String trimmedPlate = licensePlate.trim().toUpperCase();
            boolean isOwned = customerVehicles.stream().anyMatch(v -> v.getLicensePlate().equalsIgnoreCase(trimmedPlate));
            if (isOwned) {
                selectedPlate = trimmedPlate;
                allBookings = allBookings.stream()
                        .filter(b -> b.getLicensePlate() != null && b.getLicensePlate().equalsIgnoreCase(trimmedPlate))
                        .toList();
            }
        }

        // Sort descending by date (newest first)
        List<ServiceBooking> sortedBookings = allBookings.stream()
                .sorted((a, b) -> {
                    if (a.getServiceDate() == null && b.getServiceDate() == null) return 0;
                    if (a.getServiceDate() == null) return 1;
                    if (b.getServiceDate() == null) return -1;
                    return b.getServiceDate().compareTo(a.getServiceDate());
                })
                .toList();

        List<ServiceHistoryItem> historyItems = new ArrayList<>();
        long completedCount = 0;
        long inProgressCount = 0;
        double totalSpend = 0.0;

        for (ServiceBooking b : sortedBookings) {
            JobCard jc = workshopService.getJobCardByBookingId(b.getId()).orElse(null);
            Vehicle v = customerVehicles.stream()
                    .filter(veh -> veh.getLicensePlate() != null && veh.getLicensePlate().equalsIgnoreCase(b.getLicensePlate()))
                    .findFirst()
                    .orElse(null);

            historyItems.add(new ServiceHistoryItem(b, jc, v));

            if ("Completed".equalsIgnoreCase(b.getStatus())) {
                completedCount++;
                if (b.getEstimatedCost() != null) {
                    totalSpend += b.getEstimatedCost();
                }
            } else if ("In Progress".equalsIgnoreCase(b.getStatus()) || "Assigned".equalsIgnoreCase(b.getStatus()) || "Approved".equalsIgnoreCase(b.getStatus())) {
                inProgressCount++;
            }
        }

        model.addAttribute("historyItems", historyItems);
        model.addAttribute("vehicles", customerVehicles);
        model.addAttribute("selectedPlate", selectedPlate);
        model.addAttribute("completedCount", completedCount);
        model.addAttribute("inProgressCount", inProgressCount);
        model.addAttribute("totalSpend", totalSpend);
        model.addAttribute("activeTab", "service-history");

        return "customer/service_history";
    }

    public static class ServiceHistoryItem {
        private final ServiceBooking booking;
        private final JobCard jobCard;
        private final Vehicle vehicle;

        public ServiceHistoryItem(ServiceBooking booking, JobCard jobCard, Vehicle vehicle) {
            this.booking = booking;
            this.jobCard = jobCard;
            this.vehicle = vehicle;
        }

        public ServiceBooking getBooking() { return booking; }
        public JobCard getJobCard() { return jobCard; }
        public Vehicle getVehicle() { return vehicle; }
    }

    private int calculateStage(ServiceBooking booking, JobCard jobCard) {
        if ("Cancelled".equalsIgnoreCase(booking.getStatus())) {
            return 0; // Cancelled
        }
        if ("Completed".equalsIgnoreCase(booking.getStatus()) || (jobCard != null && "Completed".equalsIgnoreCase(jobCard.getStatus()))) {
            return 5;
        }
        if (jobCard != null) {
            String jobStatus = jobCard.getStatus();
            if ("Quality Check".equalsIgnoreCase(jobStatus)) {
                return 4;
            }
            if ("In Progress".equalsIgnoreCase(jobStatus) || "Waiting for Parts".equalsIgnoreCase(jobStatus)) {
                return 3;
            }
            if ("Pending".equalsIgnoreCase(jobStatus)) {
                return 2;
            }
        }
        String bStatus = booking.getStatus();
        if ("In Progress".equalsIgnoreCase(bStatus)) {
            return 3;
        }
        if ("Assigned".equalsIgnoreCase(bStatus) || "Approved".equalsIgnoreCase(bStatus)) {
            return 2;
        }
        return 1; // Vehicle Received / Scheduled
    }

    private ServicePackageInfo findPackageByName(String name) {
        if (name == null) return null;
        for (ServicePackageInfo pkg : SERVICE_PACKAGES) {
            if (pkg.getName().equalsIgnoreCase(name.trim())) {
                return pkg;
            }
        }
        return null;
    }

    private String getUsername(Authentication auth) {
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            return auth.getName();
        }
        return "customer";
    }

    private boolean isAdmin(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) return false;
        for (GrantedAuthority ga : auth.getAuthorities()) {
            if ("ROLE_ADMIN".equalsIgnoreCase(ga.getAuthority()) || "Admin".equalsIgnoreCase(ga.getAuthority())) {
                return true;
            }
        }
        return false;
    }
}
