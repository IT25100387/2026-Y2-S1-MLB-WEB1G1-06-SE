package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.FuelPrice;
import com.fuelstation.model.FuelSale;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.FuelService;
import com.fuelstation.service.PdfReceiptService;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/customer")
public class CustomerFuelController {

    @Autowired
    private FuelService fuelService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private UserService userService;

    @Autowired
    private PdfReceiptService pdfReceiptService;

    private String getUsername(Authentication auth) {
        return (auth != null && auth.isAuthenticated()) ? auth.getName() : "customer";
    }

    private String getDisplayName(String username) {
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getFullName() != null && !userOpt.get().getFullName().isBlank()) {
            return userOpt.get().getFullName().trim();
        }
        return username;
    }

    // --- 1. CUSTOMER FUEL PRICES BOARD ---
    @GetMapping({"/fuel-prices", "/prices"})
    public String fuelPrices(Model model, Authentication auth) {
        String username = getUsername(auth);
        fuelService.seedDefaultFuelDataIfEmpty();
        List<FuelPrice> prices = fuelService.getAllPrices();

        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);

        model.addAttribute("prices", prices);
        model.addAttribute("customerVehicles", customerVehicles);
        model.addAttribute("displayName", getDisplayName(username));
        model.addAttribute("activeTab", "fuel-prices");
        return "customer/fuel_prices";
    }

    // --- 2. CUSTOMER FUEL PURCHASE HISTORY ---
    @GetMapping({"/fuel-history", "/fuel-purchases"})
    public String fuelHistory(Model model, Authentication auth,
                              @RequestParam(required = false) String success,
                              @RequestParam(required = false) String error) {
        String username = getUsername(auth);

        List<FuelSale> purchases = fuelService.getCustomerFuelPurchases(username);
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);

        double totalLitres = purchases.stream()
                .mapToDouble(s -> s.getQuantityLitres() != null ? s.getQuantityLitres() : 0.0)
                .sum();

        double totalSpend = purchases.stream()
                .mapToDouble(s -> s.getTotalAmount() != null ? s.getTotalAmount() : 0.0)
                .sum();

        model.addAttribute("purchases", purchases);
        model.addAttribute("totalLitres", Math.round(totalLitres * 100.0) / 100.0);
        model.addAttribute("totalSpend", Math.round(totalSpend * 100.0) / 100.0);
        model.addAttribute("totalPurchases", purchases.size());
        model.addAttribute("customerVehicles", customerVehicles);
        model.addAttribute("displayName", getDisplayName(username));
        model.addAttribute("activeTab", "fuel-history");

        if ("access_denied".equals(error)) {
            model.addAttribute("errorMessage", "Access Denied: You are not authorized to view the requested fuel transaction receipt.");
        } else if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "The requested fuel purchase record could not be found.");
        }

        return "customer/fuel_history";
    }

    // --- 3. E-RECEIPT / INVOICE VIEW ---
    @GetMapping("/receipt/{id}")
    public String viewReceipt(@PathVariable Long id, Model model, Authentication auth) {
        String username = getUsername(auth);

        Optional<FuelSale> saleOpt = fuelService.getSaleById(id);
        if (saleOpt.isEmpty()) {
            return "redirect:/customer/fuel-history?error=not_found";
        }

        FuelSale sale = saleOpt.get();
        if (!fuelService.isSaleAccessibleByCustomer(sale, username)) {
            return "redirect:/customer/fuel-history?error=access_denied";
        }

        model.addAttribute("sale", sale);
        model.addAttribute("activeTab", "fuel-history");
        model.addAttribute("displayName", getDisplayName(username));
        return "customer/fuel_receipt";
    }

    // --- 4. PDF RECEIPT STREAMING DOWNLOAD ---
    @GetMapping("/receipt/{id}/pdf")
    public ResponseEntity<byte[]> downloadReceiptPdf(@PathVariable Long id, Authentication auth) {
        String username = getUsername(auth);

        Optional<FuelSale> saleOpt = fuelService.getSaleById(id);
        if (saleOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        FuelSale sale = saleOpt.get();
        if (!fuelService.isSaleAccessibleByCustomer(sale, username)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        byte[] pdfBytes = pdfReceiptService.generateFuelReceiptPdf(sale);
        String receiptFileName = "FuelReceipt_" + (sale.getReceiptNumber() != null ? sale.getReceiptNumber() : id) + ".pdf";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", receiptFileName);
        headers.setContentLength(pdfBytes.length);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }
}
