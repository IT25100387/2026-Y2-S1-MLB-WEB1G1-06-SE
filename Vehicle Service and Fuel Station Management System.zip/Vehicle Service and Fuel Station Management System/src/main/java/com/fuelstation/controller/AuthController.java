package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.repository.AppUserRepository;
import com.fuelstation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private AppUserRepository userRepository;

    @GetMapping("/login")
    public String login(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            @RequestParam(value = "registered", required = false) String registered,
            Authentication authentication,
            Model model
    ) {
        // If already logged in, redirect to dashboard
        if (authentication != null && authentication.isAuthenticated() && !authentication.getName().equals("anonymousUser")) {
            return "redirect:/";
        }

        if (error != null) {
            model.addAttribute("errorMessage", "Invalid username or password. Please try again.");
        }
        if (logout != null) {
            model.addAttribute("logoutMessage", "You have been successfully logged out.");
        }
        if (registered != null) {
            model.addAttribute("registrationSuccessMessage", "Account created successfully! You can now sign in with your credentials.");
        }
        return "login";
    }

    @GetMapping("/signup")
    public String signup(Authentication authentication, Model model) {
        // If already logged in, redirect to dashboard
        if (authentication != null && authentication.isAuthenticated() && !authentication.getName().equals("anonymousUser")) {
            return "redirect:/";
        }

        model.addAttribute("user", new AppUser());
        return "signup";
    }

    @PostMapping("/signup")
    public String processSignup(
            @ModelAttribute("user") AppUser user,
            @RequestParam("confirmPassword") String confirmPassword,
            Model model
    ) {
        // Validate required fields
        if (user.getFullName() == null || user.getFullName().trim().isEmpty()) {
            model.addAttribute("errorMessage", "Full Name is required.");
            return "signup";
        }
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            model.addAttribute("errorMessage", "Email Address is required.");
            return "signup";
        }
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            model.addAttribute("errorMessage", "Username is required.");
            return "signup";
        }
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            model.addAttribute("errorMessage", "Password is required.");
            return "signup";
        }
        if (user.getPassword().trim().length() < 6) {
            model.addAttribute("errorMessage", "Password must be at least 6 characters long.");
            return "signup";
        }
        if (confirmPassword == null || !user.getPassword().trim().equals(confirmPassword.trim())) {
            model.addAttribute("errorMessage", "Passwords do not match. Please verify and re-enter.");
            return "signup";
        }

        // Validate unique username
        String cleanUsername = user.getUsername().trim();
        if (userRepository.existsByUsername(cleanUsername)) {
            model.addAttribute("errorMessage", "Username '" + cleanUsername + "' is already registered. Please choose another username.");
            return "signup";
        }

        // Automatically assign role CUSTOMER
        user.setUsername(cleanUsername);
        user.setFullName(user.getFullName().trim());
        user.setEmail(user.getEmail().trim());
        user.setPassword(user.getPassword().trim());
        user.setRole("Customer");
        user.setStatus("Active");

        // Save user (BCrypt password encoding performed by userService)
        userService.registerOrUpdateUser(user);

        return "redirect:/login?registered=true";
    }

    // --- FORGOT PASSWORD ---
    @GetMapping("/forgot-password")
    public String forgotPassword(Model model) {
        return "auth/forgot_password";
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam("identifier") String identifier, Model model) {
        if (identifier == null || identifier.trim().isEmpty()) {
            model.addAttribute("errorMessage", "Please enter your registered username or email address.");
            return "auth/forgot_password";
        }

        String token = userService.generatePasswordResetToken(identifier);
        if (token != null) {
            model.addAttribute("successMessage", "Password reset authorization generated successfully.");
            model.addAttribute("resetLink", "/reset-password?token=" + token);
            model.addAttribute("token", token);
        } else {
            model.addAttribute("errorMessage", "No registered account found with that email address or username.");
        }
        return "auth/forgot_password";
    }

    // --- RESET PASSWORD ---
    @GetMapping("/reset-password")
    public String resetPassword(@RequestParam(value = "token", required = false) String token, Model model) {
        if (token == null || token.trim().isEmpty()) {
            model.addAttribute("errorMessage", "Invalid or missing password reset authorization token.");
            return "auth/reset_password";
        }
        model.addAttribute("token", token.trim());
        return "auth/reset_password";
    }

    @PostMapping("/reset-password")
    public String processResetPassword(
            @RequestParam("token") String token,
            @RequestParam("newPassword") String newPassword,
            @RequestParam("confirmPassword") String confirmPassword,
            Model model
    ) {
        model.addAttribute("token", token);

        if (newPassword == null || newPassword.trim().length() < 6) {
            model.addAttribute("errorMessage", "New password must be at least 6 characters long.");
            return "auth/reset_password";
        }

        if (!newPassword.trim().equals(confirmPassword.trim())) {
            model.addAttribute("errorMessage", "Passwords do not match. Please re-enter.");
            return "auth/reset_password";
        }

        boolean success = userService.resetPasswordWithToken(token, newPassword);
        if (success) {
            return "redirect:/login?resetSuccess=true";
        } else {
            model.addAttribute("errorMessage", "Password reset token has expired or is invalid. Please request a new link.");
            return "auth/reset_password";
        }
    }
}
