package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.service.NotificationService;
import com.fuelstation.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.Optional;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private UserService userService;

    @Autowired
    private HttpSession session;

    @ModelAttribute
    public void addGlobalAttributes(Model model) {
        // Notifications via Service
        try {
            long unreadCount = notificationService.getUnreadCount();
            model.addAttribute("unreadCount", unreadCount);
            model.addAttribute("topNotifications", notificationService.getTopRecentNotifications(5));
        } catch (Exception e) {
            model.addAttribute("unreadCount", 0L);
        }

        // Authenticated Spring Security User & Role Resolution
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String activeRole = "Admin";
        String username = "Guest";
        String fullName = "System User";
        String email = "";

        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            username = auth.getName();
            Optional<AppUser> userOpt = userService.getUserByUsername(username);
            if (userOpt.isPresent()) {
                AppUser user = userOpt.get();
                fullName = user.getFullName() != null ? user.getFullName() : username;
                activeRole = user.getRole() != null ? user.getRole() : "Admin";
                email = user.getEmail() != null ? user.getEmail() : "";
            } else {
                // Determine from granted authorities
                for (GrantedAuthority ga : auth.getAuthorities()) {
                    String authStr = ga.getAuthority();
                    if (authStr.startsWith("ROLE_")) {
                        activeRole = authStr.substring(5);
                        activeRole = activeRole.substring(0, 1).toUpperCase() + activeRole.substring(1).toLowerCase();
                        break;
                    }
                }
                fullName = username;
            }
        } else {
            // Check session fallback
            String sessionRole = (String) session.getAttribute("currentRole");
            if (sessionRole != null) {
                activeRole = sessionRole;
            }
        }

        // Allow explicit session override if set by role switcher
        String overrideRole = (String) session.getAttribute("currentRole");
        if (overrideRole != null && !overrideRole.trim().isEmpty()) {
            activeRole = overrideRole.trim();
        }

        model.addAttribute("currentRole", activeRole);
        model.addAttribute("currentUsername", username);
        model.addAttribute("currentUserFullName", fullName);
        model.addAttribute("currentUserEmail", email);
    }
}
