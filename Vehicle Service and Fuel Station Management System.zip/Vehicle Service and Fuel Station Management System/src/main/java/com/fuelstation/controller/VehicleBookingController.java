package com.fuelstation.controller;

import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class VehicleBookingController {

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private BookingService bookingService;

    private boolean isCustomer(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) return false;
        for (GrantedAuthority ga : auth.getAuthorities()) {
            if ("ROLE_CUSTOMER".equalsIgnoreCase(ga.getAuthority()) || "Customer".equalsIgnoreCase(ga.getAuthority())) {
                return true;
            }
        }
        return false;
    }

    // --- VEHICLES ---
    @GetMapping("/vehicles")
    public String vehicles(Model model, Authentication auth,
                           @RequestParam(required = false) String success,
                           @RequestParam(required = false) String error) {
        if (isCustomer(auth)) {
            return "redirect:/customer/vehicles";
        }
        model.addAttribute("vehicles", vehicleService.getAllVehicles());
        model.addAttribute("newVehicle", new Vehicle());
        if ("updated".equals(success)) {
            model.addAttribute("successMessage", "Vehicle profile updated successfully!");
        }
        if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "Requested vehicle profile was not found.");
        }
        return "vehicles";
    }

    @PostMapping("/vehicles/add")
    public String addVehicle(@ModelAttribute Vehicle vehicle, Authentication auth) {
        if (isCustomer(auth)) {
            vehicleService.saveCustomerVehicle(vehicle, auth.getName(), auth.getName(), vehicle.getOwnerContact());
            return "redirect:/customer/vehicles?success=added";
        }
        vehicleService.saveVehicle(vehicle);
        return "redirect:/vehicles";
    }

    @GetMapping("/vehicles/edit/{id}")
    public String editVehicle(@PathVariable Long id, Model model, Authentication auth,
                              @RequestParam(required = false) String error) {
        if (isCustomer(auth)) {
            if (!vehicleService.isVehicleOwnedByUser(id, auth.getName())) {
                return "redirect:/customer/vehicles?error=access_denied";
            }
            return "redirect:/customer/vehicles/edit/" + id;
        }

        Optional<Vehicle> vehicleOpt = vehicleService.getVehicleById(id);
        if (vehicleOpt.isEmpty()) {
            return "redirect:/vehicles?error=not_found";
        }
        model.addAttribute("vehicle", vehicleOpt.get());
        if (error != null) {
            model.addAttribute("errorMessage", "Please ensure all required vehicle fields are filled correctly.");
        }
        return "vehicle_edit";
    }

    @PostMapping({"/vehicles/update/{id}", "/vehicles/edit/{id}"})
    public String updateVehicle(@PathVariable Long id, @ModelAttribute Vehicle vehicle, Authentication auth) {
        if (isCustomer(auth)) {
            if (!vehicleService.isVehicleOwnedByUser(id, auth.getName())) {
                return "redirect:/customer/vehicles?error=access_denied";
            }
        }

        Optional<Vehicle> existingOpt = vehicleService.getVehicleById(id);
        if (existingOpt.isEmpty()) {
            return isCustomer(auth) ? "redirect:/customer/vehicles?error=not_found" : "redirect:/vehicles?error=not_found";
        }
        Vehicle existing = existingOpt.get();

        // Validation: required fields
        if (vehicle.getMake() == null || vehicle.getMake().trim().isEmpty() ||
            vehicle.getModel() == null || vehicle.getModel().trim().isEmpty() ||
            vehicle.getOwnerName() == null || vehicle.getOwnerName().trim().isEmpty() ||
            vehicle.getOwnerContact() == null || vehicle.getOwnerContact().trim().isEmpty()) {
            return isCustomer(auth) ? "redirect:/customer/vehicles/edit/" + id + "?error=invalid_data" : "redirect:/vehicles/edit/" + id + "?error=invalid_data";
        }

        // Safety: Keep existing licensePlate unchanged to safeguard ServiceBooking references
        existing.setMake(vehicle.getMake().trim());
        existing.setModel(vehicle.getModel().trim());
        existing.setOwnerName(vehicle.getOwnerName().trim());
        existing.setOwnerContact(vehicle.getOwnerContact().trim());
        if (vehicle.getRegisteredDate() != null && !vehicle.getRegisteredDate().trim().isEmpty()) {
            existing.setRegisteredDate(vehicle.getRegisteredDate().trim());
        }

        vehicleService.saveVehicle(existing);
        return isCustomer(auth) ? "redirect:/customer/vehicles?success=updated" : "redirect:/vehicles?success=updated";
    }

    @PostMapping("/vehicles/delete/{id}")
    public String deleteVehicle(@PathVariable Long id, Authentication auth) {
        if (isCustomer(auth)) {
            if (!vehicleService.isVehicleOwnedByUser(id, auth.getName())) {
                return "redirect:/customer/vehicles?error=access_denied";
            }
            vehicleService.deleteVehicle(id);
            return "redirect:/customer/vehicles?success=deleted";
        }
        vehicleService.deleteVehicle(id);
        return "redirect:/vehicles";
    }

    // --- SERVICE BOOKINGS ---
    @GetMapping("/bookings")
    public String bookings(Model model, Authentication auth, @RequestParam(required = false) String error) {
        if (isCustomer(auth)) {
            return "redirect:/customer/appointments";
        }
        model.addAttribute("bookings", bookingService.getAllBookings());
        model.addAttribute("newBooking", new ServiceBooking());
        model.addAttribute("vehicles", vehicleService.getAllVehicles());
        if (error != null) {
            model.addAttribute("errorMessage", "That time slot is already booked! Please select a different time.");
        }
        return "bookings";
    }

    @PostMapping("/bookings/add")
    public String addBooking(@ModelAttribute ServiceBooking booking, Authentication auth) {
        if (isCustomer(auth)) {
            return "redirect:/customer/book";
        }
        if (!bookingService.isSlotAvailable(booking.getServiceDate(), booking.getTimeSlot())) {
            return "redirect:/bookings?error=double_booking";
        }
        bookingService.createBooking(booking);
        return "redirect:/bookings";
    }

    @PostMapping("/bookings/delete/{id}")
    public String deleteBooking(@PathVariable Long id, Authentication auth) {
        if (isCustomer(auth)) {
            return "redirect:/customer/appointments?error=access_denied";
        }
        bookingService.deleteBooking(id);
        return "redirect:/bookings";
    }

    @PostMapping("/bookings/cancel/{id}")
    public String cancelBooking(@PathVariable Long id, Authentication auth) {
        if (isCustomer(auth)) {
            try {
                bookingService.cancelBookingForCustomer(id, auth.getName());
                return "redirect:/customer/appointments?success=cancelled";
            } catch (Exception e) {
                return "redirect:/customer/appointments?error=access_denied";
            }
        }
        bookingService.cancelBooking(id);
        return "redirect:/bookings";
    }

    @PostMapping("/bookings/status/{id}")
    public String updateBookingStatus(@PathVariable Long id, @RequestParam String status, Authentication auth) {
        if (isCustomer(auth)) {
            return "redirect:/customer/appointments?error=access_denied";
        }
        bookingService.updateBookingStatus(id, status);
        return "redirect:/bookings";
    }

    // --- SERVICE HISTORY ---
    @GetMapping("/service-history")
    public String serviceHistory(Model model, Authentication auth, @RequestParam(required = false) String licensePlate) {
        if (isCustomer(auth)) {
            if (licensePlate != null && !licensePlate.trim().isEmpty()) {
                return "redirect:/customer/service-history?licensePlate=" + licensePlate.trim().toUpperCase();
            }
            return "redirect:/customer/service-history";
        }

        if (licensePlate != null && !licensePlate.trim().isEmpty()) {
            model.addAttribute("history", vehicleService.getServiceHistory(licensePlate));
            model.addAttribute("searchedPlate", licensePlate);
        }
        return "service_history";
    }
}
