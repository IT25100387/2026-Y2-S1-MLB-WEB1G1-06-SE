package com.fuelstation.controller;

import com.fuelstation.model.PaymentRecord;
import com.fuelstation.model.SparePart;
import com.fuelstation.model.Supplier;
import com.fuelstation.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class BillingController {

    @Autowired
    private BillingService billingService;

    // --- INVOICES & PAYMENTS ---
    @GetMapping("/invoices")
    public String invoices(Model model, Authentication auth) {
        if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equalsIgnoreCase("ROLE_CUSTOMER") || a.getAuthority().equalsIgnoreCase("Customer"))) {
            return "redirect:/customer/invoices";
        }
        model.addAttribute("invoices", billingService.getAllInvoices());
        model.addAttribute("newPayment", new PaymentRecord());
        return "invoices";
    }

    @PostMapping("/invoices/pay")
    public String processPayment(@ModelAttribute PaymentRecord payment) {
        billingService.processPayment(payment);
        return "redirect:/invoices";
    }

    @GetMapping("/payments")
    public String payments(Model model, Authentication auth) {
        if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equalsIgnoreCase("ROLE_CUSTOMER") || a.getAuthority().equalsIgnoreCase("Customer"))) {
            return "redirect:/customer/payments";
        }
        List<PaymentRecord> payments = billingService.getAllPayments();
        double totalSettled = payments.stream()
                .filter(p -> "SUCCESS".equalsIgnoreCase(p.getStatus()))
                .mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                .sum();
        model.addAttribute("payments", payments);
        model.addAttribute("totalSettled", totalSettled);
        model.addAttribute("activeTab", "payments");
        return "payments";
    }

    @PostMapping("/payments/refund/{id}")
    public String refundPayment(@PathVariable Long id, @RequestParam(defaultValue = "Admin Manual Adjustment") String reason) {
        billingService.refundPayment(id, reason);
        return "redirect:/payments?refunded=true";
    }

    @PostMapping("/payments/status/{id}")
    public String updatePaymentStatus(@PathVariable Long id, @RequestParam String status) {
        billingService.updatePaymentStatus(id, status);
        return "redirect:/payments?updated=true";
    }

    // --- SUPPLIERS ---
    @GetMapping("/suppliers")
    public String suppliers(Model model) {
        model.addAttribute("suppliers", billingService.getAllSuppliers());
        model.addAttribute("newSupplier", new Supplier());
        return "suppliers";
    }

    @PostMapping("/suppliers/add")
    public String addSupplier(@ModelAttribute Supplier supplier) {
        billingService.saveSupplier(supplier);
        return "redirect:/suppliers";
    }

    @PostMapping("/suppliers/update/{id}")
    public String updateSupplier(@PathVariable Long id, @ModelAttribute Supplier supplier) {
        supplier.setId(id);
        billingService.saveSupplier(supplier);
        return "redirect:/suppliers?updated=true";
    }

    @PostMapping("/suppliers/delete/{id}")
    public String deleteSupplier(@PathVariable Long id) {
        billingService.deleteSupplier(id);
        return "redirect:/suppliers";
    }

    // --- SPARE PARTS ---
    @GetMapping("/spare-parts")
    public String spareParts(Model model) {
        model.addAttribute("parts", billingService.getAllSpareParts());
        model.addAttribute("newPart", new SparePart());
        return "spare_parts";
    }

    @PostMapping("/spare-parts/add")
    public String addSparePart(@ModelAttribute SparePart part) {
        billingService.saveSparePart(part);
        return "redirect:/spare-parts";
    }

    @PostMapping("/spare-parts/delete/{id}")
    public String deleteSparePart(@PathVariable Long id) {
        billingService.deleteSparePart(id);
        return "redirect:/spare-parts";
    }
}
