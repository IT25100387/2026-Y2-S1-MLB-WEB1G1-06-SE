package com.fuelstation.controller;

import com.fuelstation.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    // --- NOTIFICATIONS ---
    @GetMapping("/notifications")
    public String notifications(Model model, org.springframework.security.core.Authentication auth) {
        if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equalsIgnoreCase("ROLE_CUSTOMER") || a.getAuthority().equalsIgnoreCase("Customer"))) {
            return "redirect:/customer/notifications";
        }
        model.addAttribute("notifications", notificationService.getAllNotifications());
        return "notifications";
    }

    @PostMapping("/notifications/read/{id}")
    public String markNotificationRead(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return "redirect:/notifications";
    }

    @PostMapping("/notifications/delete/{id}")
    public String deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return "redirect:/notifications";
    }
}
