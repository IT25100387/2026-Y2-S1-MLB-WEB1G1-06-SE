package com.fuelstation.controller;

import com.fuelstation.model.AuditLog;
import com.fuelstation.service.AuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AdminAuditController {

    @Autowired
    private AuditLogService auditLogService;

    @GetMapping({"/admin/audit-logs", "/audit-logs"})
    public String auditLogs(
            @RequestParam(required = false) String action,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String q,
            Model model
    ) {
        List<AuditLog> logs = auditLogService.filterLogs(action, role, status, q);

        model.addAttribute("logs", logs);
        model.addAttribute("totalCount", auditLogService.getTotalCount());
        model.addAttribute("successCount", auditLogService.getSuccessCount());
        model.addAttribute("securityCount", auditLogService.getSecurityEventsCount());
        model.addAttribute("selectedAction", action != null ? action : "ALL");
        model.addAttribute("selectedRole", role != null ? role : "ALL");
        model.addAttribute("selectedStatus", status != null ? status : "ALL");
        model.addAttribute("searchQuery", q != null ? q : "");
        model.addAttribute("activeTab", "audit-logs");

        return "audit_logs";
    }
}
