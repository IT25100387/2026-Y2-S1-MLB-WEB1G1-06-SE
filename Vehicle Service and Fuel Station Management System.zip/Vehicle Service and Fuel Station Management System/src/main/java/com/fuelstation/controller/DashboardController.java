package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelPrice;
import com.fuelstation.model.FuelPump;
import com.fuelstation.model.FuelSale;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.Vehicle;
import com.fuelstation.model.Invoice;
import com.fuelstation.service.BillingService;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.FuelService;
import com.fuelstation.service.NotificationService;
import com.fuelstation.service.PromotionService;
import com.fuelstation.service.StaffService;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class DashboardController {

    @Autowired
    private FuelService fuelService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private StaffService staffService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private UserService userService;

    @Autowired
    private BillingService billingService;

    @Autowired
    private PromotionService promotionService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private HttpSession session;

    private String resolveActiveRole(Authentication auth) {
        String sessionRole = (String) session.getAttribute("currentRole");
        if (sessionRole != null && !sessionRole.trim().isEmpty()) {
            return sessionRole.trim();
        }
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
            for (GrantedAuthority ga : auth.getAuthorities()) {
                String authStr = ga.getAuthority();
                if (authStr.equalsIgnoreCase("ROLE_CUSTOMER") || authStr.equalsIgnoreCase("Customer")) {
                    return "Customer";
                }
                if (authStr.equalsIgnoreCase("ROLE_ADMIN") || authStr.equalsIgnoreCase("Admin")) {
                    return "Admin";
                }
                if (authStr.equalsIgnoreCase("ROLE_MANAGER") || authStr.equalsIgnoreCase("Manager")) {
                    return "Manager";
                }
                if (authStr.equalsIgnoreCase("ROLE_CASHIER") || authStr.equalsIgnoreCase("Cashier")) {
                    return "Cashier";
                }
                if (authStr.equalsIgnoreCase("ROLE_MECHANIC") || authStr.equalsIgnoreCase("Mechanic")) {
                    return "Mechanic";
                }
                if (authStr.startsWith("ROLE_")) {
                    return authStr.substring(5);
                }
            }
        }
        return "Admin";
    }

    // --- MAIN DASHBOARD DISPATCHER ---
    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, Authentication auth) {
        String activeRole = resolveActiveRole(auth);
        if ("Customer".equalsIgnoreCase(activeRole)) {
            return customerDashboard(model, auth);
        }

        // Operational Overview Dashboard for Admin, Manager, Cashier, Mechanic
        List<FuelSale> allSales = fuelService.getAllSales();
        double totalRevenue = fuelService.getTotalRevenue();
        long pendingBookings = bookingService.getPendingBookingsCount();
        long completedBookings = bookingService.getCompletedBookingsCount();
        long pendingLeaves = staffService.getPendingLeavesCount();

        model.addAttribute("pumpsCount", fuelService.getPumpsCount());
        model.addAttribute("sales", allSales);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("pendingBookings", pendingBookings);
        model.addAttribute("completedBookings", completedBookings);
        model.addAttribute("pendingLeaves", pendingLeaves);
        model.addAttribute("inventories", fuelService.getAllInventories());
        return "index";
    }

    // --- CUSTOMER PORTAL DASHBOARD (Admin Operational Data Excluded) ---
    @GetMapping("/customer/dashboard")
    public String customerDashboard(Model model, Authentication auth) {
        String username = (auth != null && auth.isAuthenticated()) ? auth.getName() : "customer";

        String displayName = username;
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent()) {
            AppUser u = userOpt.get();
            if (u.getFullName() != null && !u.getFullName().isBlank()) {
                displayName = u.getFullName();
            }
        }

        // 1. Live Fuel Prices
        List<FuelPrice> prices = fuelService.getAllPrices();
        model.addAttribute("prices", prices);

        // 2. Customer Vehicles
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);
        model.addAttribute("customerVehicles", customerVehicles);
        model.addAttribute("vehicleCount", customerVehicles.size());

        // 3. Customer Service Appointments
        List<ServiceBooking> customerBookings = bookingService.getBookingsByCustomer(username);

        long pendingCount = customerBookings.stream()
                .filter(b -> "Pending".equalsIgnoreCase(b.getStatus()))
                .count();
        long completedCount = customerBookings.stream()
                .filter(b -> "Completed".equalsIgnoreCase(b.getStatus()))
                .count();

        // 4. Loyalty & Membership Tier
        int loyaltyPoints = 0;
        String membershipTier = "Gold Member";
        if (userOpt.isPresent()) {
            AppUser u = userOpt.get();
            loyaltyPoints = u.getEffectiveLoyaltyPoints();
            membershipTier = u.getEffectiveTier();
        }
        model.addAttribute("loyaltyPoints", loyaltyPoints);
        model.addAttribute("membershipTier", membershipTier);

        // 5. Invoices & Outstanding Balance
        List<Invoice> invoices = billingService.getInvoicesByCustomer(username);
        long unpaidInvoicesCount = invoices.stream()
                .filter(i -> !"PAID".equalsIgnoreCase(i.getStatus()))
                .count();
        double outstandingAmount = invoices.stream()
                .filter(i -> !"PAID".equalsIgnoreCase(i.getStatus()))
                .mapToDouble(i -> i.getTotalAmount() != null ? i.getTotalAmount() : 0.0)
                .sum();
        model.addAttribute("unpaidInvoicesCount", unpaidInvoicesCount);
        model.addAttribute("outstandingAmount", outstandingAmount);

        // 6. Active Promotions
        model.addAttribute("promotions", promotionService.getActivePromotions());

        // 7. Customer Notifications Feed
        model.addAttribute("recentNotifications", notificationService.getNotificationsForCustomer(username).stream().limit(3).toList());
        model.addAttribute("unreadNotifsCount", notificationService.getUnreadCountForCustomer(username));

        // 8. Recent Fuel Purchases (Customer-Specific)
        List<FuelSale> customerPurchases = fuelService.getCustomerFuelPurchases(username);
        model.addAttribute("recentPurchases", customerPurchases.stream().limit(5).toList());
        model.addAttribute("totalPurchasesCount", customerPurchases.size());

        // 9. Recent Payments (Customer-Specific)
        List<com.fuelstation.model.PaymentRecord> customerPayments = billingService.getPaymentsByCustomer(username);
        model.addAttribute("recentPayments", customerPayments.stream().limit(5).toList());
        model.addAttribute("totalPaymentsCount", customerPayments.size());

        // 10. Active Service Tracking Bookings
        List<ServiceBooking> activeTrackingBookings = customerBookings.stream()
                .filter(b -> !"Completed".equalsIgnoreCase(b.getStatus()) && !"Cancelled".equalsIgnoreCase(b.getStatus()))
                .limit(3)
                .toList();
        model.addAttribute("activeTrackingBookings", activeTrackingBookings);

        model.addAttribute("customerBookings", customerBookings);
        model.addAttribute("pendingBookingsCount", pendingCount);
        model.addAttribute("completedBookingsCount", completedCount);
        model.addAttribute("totalBookingsCount", customerBookings.size());
        model.addAttribute("displayName", displayName);
        model.addAttribute("activeTab", "dashboard");

        return "customer/dashboard";
    }

    // --- REPORTS ---
    @GetMapping("/reports")
    public String reports(Model model) {
        model.addAttribute("sales", fuelService.getAllSales());
        model.addAttribute("inventories", fuelService.getAllInventories());
        model.addAttribute("bookings", bookingService.getAllBookings());
        return "reports";
    }

    // --- SETTINGS ---
    @GetMapping("/settings")
    public String settings() {
        return "settings";
    }

    // --- ROLE SWITCHER ---
    @PostMapping("/switch-role")
    public String switchRole(@RequestParam String role, HttpServletRequest request) {
        session.setAttribute("currentRole", role);

        Authentication currentAuth = SecurityContextHolder.getContext().getAuthentication();
        if (currentAuth != null && role != null && !role.trim().isEmpty()) {
            String roleClean = role.trim();
            String roleUpper = roleClean.toUpperCase();
            List<GrantedAuthority> updatedAuthorities = new java.util.ArrayList<>();
            if (!roleUpper.startsWith("ROLE_")) {
                updatedAuthorities.add(new SimpleGrantedAuthority("ROLE_" + roleUpper));
            } else {
                updatedAuthorities.add(new SimpleGrantedAuthority(roleUpper));
            }
            updatedAuthorities.add(new SimpleGrantedAuthority(roleClean));

            Authentication newAuth = new UsernamePasswordAuthenticationToken(
                    currentAuth.getPrincipal(),
                    currentAuth.getCredentials(),
                    updatedAuthorities
            );
            SecurityContextHolder.getContext().setAuthentication(newAuth);
            request.getSession().setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());
        }

        String referer = request.getHeader("Referer");
        return "redirect:" + (referer != null ? referer : "/");
    }

    // --- DEMO / INITIAL SETUP HELPER ---
    @GetMapping("/setup")
    @ResponseBody
    public String setupData() {
        if (fuelService.getAllInventories().isEmpty()) {
            FuelInventory i1 = new FuelInventory();
            i1.setFuelType("Lanka Petrol 92");
            i1.setCurrentStockLitres(5000.0);
            i1.setMaxCapacityLitres(10000.0);
            i1.setMinStockWarning(1000.0);
            i1.setStatus("Normal");
            fuelService.saveInventory(i1);

            FuelPrice p1 = new FuelPrice();
            p1.setFuelType("Lanka Petrol 92");
            p1.setCurrentPrice(340.0);
            p1.setPreviousPrice(350.0);
            p1.setLastUpdated(LocalDateTime.now());
            fuelService.savePrice(p1);

            FuelPump pump1 = new FuelPump();
            pump1.setPumpName("Pump 1");
            pump1.setPumpNumber("PUMP-01");
            pump1.setFuelType("Lanka Petrol 92");
            pump1.setStatus("Active");
            fuelService.savePump(pump1);

            return "Setup complete";
        }
        return "Already setup";
    }
}
