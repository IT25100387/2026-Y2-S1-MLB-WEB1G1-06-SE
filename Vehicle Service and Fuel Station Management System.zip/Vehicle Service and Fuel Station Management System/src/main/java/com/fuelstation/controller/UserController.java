package com.fuelstation.controller;

import com.fuelstation.model.AppUser;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import com.fuelstation.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private BookingService bookingService;

    // --- USER DIRECTORY & MANAGEMENT (ADMIN) ---
    @GetMapping("/users")
    public String users(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String success,
            @RequestParam(required = false) String error,
            Model model
    ) {
        List<AppUser> allUsers;
        if ((search != null && !search.isBlank()) || (role != null && !role.isBlank() && !"ALL".equalsIgnoreCase(role)) || (status != null && !status.isBlank() && !"ALL".equalsIgnoreCase(status))) {
            allUsers = userService.searchUsers(search, role, status);
        } else {
            allUsers = userService.getAllUsers();
        }

        List<AppUser> fullList = userService.getAllUsers();
        long activeCount = fullList.stream().filter(u -> "Active".equalsIgnoreCase(u.getStatus())).count();
        long adminCount = fullList.stream().filter(u -> "Admin".equalsIgnoreCase(u.getRole())).count();
        long staffCount = fullList.stream().filter(u -> !"Customer".equalsIgnoreCase(u.getRole()) && !"Admin".equalsIgnoreCase(u.getRole())).count();
        long customerCount = fullList.stream().filter(u -> "Customer".equalsIgnoreCase(u.getRole())).count();

        model.addAttribute("users", allUsers);
        model.addAttribute("newUser", new AppUser());
        model.addAttribute("totalCount", fullList.size());
        model.addAttribute("activeCount", activeCount);
        model.addAttribute("adminCount", adminCount);
        model.addAttribute("staffCount", staffCount);
        model.addAttribute("customerCount", customerCount);
        model.addAttribute("search", search != null ? search : "");
        model.addAttribute("selectedRole", role != null ? role : "ALL");
        model.addAttribute("selectedStatus", status != null ? status : "ALL");
        model.addAttribute("activeTab", "users");

        if ("created".equals(success)) {
            model.addAttribute("successMessage", "New user account created successfully with encrypted credentials.");
        } else if ("updated".equals(success)) {
            model.addAttribute("successMessage", "User account profile and access privileges updated successfully.");
        } else if ("deactivated".equals(success)) {
            model.addAttribute("successMessage", "User account has been safely deactivated (soft deleted).");
        } else if ("reactivated".equals(success)) {
            model.addAttribute("successMessage", "User account has been successfully reactivated.");
        }

        if ("exists".equals(error)) {
            model.addAttribute("errorMessage", "Error: Username is already registered in the system.");
        } else if ("not_found".equals(error)) {
            model.addAttribute("errorMessage", "Error: User account not found.");
        }

        return "users";
    }

    // --- CREATE USER FORM (DEDICATED PAGE) ---
    @GetMapping({"/users/new", "/users/create"})
    public String createUserPage(Model model) {
        AppUser user = new AppUser();
        user.setStatus("Active");
        user.setRole("Customer");
        model.addAttribute("user", user);
        model.addAttribute("activeTab", "users");
        return "user_create";
    }

    @PostMapping({"/users/add", "/users/new", "/users/create"})
    public String addUser(@ModelAttribute AppUser user) {
        try {
            userService.createUser(user);
            return "redirect:/users?success=created";
        } catch (IllegalArgumentException e) {
            return "redirect:/users?error=exists";
        } catch (Exception e) {
            return "redirect:/users?error=invalid_data";
        }
    }

    // --- VIEW USER DETAILS ---
    @GetMapping({"/users/{id}", "/users/view/{id}"})
    public String viewUserDetails(@PathVariable Long id, Model model,
                                  @RequestParam(required = false) String success) {
        Optional<AppUser> userOpt = userService.getUserById(id);
        if (userOpt.isEmpty()) {
            return "redirect:/users?error=not_found";
        }

        AppUser user = userOpt.get();
        int vehicleCount = 0;
        int bookingCount = 0;
        try {
            vehicleCount = vehicleService.getVehiclesByOwner(user.getUsername()).size();
            bookingCount = bookingService.getBookingsByCustomer(user.getUsername()).size();
        } catch (Exception ignored) {}

        model.addAttribute("user", user);
        model.addAttribute("vehicleCount", vehicleCount);
        model.addAttribute("bookingCount", bookingCount);
        model.addAttribute("activeTab", "users");

        if ("updated".equals(success)) {
            model.addAttribute("successMessage", "User profile and privileges updated successfully.");
        }

        return "user_details";
    }

    // --- EDIT USER (ADMIN WORKFLOW) ---
    @GetMapping("/users/edit/{id}")
    public String editUserPage(@PathVariable Long id, Model model) {
        Optional<AppUser> userOpt = userService.getUserById(id);
        if (userOpt.isEmpty()) {
            return "redirect:/users?error=not_found";
        }

        model.addAttribute("user", userOpt.get());
        model.addAttribute("activeTab", "users");
        return "user_edit";
    }

    @PostMapping({"/users/edit/{id}", "/users/update/{id}"})
    public String saveUserEdits(
            @PathVariable Long id,
            @ModelAttribute AppUser formUser,
            @RequestParam(value = "newPassword", required = false) String newPassword
    ) {
        try {
            userService.updateUser(id, formUser, newPassword);
            return "redirect:/users/view/" + id + "?success=updated";
        } catch (Exception e) {
            return "redirect:/users/edit/" + id + "?error=update_failed";
        }
    }

    // --- SAFE DELETION (SOFT DELETE: DEACTIVATE & REACTIVATE) ---
    @PostMapping({"/users/delete/{id}", "/users/deactivate/{id}"})
    public String deactivateUser(@PathVariable Long id) {
        userService.deactivateUser(id);
        return "redirect:/users?success=deactivated";
    }

    @PostMapping("/users/reactivate/{id}")
    public String reactivateUser(@PathVariable Long id) {
        userService.reactivateUser(id);
        return "redirect:/users?success=reactivated";
    }

    @PostMapping("/users/status/{id}")
    public String toggleUserStatus(@PathVariable Long id) {
        userService.toggleUserStatus(id);
        return "redirect:/users?success=updated";
    }

    // --- CUSTOMER DIRECTORY (ADMIN / MANAGER) ---
    @GetMapping("/customers")
    public String customers(Model model) {
        List<AppUser> customers = userService.getCustomersOnly();
        long activeCount = customers.stream().filter(c -> "Active".equalsIgnoreCase(c.getStatus())).count();

        model.addAttribute("customers", customers);
        model.addAttribute("totalCustomers", customers.size());
        model.addAttribute("activeCount", activeCount);
        model.addAttribute("activeTab", "customers");
        return "customers";
    }

    @PostMapping("/customers/status/{id}")
    public String toggleCustomerStatus(@PathVariable Long id) {
        userService.toggleUserStatus(id);
        return "redirect:/customers";
    }

    @PostMapping("/customers/update/{id}")
    public String updateCustomer(@PathVariable Long id, @ModelAttribute AppUser formUser) {
        userService.updateUser(id, formUser, null);
        return "redirect:/customers?updated=true";
    }

    @PostMapping("/customers/deactivate/{id}")
    public String deactivateCustomer(@PathVariable Long id) {
        userService.deactivateUser(id);
        return "redirect:/customers?deactivated=true";
    }

    @PostMapping("/customers/reactivate/{id}")
    public String reactivateCustomer(@PathVariable Long id) {
        userService.reactivateUser(id);
        return "redirect:/customers?reactivated=true";
    }
}
