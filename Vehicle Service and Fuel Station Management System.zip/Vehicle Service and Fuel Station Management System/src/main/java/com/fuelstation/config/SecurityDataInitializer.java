package com.fuelstation.config;

import com.fuelstation.model.AppUser;
import com.fuelstation.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Order(1)
public class SecurityDataInitializer implements CommandLineRunner {

    @Autowired
    private AppUserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private com.fuelstation.service.FuelService fuelService;

    @Override
    public void run(String... args) {
        // Ensure default users exist with properly BCrypt-hashed passwords
        createOrUpdateUser("admin", "Admin@123", "Milinda Kalum", "admin@fuelcore.com", "Admin");
        createOrUpdateUser("manager", "manager123", "Sunil Perera", "manager@fuelcore.com", "Manager");
        createOrUpdateUser("cashier", "cashier123", "Kamal Fernando", "cashier@fuelcore.com", "Cashier");
        createOrUpdateUser("mechanic", "mechanic123", "Nimal Jayawardena", "mechanic@fuelcore.com", "Mechanic");
        createOrUpdateUser("customer", "customer123", "Kasun Dias", "kasun@gmail.com", "Customer");
        createOrUpdateUser("customer2", "customer123", "Nuwan Kulasekara", "nuwan@gmail.com", "Customer");

        // Ensure default fuel tariffs and initial forecourt data
        fuelService.seedDefaultFuelDataIfEmpty();
    }

    private void createOrUpdateUser(String username, String rawPassword, String fullName, String email, String role) {
        AppUser user = userRepository.findByUsername(username).orElseGet(() -> {
            AppUser newUser = new AppUser();
            newUser.setUsername(username);
            newUser.setFullName(fullName);
            newUser.setEmail(email);
            newUser.setRole(role);
            newUser.setStatus("Active");
            return newUser;
        });

        // Always ensure password is valid BCrypt hash matching rawPassword
        String currentPassword = user.getPassword() != null ? user.getPassword().trim() : "";
        if (currentPassword.isEmpty() || !currentPassword.startsWith("$2a$") || currentPassword.length() < 50 || !passwordEncoder.matches(rawPassword, currentPassword)) {
            user.setPassword(passwordEncoder.encode(rawPassword));
            userRepository.save(user);
        }
    }
}
