package com.fuelstation.config;

import com.fuelstation.model.*;
import com.fuelstation.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Component
@Order(2)
public class ComprehensiveDemoDataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(ComprehensiveDemoDataSeeder.class);

    @Autowired private AppUserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private VehicleRepository vehicleRepository;
    @Autowired private ServiceBayRepository bayRepository;
    @Autowired private StaffRepository staffRepository;
    @Autowired private ShiftScheduleRepository shiftRepository;
    @Autowired private AttendanceRecordRepository attendanceRepository;
    @Autowired private LeaveRequestRepository leaveRepository;
    @Autowired private SupplierRepository supplierRepository;
    @Autowired private SparePartRepository sparePartRepository;
    @Autowired private ServiceBookingRepository bookingRepository;
    @Autowired private JobCardRepository jobCardRepository;
    @Autowired private InvoiceRepository invoiceRepository;
    @Autowired private PaymentRecordRepository paymentRepository;
    @Autowired private CustomerFeedbackRepository feedbackRepository;
    @Autowired private FuelPriceRepository fuelPriceRepository;
    @Autowired private FuelInventoryRepository fuelInventoryRepository;
    @Autowired private FuelPumpRepository fuelPumpRepository;
    @Autowired private FuelSaleRepository fuelSaleRepository;
    @Autowired private PromotionRepository promotionRepository;
    @Autowired private LoyaltyRewardRepository loyaltyRewardRepository;
    @Autowired private LoyaltyTransactionRepository loyaltyTxRepository;
    @Autowired private SupportTicketRepository supportTicketRepository;
    @Autowired private NotificationRepository notificationRepository;
    @Autowired private AuditLogRepository auditLogRepository;

    @Override
    @Transactional
    public void run(String... args) {
        log.info("================================================================================");
        log.info(">>> FUELCORE REALISTIC SRI LANKAN DEMO DATA SEEDER STARTING <<<");
        log.info("================================================================================");

        seedCustomers();
        seedVehicles();
        seedServiceBays();
        seedStaffDirectory();
        seedShiftsAndAttendance();
        seedSuppliers();
        seedSpareParts();
        seedFuelPricesAndTanks();
        seedFuelPumpsAndSales();
        seedPromotions();
        seedLoyaltyCatalogAndTransactions();
        seedServiceBookingsWorkflow();
        seedSupportTickets();
        seedNotifications();
        seedAuditLogs();

        log.info("================================================================================");
        log.info(">>> FUELCORE REALISTIC SRI LANKAN DEMO DATA SEEDER COMPLETED SUCCESSFULLY <<<");
        log.info("================================================================================");
    }

    // -------------------------------------------------------------------------
    // 1. CUSTOMERS & EXTENDED USER PROFILES
    // -------------------------------------------------------------------------
    private void seedCustomers() {
        // Enrich default customers
        enrichCustomer("customer", "Kasun Dias", "kasun@gmail.com", "customer123",
                "+94 77 123 4567", "45/2 Temple Road", "Colombo 03", 1450, "Platinum Member");

        enrichCustomer("customer2", "Nuwan Kulasekara", "nuwan@gmail.com", "customer123",
                "+94 71 987 6543", "12 Lake Drive", "Kandy", 820, "Gold Member");

        // Additional Sri Lankan customers
        enrichCustomer("nimal", "Nimal Fernando", "nimal.f@outlook.com", "customer123",
                "+94 76 345 6789", "78 Beach Road", "Negombo", 520, "Silver Member");

        enrichCustomer("anura", "Anura Bandaranaike", "anura.bandara@yahoo.com", "customer123",
                "+94 70 234 5678", "105 Kandy Road", "Kurunegala", 310, "Silver Member");

        enrichCustomer("chamari", "Chamari Athapaththu", "chamari.a@gmail.com", "customer123",
                "+94 77 567 8901", "24 Fort Gate", "Galle", 1950, "Platinum Member");

        enrichCustomer("dilshan", "Tillakaratne Dilshan", "dilshan.t@gmail.com", "customer123",
                "+94 72 678 9012", "63 Riverside Lane", "Kalutara", 780, "Gold Member");

        enrichCustomer("dinesh", "Dinesh Chandimal", "dinesh.c@gmail.com", "customer123",
                "+94 75 890 1234", "15 Gregory's Road", "Colombo 07", 1250, "Gold Member");

        enrichCustomer("chathura", "Chathura Senanayake", "chathura.s@gmail.com", "customer123",
                "+94 78 456 7890", "88 Station Road", "Gampaha", 150, "Standard Member");
    }

    private void enrichCustomer(String username, String fullName, String email, String rawPassword,
                                String phone, String address, String city, int loyaltyPoints, String tier) {
        AppUser user = userRepository.findByUsername(username).orElseGet(() -> {
            AppUser u = new AppUser();
            u.setUsername(username);
            u.setPassword(passwordEncoder.encode(rawPassword));
            u.setRole("Customer");
            u.setStatus("Active");
            return u;
        });

        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhoneNumber(phone);
        user.setAddress(address);
        user.setCity(city);
        user.setLoyaltyPoints(loyaltyPoints);
        user.setMembershipTier(tier);
        user.setEmailNotifications(true);
        user.setSmsNotifications(true);

        if (user.getPassword() == null || !user.getPassword().startsWith("$2a$")) {
            user.setPassword(passwordEncoder.encode(rawPassword));
        }

        userRepository.save(user);
    }

    // -------------------------------------------------------------------------
    // 2. VEHICLES (AUTHENTIC SRI LANKAN NUMBER PLATES)
    // -------------------------------------------------------------------------
    private void seedVehicles() {
        createVehicleIfAbsent("WP CAB-4521", "Toyota", "Prius 1.8 S-Touring", "Kasun Dias", "+94 77 123 4567",
                "2021-03-15", 2018, "Hybrid Petrol", 68500, "2ZR-FXE-481920", "ZVW50-0048192", "customer");

        createVehicleIfAbsent("WP CAE-8921", "Honda", "Vezel Z Sensing", "Kasun Dias", "+94 77 123 4567",
                "2022-01-10", 2019, "Hybrid Petrol", 52400, "LEB-H1-912048", "RU3-1209341", "customer");

        createVehicleIfAbsent("CP CAA-1020", "Toyota", "Land Cruiser Prado TX L-Package", "Nuwan Kulasekara", "+94 71 987 6543",
                "2021-08-20", 2020, "Diesel", 41200, "1GD-FTV-781902", "GDJ150-0023910", "customer2");

        createVehicleIfAbsent("WP CBB-7788", "Suzuki", "Wagon R Stingray Hybrid", "Nuwan Kulasekara", "+94 71 987 6543",
                "2020-05-14", 2017, "Hybrid Petrol", 79300, "R06A-WA04A-55219", "MH55S-104928", "customer2");

        createVehicleIfAbsent("NW CAD-3344", "Mitsubishi", "Montero Sport GLS 4WD", "Anura Bandaranaike", "+94 70 234 5678",
                "2019-11-04", 2016, "Diesel", 114000, "4N15-MIVEC-3901", "KS1W-0012984", "anura");

        createVehicleIfAbsent("SP KX-9912", "Nissan", "Leaf G 40kWh", "Chamari Athapaththu", "+94 77 567 8901",
                "2021-06-18", 2018, "Electric", 48000, "EM57-ELECTRIC-001", "ZE1-019283", "chamari");

        createVehicleIfAbsent("WP CBA-5566", "Hyundai", "Grand i10 Magna", "Nimal Fernando", "+94 76 345 6789",
                "2022-04-12", 2019, "Petrol", 38900, "KAPPA-1.2-48201", "BA81-0091823", "nimal");

        createVehicleIfAbsent("WP PH-3321", "Toyota", "Hilux Revo D-Cab 4x4", "Tillakaratne Dilshan", "+94 72 678 9012",
                "2021-12-05", 2021, "Diesel", 62100, "2GD-FTV-881290", "GUN125-901823", "dilshan");

        createVehicleIfAbsent("WP CBG-9900", "BMW", "520d M-Sport Sedan", "Dinesh Chandimal", "+94 75 890 1234",
                "2022-02-18", 2021, "Diesel", 28400, "B47D20-TURBO-77", "WBAJB31-901827", "dinesh");

        createVehicleIfAbsent("WP BAF-1234", "Suzuki", "Alto 800 LXi", "Chathura Senanayake", "+94 78 456 7890",
                "2018-09-22", 2015, "Petrol", 92000, "F8D-GAS-66102", "HA36S-772910", "chathura");
    }

    private void createVehicleIfAbsent(String plate, String make, String model, String ownerName, String contact,
                                       String regDate, int year, String fuel, int mileage, String engine, String chassis, String username) {
        if (vehicleRepository.findByLicensePlate(plate).isEmpty()) {
            Vehicle v = new Vehicle();
            v.setLicensePlate(plate);
            v.setMake(make);
            v.setModel(model);
            v.setOwnerName(ownerName);
            v.setOwnerContact(contact);
            v.setRegisteredDate(regDate);
            v.setManufactureYear(year);
            v.setFuelType(fuel);
            v.setMileage(mileage);
            v.setEngineNumber(engine);
            v.setChassisNumber(chassis);
            v.setOwnerUsername(username);
            vehicleRepository.save(v);
        }
    }

    // -------------------------------------------------------------------------
    // 3. SERVICE BAYS
    // -------------------------------------------------------------------------
    private void seedServiceBays() {
        createBayIfAbsent("Bay 01 - Heavy Hydraulic Lift", "Available");
        createBayIfAbsent("Bay 02 - Hybrid & EV Diagnostics Center", "Occupied");
        createBayIfAbsent("Bay 03 - Express Lube & Brake Service", "Occupied");
        createBayIfAbsent("Bay 04 - Automatic Detailing & Underwash", "Available");
        createBayIfAbsent("Bay 05 - Wheel Alignment & Balancing", "Under Maintenance");
    }

    private void createBayIfAbsent(String bayName, String status) {
        boolean exists = bayRepository.findAll().stream().anyMatch(b -> bayName.equalsIgnoreCase(b.getBayName()));
        if (!exists) {
            ServiceBay bay = new ServiceBay();
            bay.setBayName(bayName);
            bay.setStatus(status);
            bayRepository.save(bay);
        }
    }

    // -------------------------------------------------------------------------
    // 4. STAFF DIRECTORY (HUMAN RESOURCES)
    // -------------------------------------------------------------------------
    private void seedStaffDirectory() {
        createStaffIfAbsent("Milinda Kalum", "General Manager", "+94 77 001 0001", "Main Office", "Active");
        createStaffIfAbsent("Sunil Perera", "Shift Supervisor", "+94 77 002 0002", "Forecourt & Workshop", "Active");
        createStaffIfAbsent("Kamal Fernando", "Senior Cashier", "+94 77 003 0003", "Counter 1 - Cashier Desk", "Active");
        createStaffIfAbsent("Sanduni Wickramasinghe", "Billing Officer", "+94 77 004 0004", "Counter 2 - Service Billing", "Active");
        createStaffIfAbsent("Nimal Jayawardena", "Master Mechanic", "+94 77 005 0005", "Bay 01 - Heavy Hydraulic Lift", "Active");
        createStaffIfAbsent("Ruwan Thushara", "Hybrid/EV Specialist", "+94 77 006 0006", "Bay 02 - Hybrid Diagnostics", "Active");
        createStaffIfAbsent("Asanka Priyadarshana", "Brake & Suspension Tech", "+94 77 007 0007", "Bay 03 - Express Lube & Brake", "Active");
        createStaffIfAbsent("Lasantha Kumara", "Forecourt Pump Lead", "+94 77 008 0008", "Fuel Island A", "Active");
        createStaffIfAbsent("Indika Sampath", "Senior Attendant", "+94 77 009 0009", "Fuel Island B", "Active");
        createStaffIfAbsent("Chaminda Silva", "Lube Technician", "+94 77 010 0010", "Bay 04 - Detailing", "On Leave");
    }

    private void createStaffIfAbsent(String name, String role, String contact, String station, String status) {
        boolean exists = staffRepository.findAll().stream().anyMatch(s -> name.equalsIgnoreCase(s.getName()));
        if (!exists) {
            Staff s = new Staff();
            s.setName(name);
            s.setRole(role);
            s.setContactDetails(contact);
            s.setAssignedStation(station);
            s.setEmploymentStatus(status);
            staffRepository.save(s);
        }
    }

    // -------------------------------------------------------------------------
    // 5. SHIFTS, ATTENDANCE & LEAVES
    // -------------------------------------------------------------------------
    private void seedShiftsAndAttendance() {
        List<Staff> staffList = staffRepository.findAll();
        if (staffList.isEmpty()) return;

        LocalDate today = LocalDate.now();

        if (shiftRepository.findAll().isEmpty()) {
            for (int i = 0; i < Math.min(staffList.size(), 6); i++) {
                Staff s = staffList.get(i);
                ShiftSchedule shift = new ShiftSchedule();
                shift.setStaffId(s.getId());
                shift.setStaffName(s.getName());
                shift.setShiftDate(today);
                shift.setShiftTiming(i % 2 == 0 ? "Morning (06:00 - 14:00)" : "Evening (14:00 - 22:00)");
                shift.setStation(s.getAssignedStation());
                shift.setStatus("Scheduled");
                shiftRepository.save(shift);
            }
        }

        if (attendanceRepository.findAll().isEmpty()) {
            for (int i = 0; i < Math.min(staffList.size(), 6); i++) {
                Staff s = staffList.get(i);
                AttendanceRecord att = new AttendanceRecord();
                att.setStaffId(s.getId());
                att.setStaffName(s.getName());
                att.setAttendanceDate(today);
                att.setClockInTime(String.format("07:%02d AM", 50 + (i * 2)));
                att.setStatus(i == 4 ? "Late" : "Present");
                attendanceRepository.save(att);
            }
        }

        if (leaveRepository.findAll().isEmpty()) {
            Staff chaminda = staffList.stream()
                    .filter(s -> s.getName().contains("Chaminda"))
                    .findFirst()
                    .orElse(staffList.get(0));

            LeaveRequest lr1 = new LeaveRequest();
            lr1.setStaffId(chaminda.getId());
            lr1.setStaffName(chaminda.getName());
            lr1.setLeaveType("Annual");
            lr1.setStartDate(today.minusDays(1));
            lr1.setEndDate(today.plusDays(3));
            lr1.setReason("Family religious pilgrimage to Anuradhapura");
            lr1.setStatus("Approved");
            leaveRepository.save(lr1);

            LeaveRequest lr2 = new LeaveRequest();
            lr2.setStaffId(staffList.get(1).getId());
            lr2.setStaffName(staffList.get(1).getName());
            lr2.setLeaveType("Casual");
            lr2.setStartDate(today.plusDays(5));
            lr2.setEndDate(today.plusDays(6));
            lr2.setReason("Personal vehicle revenue license renewal");
            lr2.setStatus("Pending");
            leaveRepository.save(lr2);
        }
    }

    // -------------------------------------------------------------------------
    // 6. SUPPLIERS (FUEL & SPARE PARTS)
    // -------------------------------------------------------------------------
    private void seedSuppliers() {
        createSupplierIfAbsent("Ceylon Petroleum Corporation (CPC)", "Ceylon Petroleum Corporation",
                "+94 11 252 3456", "supplies@ceypetco.gov.lk",
                "Lanka Petrol 92, Lanka Petrol 95, Lanka Auto Diesel, Lanka Super Diesel, Kerosene",
                "Weekly Bulk Tanker (Tue & Fri)", "Active");

        createSupplierIfAbsent("Lanka IOC PLC", "Lanka IOC PLC",
                "+94 11 247 5720", "commercial@lankaioc.com",
                "XtraPremium 95, Lanka Auto Diesel",
                "Bi-weekly", "Active");

        createSupplierIfAbsent("Sinopec Energy Lanka", "Sinopec Energy Lanka (Pvt) Ltd",
                "+94 11 750 0800", "info@sinopeclanka.lk",
                "Petrol 92, Auto Diesel",
                "Bi-weekly Tanker", "Active");

        createSupplierIfAbsent("Toyota Lanka (Pvt) Ltd", "Toyota Lanka (Pvt) Ltd",
                "+94 11 293 9000", "parts@toyota.lk",
                "Genuine Parts & Hybrid Fluids",
                "Weekly scheduled courier", "Active");

        createSupplierIfAbsent("McLarens Lubricants Ltd", "McLarens Lubricants Ltd (Mobil 1 Distributor)",
                "+94 11 244 5441", "mobil@mclarens.lk",
                "Mobil 1 Synthetic Lubricants & Engine Oils",
                "Fortnightly supply", "Active");

        createSupplierIfAbsent("United Motors Lanka PLC", "United Motors Lanka PLC",
                "+94 11 244 8411", "parts@unitedmotors.lk",
                "OEM Spares & Valvoline Fluids",
                "On-demand / Monthly", "Active");

        createSupplierIfAbsent("Bosch Automotive Lanka", "Diesel & Motor Engineering PLC (DIMO - Bosch)",
                "+94 11 244 9797", "bosch@dimolanka.com",
                "Bosch Braking Systems, Spark Plugs & Sensors",
                "Weekly", "Active");
    }

    private void createSupplierIfAbsent(String name, String comp, String contact, String email, String fuels, String schedule, String status) {
        boolean exists = supplierRepository.findAll().stream().anyMatch(s -> name.equalsIgnoreCase(s.getSupplierName()));
        if (!exists) {
            Supplier s = new Supplier();
            s.setSupplierName(name);
            s.setCompany(comp);
            s.setContactNumber(contact);
            s.setEmail(email);
            s.setFuelTypesSupplied(fuels);
            s.setDeliverySchedule(schedule);
            s.setStatus(status);
            supplierRepository.save(s);
        }
    }

    // -------------------------------------------------------------------------
    // 7. SPARE PARTS INVENTORY
    // -------------------------------------------------------------------------
    private void seedSpareParts() {
        createPartIfAbsent("Mobil 1 0W-20 Advanced Full Synthetic (4L)", "Engine Oil", 45, 10, 14500.0, 18500.0, "McLarens Lubricants Ltd", "In Stock");
        createPartIfAbsent("Toyota Genuine Oil Filter (90915-10009)", "Filters", 60, 15, 2200.0, 3200.0, "Toyota Lanka (Pvt) Ltd", "In Stock");
        createPartIfAbsent("Bosch QuietCast Ceramic Front Brake Pads", "Brake Parts", 25, 8, 7500.0, 11000.0, "Bosch Automotive Lanka", "In Stock");
        createPartIfAbsent("Denso Iridium Power Spark Plugs (Set of 4)", "Ignition", 30, 10, 9500.0, 13500.0, "Toyota Lanka (Pvt) Ltd", "In Stock");
        createPartIfAbsent("Mann Engine Air Filter C25016", "Filters", 35, 10, 2800.0, 4200.0, "United Motors Lanka PLC", "In Stock");
        createPartIfAbsent("Castrol Radicool Premix Long Life Coolant (4L)", "Fluids & Chemicals", 20, 5, 4500.0, 6500.0, "McLarens Lubricants Ltd", "In Stock");
        createPartIfAbsent("Bosch DOT 4 High Performance Brake Fluid (1L)", "Fluids & Chemicals", 40, 12, 1600.0, 2400.0, "Bosch Automotive Lanka", "In Stock");
        createPartIfAbsent("Michelin Primacy 4 Tyres 195/65 R15", "Tyres & Wheels", 16, 8, 26000.0, 34000.0, "United Motors Lanka PLC", "In Stock");
        createPartIfAbsent("Toyota Super Long Life Hybrid Inverter Coolant (2L)", "Hybrid Parts", 18, 6, 5200.0, 7800.0, "Toyota Lanka (Pvt) Ltd", "In Stock");
        createPartIfAbsent("Osram Night Breaker 200 H4 Headlight Bulbs (Pair)", "Electrical", 4, 6, 4800.0, 6800.0, "Bosch Automotive Lanka", "Low Stock");
    }

    private void createPartIfAbsent(String name, String cat, int stock, int minStock, double buyPrice, double sellPrice, String sup, String status) {
        boolean exists = sparePartRepository.findAll().stream().anyMatch(p -> name.equalsIgnoreCase(p.getPartName()));
        if (!exists) {
            SparePart part = new SparePart();
            part.setPartName(name);
            part.setCategory(cat);
            part.setStockQuantity(stock);
            part.setMinStockWarning(minStock);
            part.setBuyingPrice(buyPrice);
            part.setSellingPrice(sellPrice);
            part.setSupplier(sup);
            part.setStatus(status);
            sparePartRepository.save(part);
        }
    }

    // -------------------------------------------------------------------------
    // 8. FUEL PRICES & UNDERGROUND STORAGE TANKS (UST-1 to UST-5)
    // -------------------------------------------------------------------------
    private void seedFuelPricesAndTanks() {
        ensureFuelPrice("Lanka Petrol 92", 340.0, 350.0);
        ensureFuelPrice("Lanka Petrol 95 (Euro 4)", 385.0, 395.0);
        ensureFuelPrice("Lanka Auto Diesel", 325.0, 335.0);
        ensureFuelPrice("Lanka Super Diesel (Euro 4)", 360.0, 370.0);
        ensureFuelPrice("Lanka Kerosene", 230.0, 245.0);

        ensureTank("Lanka Petrol 92", 14500.0, 25000.0, 2500.0, "Ceylon Petroleum Corporation");
        ensureTank("Lanka Petrol 95 (Euro 4)", 10200.0, 20000.0, 2000.0, "Ceylon Petroleum Corporation");
        ensureTank("Lanka Auto Diesel", 18000.0, 30000.0, 3000.0, "Ceylon Petroleum Corporation");
        ensureTank("Lanka Super Diesel (Euro 4)", 9800.0, 18000.0, 1800.0, "Lanka IOC PLC");
        ensureTank("Lanka Kerosene", 4200.0, 10000.0, 1000.0, "Ceylon Petroleum Corporation");
    }

    private void ensureFuelPrice(String fuelType, double current, double previous) {
        FuelPrice fp = fuelPriceRepository.findByFuelType(fuelType).orElseGet(() -> {
            FuelPrice p = new FuelPrice();
            p.setFuelType(fuelType);
            return p;
        });
        fp.setCurrentPrice(current);
        fp.setPreviousPrice(previous);
        fp.setLastUpdated(LocalDateTime.now().minusDays(1));
        fp.setUpdatedBy("Milinda Kalum (Director)");
        fuelPriceRepository.save(fp);
    }

    private void ensureTank(String fuelType, double currentStock, double maxCap, double minWarn, String supplier) {
        FuelInventory inv = fuelInventoryRepository.findByFuelType(fuelType).orElseGet(() -> {
            FuelInventory i = new FuelInventory();
            i.setFuelType(fuelType);
            return i;
        });
        inv.setCurrentStockLitres(currentStock);
        inv.setMaxCapacityLitres(maxCap);
        inv.setMinStockWarning(minWarn);
        inv.setSupplier(supplier);
        inv.setLastDeliveryDate(LocalDateTime.now().minusDays(2));
        inv.setStatus("Normal");
        fuelInventoryRepository.save(inv);
    }

    // -------------------------------------------------------------------------
    // 9. FUEL PUMPS & REALISTIC POS SALES TRANSACTIONS
    // -------------------------------------------------------------------------
    private void seedFuelPumpsAndSales() {
        createPumpIfAbsent("Pump 01", "PUMP-01", "Lanka Petrol 92", "Forecourt Island A - Lane 1", "Lasantha Kumara", 154200.0, 48500.0);
        createPumpIfAbsent("Pump 02", "PUMP-02", "Lanka Petrol 95 (Euro 4)", "Forecourt Island A - Lane 2", "Lasantha Kumara", 98450.0, 62400.0);
        createPumpIfAbsent("Pump 03", "PUMP-03", "Lanka Auto Diesel", "Forecourt Island B - Commercial Lane", "Indika Sampath", 215300.0, 89600.0);
        createPumpIfAbsent("Pump 04", "PUMP-04", "Lanka Super Diesel (Euro 4)", "Forecourt Island B - SUV / Premium Lane", "Indika Sampath", 76800.0, 34200.0);
        createPumpIfAbsent("Pump 05", "PUMP-05", "Lanka Kerosene", "Auxiliary Island C - Domestic Dispenser", "Kamal Fernando", 32100.0, 11500.0);

        // Sales for customer Kasun Dias
        createSaleIfAbsent("REC-890214", "TXN-774129", LocalDateTime.now().minusDays(2).minusHours(3),
                "Pump 01", "Lanka Petrol 92", 35.0, 340.0, 11900.0,
                "Kasun Dias", "customer", "WP CAB-4521", "Visa Card", "Kamal Fernando");

        createSaleIfAbsent("REC-874312", "TXN-761928", LocalDateTime.now().minusDays(6).minusHours(5),
                "Pump 02", "Lanka Petrol 95 (Euro 4)", 40.0, 385.0, 15400.0,
                "Kasun Dias", "customer", "WP CAE-8921", "Fuel Card", "Kamal Fernando");

        // Sales for customer Nuwan Kulasekara
        createSaleIfAbsent("REC-861045", "TXN-751203", LocalDateTime.now().minusDays(10).minusHours(2),
                "Pump 04", "Lanka Super Diesel (Euro 4)", 65.0, 360.0, 23400.0,
                "Nuwan Kulasekara", "customer2", "CP CAA-1020", "MasterCard", "Kamal Fernando");

        createSaleIfAbsent("REC-895101", "TXN-881290", LocalDateTime.now().minusDays(1).minusHours(4),
                "Pump 01", "Lanka Petrol 92", 28.0, 340.0, 9520.0,
                "Nuwan Kulasekara", "customer2", "WP CBB-7788", "Cash", "Kamal Fernando");

        // Sales for other Sri Lankan customers
        createSaleIfAbsent("REC-895102", "TXN-881291", LocalDateTime.now().minusHours(8),
                "Pump 02", "Lanka Petrol 95 (Euro 4)", 45.0, 385.0, 17325.0,
                "Dinesh Chandimal", "dinesh", "WP CBG-9900", "Visa Card", "Sanduni Wickramasinghe");

        createSaleIfAbsent("REC-895103", "TXN-881292", LocalDateTime.now().minusHours(14),
                "Pump 03", "Lanka Auto Diesel", 70.0, 325.0, 22750.0,
                "Tillakaratne Dilshan", "dilshan", "WP PH-3321", "MasterCard", "Kamal Fernando");

        createSaleIfAbsent("REC-895104", "TXN-881293", LocalDateTime.now().minusDays(3).minusHours(2),
                "Pump 01", "Lanka Petrol 92", 30.0, 340.0, 10200.0,
                "Nimal Fernando", "nimal", "WP CBA-5566", "Cash", "Sanduni Wickramasinghe");

        createSaleIfAbsent("REC-895105", "TXN-881294", LocalDateTime.now().minusDays(4).minusHours(6),
                "Pump 03", "Lanka Auto Diesel", 55.0, 325.0, 17875.0,
                "Anura Bandaranaike", "anura", "NW CAD-3344", "Online Wallet", "Kamal Fernando");
    }

    private void createPumpIfAbsent(String name, String number, String fuel, String loc, String op, double meter, double sales) {
        boolean exists = fuelPumpRepository.findAll().stream().anyMatch(p -> number.equalsIgnoreCase(p.getPumpNumber()));
        if (!exists) {
            FuelPump pump = new FuelPump();
            pump.setPumpName(name);
            pump.setPumpNumber(number);
            pump.setFuelType(fuel);
            pump.setLocation(loc);
            pump.setAssignedOperator(op);
            pump.setCurrentMeterReading(meter);
            pump.setOpeningReading(meter - sales / 350.0);
            pump.setClosingReading(meter);
            pump.setTodaysSales(sales);
            pump.setStatus("Active");
            fuelPumpRepository.save(pump);
        }
    }

    private void createSaleIfAbsent(String receiptNo, String txnId, LocalDateTime date, String pump, String fuel,
                                    double litres, double price, double total, String custName, String custUser,
                                    String vehNo, String payMethod, String cashier) {
        if (fuelSaleRepository.findByReceiptNumber(receiptNo).isEmpty()) {
            FuelSale sale = new FuelSale();
            sale.setReceiptNumber(receiptNo);
            sale.setTransactionId(txnId);
            sale.setSaleDate(date);
            sale.setPumpName(pump);
            sale.setFuelType(fuel);
            sale.setQuantityLitres(litres);
            sale.setCurrentPrice(price);
            sale.setUnitPrice(price);
            sale.setTotalAmount(total);
            sale.setCustomerName(custName);
            sale.setCustomerUsername(custUser);
            sale.setVehicleNumber(vehNo);
            sale.setPaymentMethod(payMethod);
            sale.setPaymentStatus("PAID");
            sale.setCashier(cashier);
            fuelSaleRepository.save(sale);
        }
    }

    // -------------------------------------------------------------------------
    // 10. OFFERS & PROMOTIONS
    // -------------------------------------------------------------------------
    private void seedPromotions() {
        createPromoIfAbsent("HYBRIDCARE15", "Hybrid & EV Diagnostic Special",
                "Enjoy 15% off complete hybrid system inspection and cell delta calibration.",
                15.0, 0.0, "Service", LocalDate.now().plusMonths(3), "Save 15%",
                "Valid for all Toyota & Honda hybrid vehicles. Prior appointment required.");

        createPromoIfAbsent("OCTANE95PLUS", "Euro 4 Octane Boost Week",
                "Instant LKR 500 flat discount when dispensing 40 litres or more of Lanka Petrol 95 (Euro 4).",
                0.0, 500.0, "Fuel", LocalDate.now().plusMonths(1), "LKR 500 Off",
                "Valid at Pumps 02 and 04. Limited to one voucher per vehicle per day.");

        createPromoIfAbsent("LUBRICANT10", "Mobil 1 Premium Lube Package",
                "10% discount on synthetic engine oil flush, replacement, and genuine OEM filter installation.",
                10.0, 0.0, "Service", LocalDate.now().plusMonths(2), "10% Off",
                "Applicable with Mobil 1 0W-20 or 5W-30 synthetic lubricants.");

        createPromoIfAbsent("WEEKENDWASH", "Express Underwash & Detailing",
                "Flat LKR 750 rebate when booking Saturday or Sunday full vehicle body underwash & foam detailing.",
                0.0, 750.0, "Wash", LocalDate.now().plusMonths(2), "LKR 750 Rebate",
                "Valid on weekend service bookings at Bay 04.");

        createPromoIfAbsent("MONSOONDRIVE", "Monsoon Brake & Wiper Safety Special",
                "Complimentary 24-point wet-weather safety check and free high-performance washer fluid refill.",
                0.0, 0.0, "Service", LocalDate.now().plusMonths(4), "Complimentary",
                "Included with any periodic service package during the southwest monsoon season.");
    }

    private void createPromoIfAbsent(String code, String title, String desc, double pct, double amt,
                                     String cat, LocalDate until, String badge, String terms) {
        if (promotionRepository.findByCodeIgnoreCase(code).isEmpty()) {
            Promotion p = new Promotion();
            p.setCode(code);
            p.setTitle(title);
            p.setDescription(desc);
            p.setDiscountPercent(pct);
            p.setDiscountAmount(amt);
            p.setCategory(cat);
            p.setValidUntil(until);
            p.setActive(true);
            p.setBadgeText(badge);
            p.setTerms(terms);
            promotionRepository.save(p);
        }
    }

    // -------------------------------------------------------------------------
    // 11. LOYALTY CATALOG & TRANSACTIONS
    // -------------------------------------------------------------------------
    private void seedLoyaltyCatalogAndTransactions() {
        createRewardIfAbsent("Free Premium Foam Car Wash & Vacuum",
                "Complete exterior snow-foam wash, high-pressure undercarriage rinse, and interior vacuuming.",
                300, "CarWash", "bi-droplet-half", "WASH-");

        createRewardIfAbsent("LKR 1,000 Fuel Voucher (40L+ Fill)",
                "Redeemable for LKR 1,000 off any Lanka Petrol 95 or Super Diesel fill of 40L or more.",
                500, "Fuel", "bi-fuel-pump", "FUEL-");

        createRewardIfAbsent("Genuine Engine Oil Filter Replacement",
                "Free genuine Toyota / Honda / Nissan OEM oil filter replacement during your next scheduled service.",
                750, "Service", "bi-funnel", "FILT-");

        createRewardIfAbsent("Computerized 4-Wheel Alignment & Balancing",
                "High-precision laser wheel alignment, steering angle sensor calibration, and wheel balancing.",
                1000, "Service", "bi-gear-wide-connected", "ALIGN-");

        createRewardIfAbsent("LKR 2,500 Full Service Milestone Voucher",
                "Flat LKR 2,500 deduction applied to labor charges on any periodic or comprehensive vehicle maintenance.",
                2000, "Service", "bi-award", "VCH-");

        // Seed customer loyalty transaction history
        if (loyaltyTxRepository.findAll().isEmpty()) {
            createLoyaltyTx("customer", 450, "EARNED", "Earned from Full Hybrid Maintenance Service on WP CAB-4521", null, LocalDateTime.now().minusDays(10));
            createLoyaltyTx("customer", 250, "EARNED", "Earned from Lanka Petrol 95 dispensing (REC-874312)", null, LocalDateTime.now().minusDays(6));
            createLoyaltyTx("customer", -300, "REDEEMED", "Redeemed for Free Premium Foam Car Wash Voucher", "WASH-88129", LocalDateTime.now().minusDays(4));
            createLoyaltyTx("customer", 1050, "EARNED", "Welcome bonus and accumulated past periodic service milestones", null, LocalDateTime.now().minusMonths(2));

            createLoyaltyTx("customer2", 600, "EARNED", "Earned from 4WD Periodic Maintenance on CP CAA-1020", null, LocalDateTime.now().minusDays(14));
            createLoyaltyTx("customer2", 220, "EARNED", "Earned from Lanka Super Diesel dispensing (REC-861045)", null, LocalDateTime.now().minusDays(10));

            createLoyaltyTx("chamari", 1950, "EARNED", "EV Maintenance Package & Fast Charging session rewards", null, LocalDateTime.now().minusDays(8));
        }
    }

    private void createRewardIfAbsent(String title, String desc, int pts, String cat, String icon, String prefix) {
        boolean exists = loyaltyRewardRepository.findAll().stream().anyMatch(r -> title.equalsIgnoreCase(r.getTitle()));
        if (!exists) {
            LoyaltyReward r = new LoyaltyReward();
            r.setTitle(title);
            r.setDescription(desc);
            r.setPointsRequired(pts);
            r.setCategory(cat);
            r.setIcon(icon);
            r.setActive(true);
            r.setVoucherPrefix(prefix);
            loyaltyRewardRepository.save(r);
        }
    }

    private void createLoyaltyTx(String username, int points, String type, String desc, String code, LocalDateTime date) {
        LoyaltyTransaction tx = new LoyaltyTransaction();
        tx.setCustomerUsername(username);
        tx.setPoints(points);
        tx.setType(type);
        tx.setDescription(desc);
        tx.setVoucherCode(code);
        tx.setTransactionDate(date);
        loyaltyTxRepository.save(tx);
    }

    // -------------------------------------------------------------------------
    // 12. SERVICE BOOKINGS, JOB CARDS, INVOICES & PAYMENTS WORKFLOW
    // -------------------------------------------------------------------------
    private void seedServiceBookingsWorkflow() {
        LocalDate today = LocalDate.now();

        // ---------------------------------------------------------------------
        // Workflow Case 1: Completed Major Service for customer Kasun Dias (WP CAB-4521)
        // Customer Journey: Booked -> Assigned -> In Progress -> Completed -> Paid -> Feedback
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "INV-2026-0811".equals(b.getNotes()) || ("WP CAB-4521".equals(b.getLicensePlate()) && "Completed".equals(b.getStatus())))) {
            ServiceBooking b1 = new ServiceBooking();
            b1.setLicensePlate("WP CAB-4521");
            b1.setCustomerName("Kasun Dias");
            b1.setCustomerUsername("customer");
            b1.setCustomerPhone("+94 77 123 4567");
            b1.setServiceDate(today.minusDays(10));
            b1.setTimeSlot("09:00 AM");
            b1.setServiceType("Full Service");
            b1.setStatus("Completed");
            b1.setTrackingStage("Completed");
            b1.setEstimatedCost(24500.0);
            b1.setEstimatedDuration("3.5 Hours");
            b1.setProblemDescription("100,000 km major service, hybrid cooling fan inspection, and brake caliper cleaning.");
            b1.setNotes("Completed on schedule. All 28 hybrid cell blocks within factory voltage tolerances.");
            b1 = bookingRepository.save(b1);

            JobCard jc1 = new JobCard();
            jc1.setBookingId(b1.getId());
            jc1.setLicensePlate("WP CAB-4521");
            jc1.setCustomerName("Kasun Dias");
            jc1.setMechanicName("Nimal Jayawardena");
            jc1.setBayName("Bay 02 - Hybrid & EV Diagnostics Center");
            jc1.setServiceType("Full Service");
            jc1.setStatus("Completed");
            jc1.setMechanicNotes("Hybrid diagnostic sweep completed. Cell voltages balanced within 0.02V delta. Inverter coolant renewed. Front brake pads 65% remaining.");
            jc1.setPartsUsed("Mobil 1 0W-20 (4L), Toyota Genuine Oil Filter, Toyota Hybrid Inverter Coolant (2L)");
            jc1 = jobCardRepository.save(jc1);

            Invoice inv1 = new Invoice();
            inv1.setBookingId(b1.getId());
            inv1.setInvoiceNo("INV-2026-0811");
            inv1.setInvoiceName("Full Hybrid Maintenance - WP CAB-4521");
            inv1.setCustomerName("Kasun Dias");
            inv1.setCustomerUsername("customer");
            inv1.setLicensePlate("WP CAB-4521");
            inv1.setInvoiceDate(today.minusDays(10));
            inv1.setDueDate(today.minusDays(10));
            inv1.setGrossTotalAmount(24500.0);
            inv1.setConvenienceFee(250.0);
            inv1.setNetTotal(24750.0);
            inv1.setAmountPaid(24750.0);
            inv1.setStatus("PAID");
            inv1.setNotes("Settled via Credit Card at Counter 2. e-Receipt generated.");
            inv1 = invoiceRepository.save(inv1);

            PaymentRecord pr1 = new PaymentRecord();
            pr1.setInvoiceId(inv1.getId());
            pr1.setPaymentDate(today.minusDays(10));
            pr1.setPaidOccupant("Kasun Dias");
            pr1.setCustomerUsername("customer");
            pr1.setPaymentMethod("Credit Card");
            pr1.setAmount(24750.0);
            pr1.setStatus("SUCCESS");
            pr1.setTransactionRef("TXN-CC-884102");
            pr1.setNotes("Visa Card ending in 4102 approved. POS Slip #9812.");
            paymentRepository.save(pr1);

            CustomerFeedback fb1 = new CustomerFeedback();
            fb1.setJobCardId(jc1.getId());
            fb1.setCustomerName("Kasun Dias");
            fb1.setServiceType("Full Service");
            fb1.setRating(5);
            fb1.setComments("Exceptional hybrid service! Fuel efficiency increased noticeably after the inverter coolant flush and ECU tune. Highly recommend Master Tech Nimal.");
            fb1.setNeedsAttention(false);
            fb1.setSubmissionDate(LocalDateTime.now().minusDays(9));
            feedbackRepository.save(fb1);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 2: Completed 4WD Service for Nuwan Kulasekara (CP CAA-1020)
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "CP CAA-1020".equals(b.getLicensePlate()) && "Completed".equals(b.getStatus()))) {
            ServiceBooking b2 = new ServiceBooking();
            b2.setLicensePlate("CP CAA-1020");
            b2.setCustomerName("Nuwan Kulasekara");
            b2.setCustomerUsername("customer2");
            b2.setCustomerPhone("+94 71 987 6543");
            b2.setServiceDate(today.minusDays(14));
            b2.setTimeSlot("10:30 AM");
            b2.setServiceType("Full Service");
            b2.setStatus("Completed");
            b2.setTrackingStage("Completed");
            b2.setEstimatedCost(38000.0);
            b2.setEstimatedDuration("4.0 Hours");
            b2.setProblemDescription("Periodic 4WD transmission and differential oil replacement with suspension check.");
            b2.setNotes("4x4 transfer case inspected. Front and rear differential fluid flushed.");
            b2 = bookingRepository.save(b2);

            JobCard jc2 = new JobCard();
            jc2.setBookingId(b2.getId());
            jc2.setLicensePlate("CP CAA-1020");
            jc2.setCustomerName("Nuwan Kulasekara");
            jc2.setMechanicName("Ruwan Thushara");
            jc2.setBayName("Bay 01 - Heavy Hydraulic Lift");
            jc2.setServiceType("Full Service");
            jc2.setStatus("Completed");
            jc2.setMechanicNotes("Differential fluids drained and refilled. Transfer case seals in pristine condition. Multi-point check passed.");
            jc2.setPartsUsed("Castrol 80W-90 Axle Fluid (3L), Mann Air Filter, Genuine Toyota Oil Filter");
            jc2 = jobCardRepository.save(jc2);

            Invoice inv2 = new Invoice();
            inv2.setBookingId(b2.getId());
            inv2.setInvoiceNo("INV-2026-0792");
            inv2.setInvoiceName("Comprehensive 4WD Service - CP CAA-1020");
            inv2.setCustomerName("Nuwan Kulasekara");
            inv2.setCustomerUsername("customer2");
            inv2.setLicensePlate("CP CAA-1020");
            inv2.setInvoiceDate(today.minusDays(14));
            inv2.setDueDate(today.minusDays(14));
            inv2.setGrossTotalAmount(38000.0);
            inv2.setConvenienceFee(300.0);
            inv2.setNetTotal(38300.0);
            inv2.setAmountPaid(38300.0);
            inv2.setStatus("PAID");
            inv2.setNotes("Settled via Online Wallet. Automatic receipt delivered.");
            inv2 = invoiceRepository.save(inv2);

            PaymentRecord pr2 = new PaymentRecord();
            pr2.setInvoiceId(inv2.getId());
            pr2.setPaymentDate(today.minusDays(14));
            pr2.setPaidOccupant("Nuwan Kulasekara");
            pr2.setCustomerUsername("customer2");
            pr2.setPaymentMethod("Online Wallet");
            pr2.setAmount(38300.0);
            pr2.setStatus("SUCCESS");
            pr2.setTransactionRef("TXN-WL-912044");
            pr2.setNotes("eZ Cash payment confirmed. Approval #77192.");
            paymentRepository.save(pr2);

            CustomerFeedback fb2 = new CustomerFeedback();
            fb2.setJobCardId(jc2.getId());
            fb2.setCustomerName("Nuwan Kulasekara");
            fb2.setServiceType("Full Service");
            fb2.setRating(5);
            fb2.setComments("Very smooth ride after the 40,000 km service. Great attention to detail on the Prado by technician Ruwan.");
            fb2.setNeedsAttention(false);
            fb2.setSubmissionDate(LocalDateTime.now().minusDays(13));
            feedbackRepository.save(fb2);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 3: Completed Quick Lube Service for Nimal Fernando (WP CBA-5566)
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP CBA-5566".equals(b.getLicensePlate()) && "Completed".equals(b.getStatus()))) {
            ServiceBooking b3 = new ServiceBooking();
            b3.setLicensePlate("WP CBA-5566");
            b3.setCustomerName("Nimal Fernando");
            b3.setCustomerUsername("nimal");
            b3.setCustomerPhone("+94 76 345 6789");
            b3.setServiceDate(today.minusDays(7));
            b3.setTimeSlot("02:00 PM");
            b3.setServiceType("Oil Change");
            b3.setStatus("Completed");
            b3.setTrackingStage("Completed");
            b3.setEstimatedCost(12500.0);
            b3.setEstimatedDuration("1.5 Hours");
            b3.setProblemDescription("Regular 5,000km lube service and multi-point visual inspection.");
            b3.setNotes("Engine oil change completed. Tyre pressures adjusted to 32 psi.");
            b3 = bookingRepository.save(b3);

            JobCard jc3 = new JobCard();
            jc3.setBookingId(b3.getId());
            jc3.setLicensePlate("WP CBA-5566");
            jc3.setCustomerName("Nimal Fernando");
            jc3.setMechanicName("Asanka Priyadarshana");
            jc3.setBayName("Bay 03 - Express Lube & Brake Service");
            jc3.setServiceType("Oil Change");
            jc3.setStatus("Completed");
            jc3.setMechanicNotes("Clean oil drain, new gasket installed, washer fluid refilled.");
            jc3.setPartsUsed("Mobil Super 2000 5W-30 (3.5L), Genuine Hyundai Filter");
            jc3 = jobCardRepository.save(jc3);

            Invoice inv3 = new Invoice();
            inv3.setBookingId(b3.getId());
            inv3.setInvoiceNo("INV-2026-0845");
            inv3.setInvoiceName("Express Lube Service - WP CBA-5566");
            inv3.setCustomerName("Nimal Fernando");
            inv3.setCustomerUsername("nimal");
            inv3.setLicensePlate("WP CBA-5566");
            inv3.setInvoiceDate(today.minusDays(7));
            inv3.setDueDate(today.minusDays(7));
            inv3.setGrossTotalAmount(12500.0);
            inv3.setConvenienceFee(0.0);
            inv3.setNetTotal(12500.0);
            inv3.setAmountPaid(12500.0);
            inv3.setStatus("PAID");
            inv3.setNotes("Settled in Cash at counter.");
            inv3 = invoiceRepository.save(inv3);

            PaymentRecord pr3 = new PaymentRecord();
            pr3.setInvoiceId(inv3.getId());
            pr3.setPaymentDate(today.minusDays(7));
            pr3.setPaidOccupant("Nimal Fernando");
            pr3.setCustomerUsername("nimal");
            pr3.setPaymentMethod("Cash");
            pr3.setAmount(12500.0);
            pr3.setStatus("SUCCESS");
            pr3.setTransactionRef("TXN-CSH-441208");
            paymentRepository.save(pr3);

            CustomerFeedback fb3 = new CustomerFeedback();
            fb3.setJobCardId(jc3.getId());
            fb3.setCustomerName("Nimal Fernando");
            fb3.setServiceType("Oil Change");
            fb3.setRating(4);
            fb3.setComments("Fast and courteous turnaround. Completed in under 60 minutes as promised.");
            fb3.setNeedsAttention(false);
            fb3.setSubmissionDate(LocalDateTime.now().minusDays(6));
            feedbackRepository.save(fb3);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 4: Completed Heavy Suspension Service for Tillakaratne Dilshan (WP PH-3321)
        // With partial refund audit demonstration
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP PH-3321".equals(b.getLicensePlate()) && "Completed".equals(b.getStatus()))) {
            ServiceBooking b4 = new ServiceBooking();
            b4.setLicensePlate("WP PH-3321");
            b4.setCustomerName("Tillakaratne Dilshan");
            b4.setCustomerUsername("dilshan");
            b4.setCustomerPhone("+94 72 678 9012");
            b4.setServiceDate(today.minusDays(5));
            b4.setTimeSlot("08:30 AM");
            b4.setServiceType("Periodic Maintenance");
            b4.setStatus("Completed");
            b4.setTrackingStage("Completed");
            b4.setEstimatedCost(42000.0);
            b4.setEstimatedDuration("4.5 Hours");
            b4.setProblemDescription("Heavy duty suspension overhaul and propeller shaft greasing.");
            b4.setNotes("Replaced front stabilizer link bushes and lower arm bushings.");
            b4 = bookingRepository.save(b4);

            JobCard jc4 = new JobCard();
            jc4.setBookingId(b4.getId());
            jc4.setLicensePlate("WP PH-3321");
            jc4.setCustomerName("Tillakaratne Dilshan");
            jc4.setMechanicName("Nimal Jayawardena");
            jc4.setBayName("Bay 01 - Heavy Hydraulic Lift");
            jc4.setServiceType("Periodic Maintenance");
            jc4.setStatus("Completed");
            jc4.setMechanicNotes("Suspension alignment verified on laser rig. Road test confirmed zero clunking noise.");
            jc4.setPartsUsed("OEM Polyurethane Bush Set, Heavy Chassis Greasing");
            jc4 = jobCardRepository.save(jc4);

            Invoice inv4 = new Invoice();
            inv4.setBookingId(b4.getId());
            inv4.setInvoiceNo("INV-2026-0870");
            inv4.setInvoiceName("Suspension Overhaul - WP PH-3321");
            inv4.setCustomerName("Tillakaratne Dilshan");
            inv4.setCustomerUsername("dilshan");
            inv4.setLicensePlate("WP PH-3321");
            inv4.setInvoiceDate(today.minusDays(5));
            inv4.setDueDate(today.minusDays(5));
            inv4.setGrossTotalAmount(42000.0);
            inv4.setConvenienceFee(350.0);
            inv4.setNetTotal(42350.0);
            inv4.setAmountPaid(42350.0);
            inv4.setStatus("PAID");
            inv4.setNotes("Settled via Bank Transfer. Transaction receipt verified.");
            inv4 = invoiceRepository.save(inv4);

            PaymentRecord pr4a = new PaymentRecord();
            pr4a.setInvoiceId(inv4.getId());
            pr4a.setPaymentDate(today.minusDays(5));
            pr4a.setPaidOccupant("Tillakaratne Dilshan");
            pr4a.setCustomerUsername("dilshan");
            pr4a.setPaymentMethod("Bank Transfer");
            pr4a.setAmount(42350.0);
            pr4a.setStatus("SUCCESS");
            pr4a.setTransactionRef("TXN-BT-309112");
            paymentRepository.save(pr4a);

            PaymentRecord pr4b = new PaymentRecord();
            pr4b.setInvoiceId(inv4.getId());
            pr4b.setPaymentDate(today.minusDays(4));
            pr4b.setPaidOccupant("Tillakaratne Dilshan");
            pr4b.setCustomerUsername("dilshan");
            pr4b.setPaymentMethod("Bank Transfer");
            pr4b.setAmount(5000.0);
            pr4b.setStatus("REFUNDED");
            pr4b.setTransactionRef("TXN-REF-100234");
            pr4b.setNotes("Promotional loyalty cashback applied retroactively by manager.");
            paymentRepository.save(pr4b);

            CustomerFeedback fb4 = new CustomerFeedback();
            fb4.setJobCardId(jc4.getId());
            fb4.setCustomerName("Tillakaratne Dilshan");
            fb4.setServiceType("Periodic Maintenance");
            fb4.setRating(5);
            fb4.setComments("Top-tier suspension work on my Hilux. Handling on rough plantation roads is rock solid now.");
            fb4.setNeedsAttention(false);
            fb4.setSubmissionDate(LocalDateTime.now().minusDays(4));
            feedbackRepository.save(fb4);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 5: ACTIVE SERVICE IN PROGRESS on Bay 02 for Kasun Dias (WP CAE-8921)
        // Ready for UI demonstration: Tracking, JobCard updates, and Billing payment!
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP CAE-8921".equals(b.getLicensePlate()) && "In Progress".equals(b.getStatus()))) {
            ServiceBooking b5 = new ServiceBooking();
            b5.setLicensePlate("WP CAE-8921");
            b5.setCustomerName("Kasun Dias");
            b5.setCustomerUsername("customer");
            b5.setCustomerPhone("+94 77 123 4567");
            b5.setServiceDate(today);
            b5.setTimeSlot("09:30 AM");
            b5.setServiceType("Full Service");
            b5.setStatus("In Progress");
            b5.setTrackingStage("Repair / Service");
            b5.setEstimatedCost(28500.0);
            b5.setEstimatedDuration("3.0 Hours");
            b5.setProblemDescription("Slight clutch judder when accelerating in 1st gear and squealing front brake pads.");
            b5.setNotes("DCT actuator software relearn in progress on Bay 02.");
            b5 = bookingRepository.save(b5);

            JobCard jc5 = new JobCard();
            jc5.setBookingId(b5.getId());
            jc5.setLicensePlate("WP CAE-8921");
            jc5.setCustomerName("Kasun Dias");
            jc5.setMechanicName("Ruwan Thushara");
            jc5.setBayName("Bay 02 - Hybrid & EV Diagnostics Center");
            jc5.setServiceType("Full Service");
            jc5.setStatus("In Progress");
            jc5.setMechanicNotes("DCT actuator software relearn completed. Currently replacing front brake pads with Bosch ceramic pads.");
            jc5.setPartsUsed("Bosch QuietCast Ceramic Front Brake Pads, Honda Ultra ATF DW-1 (2L)");
            jc5 = jobCardRepository.save(jc5);

            Invoice inv5 = new Invoice();
            inv5.setBookingId(b5.getId());
            inv5.setInvoiceNo("INV-2026-0902");
            inv5.setInvoiceName("DCT Calibration & Brake Service - WP CAE-8921");
            inv5.setCustomerName("Kasun Dias");
            inv5.setCustomerUsername("customer");
            inv5.setLicensePlate("WP CAE-8921");
            inv5.setInvoiceDate(today);
            inv5.setDueDate(today);
            inv5.setGrossTotalAmount(28500.0);
            inv5.setConvenienceFee(250.0);
            inv5.setNetTotal(28750.0);
            inv5.setAmountPaid(0.0);
            inv5.setStatus("PENDING");
            inv5.setNotes("Awaiting customer payment via customer portal or cashier counter.");
            invoiceRepository.save(inv5);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 6: ASSIGNED SERVICE on Bay 01 for Dinesh Chandimal (WP CBG-9900)
        // Ready for Mechanic to start and update JobCard!
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP CBG-9900".equals(b.getLicensePlate()) && "Assigned".equals(b.getStatus()))) {
            ServiceBooking b6 = new ServiceBooking();
            b6.setLicensePlate("WP CBG-9900");
            b6.setCustomerName("Dinesh Chandimal");
            b6.setCustomerUsername("dinesh");
            b6.setCustomerPhone("+94 75 890 1234");
            b6.setServiceDate(today);
            b6.setTimeSlot("11:00 AM");
            b6.setServiceType("Full Service");
            b6.setStatus("Assigned");
            b6.setTrackingStage("Inspection");
            b6.setEstimatedCost(35000.0);
            b6.setEstimatedDuration("2.5 Hours");
            b6.setProblemDescription("Condition Based Servicing amber reminder on iDrive dashboard.");
            b6.setNotes("Vehicle checked into workshop bay.");
            b6 = bookingRepository.save(b6);

            JobCard jc6 = new JobCard();
            jc6.setBookingId(b6.getId());
            jc6.setLicensePlate("WP CBG-9900");
            jc6.setCustomerName("Dinesh Chandimal");
            jc6.setMechanicName("Nimal Jayawardena");
            jc6.setBayName("Bay 01 - Heavy Hydraulic Lift");
            jc6.setServiceType("Full Service");
            jc6.setStatus("Pending");
            jc6.setMechanicNotes("Vehicle positioned on lift for OBD-II scan and multi-point pre-check.");
            jc6.setPartsUsed("Mobil 1 ESP 5W-30 (5.5L), Mann Microfilter");
            jobCardRepository.save(jc6);

            Invoice inv6 = new Invoice();
            inv6.setBookingId(b6.getId());
            inv6.setInvoiceNo("INV-2026-0915");
            inv6.setInvoiceName("BMW CBS Service - WP CBG-9900");
            inv6.setCustomerName("Dinesh Chandimal");
            inv6.setCustomerUsername("dinesh");
            inv6.setLicensePlate("WP CBG-9900");
            inv6.setInvoiceDate(today);
            inv6.setDueDate(today);
            inv6.setGrossTotalAmount(35000.0);
            inv6.setConvenienceFee(300.0);
            inv6.setNetTotal(35300.0);
            inv6.setAmountPaid(0.0);
            inv6.setStatus("PENDING");
            invoiceRepository.save(inv6);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 7: APPROVED SERVICE for Nuwan Kulasekara (WP CBB-7788)
        // Ready for Admin to assign bay and mechanic!
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP CBB-7788".equals(b.getLicensePlate()) && "Approved".equals(b.getStatus()))) {
            ServiceBooking b7 = new ServiceBooking();
            b7.setLicensePlate("WP CBB-7788");
            b7.setCustomerName("Nuwan Kulasekara");
            b7.setCustomerUsername("customer2");
            b7.setCustomerPhone("+94 71 987 6543");
            b7.setServiceDate(today.plusDays(1));
            b7.setTimeSlot("02:30 PM");
            b7.setServiceType("Full Service");
            b7.setStatus("Approved");
            b7.setTrackingStage("Vehicle Received");
            b7.setEstimatedCost(8500.0);
            b7.setEstimatedDuration("1.0 Hour");
            b7.setProblemDescription("Musty odor from AC vents when starting in the morning.");
            b7.setNotes("Approved for Bay 03 or 04 inspection tomorrow.");
            b7 = bookingRepository.save(b7);

            Invoice inv7 = new Invoice();
            inv7.setBookingId(b7.getId());
            inv7.setInvoiceNo("INV-2026-0920");
            inv7.setInvoiceName("Air Conditioning Disinfection - WP CBB-7788");
            inv7.setCustomerName("Nuwan Kulasekara");
            inv7.setCustomerUsername("customer2");
            inv7.setLicensePlate("WP CBB-7788");
            inv7.setInvoiceDate(today.plusDays(1));
            inv7.setDueDate(today.plusDays(1));
            inv7.setGrossTotalAmount(8500.0);
            inv7.setConvenienceFee(100.0);
            inv7.setNetTotal(8600.0);
            inv7.setAmountPaid(0.0);
            inv7.setStatus("PENDING");
            invoiceRepository.save(inv7);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 8: PENDING BOOKINGS for Admin / Manager to review and approve
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "SP KX-9912".equals(b.getLicensePlate()))) {
            ServiceBooking b8 = new ServiceBooking();
            b8.setLicensePlate("SP KX-9912");
            b8.setCustomerName("Chamari Athapaththu");
            b8.setCustomerUsername("chamari");
            b8.setCustomerPhone("+94 77 567 8901");
            b8.setServiceDate(today.plusDays(2));
            b8.setTimeSlot("10:00 AM");
            b8.setServiceType("Full Service");
            b8.setStatus("Pending");
            b8.setTrackingStage("Inspection");
            b8.setEstimatedCost(16000.0);
            b8.setEstimatedDuration("2.0 Hours");
            b8.setProblemDescription("Quarterly EV high voltage battery health diagnostic check and LeafSpy report.");
            bookingRepository.save(b8);
        }

        if (bookingRepository.findAll().stream().noneMatch(b -> "NW CAD-3344".equals(b.getLicensePlate()))) {
            ServiceBooking b9 = new ServiceBooking();
            b9.setLicensePlate("NW CAD-3344");
            b9.setCustomerName("Anura Bandaranaike");
            b9.setCustomerUsername("anura");
            b9.setCustomerPhone("+94 70 234 5678");
            b9.setServiceDate(today.plusDays(3));
            b9.setTimeSlot("01:30 PM");
            b9.setServiceType("Periodic Maintenance");
            b9.setStatus("Pending");
            b9.setTrackingStage("Inspection");
            b9.setEstimatedCost(19500.0);
            b9.setEstimatedDuration("2.5 Hours");
            b9.setProblemDescription("Rough idle on cold mornings. Requesting injector cleaning and diesel fuel filter renewal.");
            bookingRepository.save(b9);
        }

        // ---------------------------------------------------------------------
        // Workflow Case 9: CANCELLED BOOKING to demonstrate cancellation filter
        // ---------------------------------------------------------------------
        if (bookingRepository.findAll().stream().noneMatch(b -> "WP BAF-1234".equals(b.getLicensePlate()))) {
            ServiceBooking b10 = new ServiceBooking();
            b10.setLicensePlate("WP BAF-1234");
            b10.setCustomerName("Chathura Senanayake");
            b10.setCustomerUsername("chathura");
            b10.setCustomerPhone("+94 78 456 7890");
            b10.setServiceDate(today.minusDays(12));
            b10.setTimeSlot("03:00 PM");
            b10.setServiceType("Full Service");
            b10.setStatus("Cancelled");
            b10.setTrackingStage("Inspection");
            b10.setEstimatedCost(6000.0);
            b10.setEstimatedDuration("1.0 Hour");
            b10.setNotes("Customer rescheduled due to personal travel outside Colombo.");
            bookingRepository.save(b10);
        }

        // ---------------------------------------------------------------------
        // Additional Invoices demonstrating OVERDUE and PARTIAL status filtering
        // ---------------------------------------------------------------------
        if (invoiceRepository.findByInvoiceNo("INV-2026-0750").isEmpty()) {
            Invoice invOverdue = new Invoice();
            invOverdue.setInvoiceNo("INV-2026-0750");
            invOverdue.setInvoiceName("Scheduled Tune-Up - WP BAF-1234");
            invOverdue.setCustomerName("Chathura Senanayake");
            invOverdue.setCustomerUsername("chathura");
            invOverdue.setLicensePlate("WP BAF-1234");
            invOverdue.setInvoiceDate(today.minusDays(25));
            invOverdue.setDueDate(today.minusDays(15));
            invOverdue.setGrossTotalAmount(14000.0);
            invOverdue.setConvenienceFee(200.0);
            invOverdue.setNetTotal(14200.0);
            invOverdue.setAmountPaid(0.0);
            invOverdue.setStatus("OVERDUE");
            invOverdue.setNotes("Payment reminder SMS and email notification dispatched.");
            invoiceRepository.save(invOverdue);
        }

        if (invoiceRepository.findByInvoiceNo("INV-2026-0880").isEmpty()) {
            Invoice invPartial = new Invoice();
            invPartial.setInvoiceNo("INV-2026-0880");
            invPartial.setInvoiceName("Montero Transfer Case Repair - NW CAD-3344");
            invPartial.setCustomerName("Anura Bandaranaike");
            invPartial.setCustomerUsername("anura");
            invPartial.setLicensePlate("NW CAD-3344");
            invPartial.setInvoiceDate(today.minusDays(3));
            invPartial.setDueDate(today.plusDays(7));
            invPartial.setGrossTotalAmount(22000.0);
            invPartial.setConvenienceFee(0.0);
            invPartial.setNetTotal(22000.0);
            invPartial.setAmountPaid(10000.0);
            invPartial.setStatus("PARTIAL");
            invPartial.setNotes("Advance deposit of LKR 10,000 received. Balance payable on vehicle handover.");
            invPartial = invoiceRepository.save(invPartial);

            PaymentRecord prPart = new PaymentRecord();
            prPart.setInvoiceId(invPartial.getId());
            prPart.setPaymentDate(today.minusDays(3));
            prPart.setPaidOccupant("Anura Bandaranaike");
            prPart.setCustomerUsername("anura");
            prPart.setPaymentMethod("Cash");
            prPart.setAmount(10000.0);
            prPart.setStatus("SUCCESS");
            prPart.setTransactionRef("TXN-DEP-00921");
            prPart.setNotes("Initial cash deposit against Invoice INV-2026-0880.");
            paymentRepository.save(prPart);
        }
    }

    // -------------------------------------------------------------------------
    // 13. CUSTOMER SUPPORT TICKETS
    // -------------------------------------------------------------------------
    private void seedSupportTickets() {
        createTicketIfAbsent("TCK-4821", "customer", "Kasun Dias", "kasun@gmail.com", "+94 77 123 4567",
                "Requesting copy of Hybrid Cell Voltage Diagnostic Graph", "Booking", "Medium",
                "Hello FuelCore team, could you please share the computerized graph of the individual cell voltages for my Prius (CAB-4521) from the recent 100k service? Thank you.",
                "RESOLVED", "Diagnostic graph has been uploaded to your vehicle records in your Customer Dashboard. All 28 cell blocks show exemplary balance at 0.02V delta.",
                LocalDateTime.now().minusDays(9), LocalDateTime.now().minusDays(8));

        createTicketIfAbsent("TCK-5104", "customer2", "Nuwan Kulasekara", "nuwan@gmail.com", "+94 71 987 6543",
                "Inquiry regarding Lanka Super Diesel Euro 4 cetane rating certificate", "FuelBilling", "Low",
                "Good day, does your station provide CPC laboratory certification for Euro 4 Super Diesel cetane index? Required for my Prado emission warranty.",
                "RESOLVED", "Yes, our monthly CPC Quality Compliance Certificate is displayed at the forecourt cashier desk and confirms a cetane index above 51.5. A digital copy has also been sent to your email.",
                LocalDateTime.now().minusDays(7), LocalDateTime.now().minusDays(6));

        createTicketIfAbsent("TCK-5310", "chamari", "Chamari Athapaththu", "chamari.a@gmail.com", "+94 77 567 8901",
                "EV Battery check appointment rescheduling request", "Booking", "Medium",
                "Hi, I would like to confirm if I can reschedule my upcoming EV service from 10:00 AM to 02:00 PM due to cricket training schedule.",
                "OPEN", null,
                LocalDateTime.now().minusHours(5), null);
    }

    private void createTicketIfAbsent(String ticketNo, String username, String name, String email, String phone,
                                      String subject, String cat, String priority, String msg, String status,
                                      String reply, LocalDateTime created, LocalDateTime resolved) {
        boolean exists = supportTicketRepository.findAll().stream().anyMatch(t -> ticketNo.equalsIgnoreCase(t.getTicketNumber()));
        if (!exists) {
            SupportTicket t = new SupportTicket();
            t.setTicketNumber(ticketNo);
            t.setCustomerUsername(username);
            t.setCustomerName(name);
            t.setCustomerEmail(email);
            t.setCustomerPhone(phone);
            t.setSubject(subject);
            t.setCategory(cat);
            t.setPriority(priority);
            t.setMessage(msg);
            t.setStatus(status);
            t.setAdminReply(reply);
            t.setCreatedDate(created);
            t.setResolvedDate(resolved);
            supportTicketRepository.save(t);
        }
    }

    // -------------------------------------------------------------------------
    // 14. SYSTEM & CUSTOMER NOTIFICATIONS
    // -------------------------------------------------------------------------
    private void seedNotifications() {
        createNotificationIfAbsent("Service Completed - Ready for Collection",
                "Your Toyota Prius (WP CAB-4521) has successfully passed all quality checks and is ready for pickup at Bay 02.",
                "Booking", "Read", LocalDateTime.now().minusDays(10), "customer", "/customer/services", "bi-check2-circle");

        createNotificationIfAbsent("New Invoice INV-2026-0902 Generated",
                "Invoice INV-2026-0902 for LKR 28,750 has been generated for your ongoing DCT service on WP CAE-8921.",
                "Billing", "Unread", LocalDateTime.now().minusHours(2), "customer", "/customer/billing", "bi-receipt");

        createNotificationIfAbsent("Loyalty Points Credited (+250 Pts)",
                "Congratulations! You have earned 250 FuelCore loyalty points for your recent fuel purchase. Total balance: 1,450 pts.",
                "Loyalty", "Unread", LocalDateTime.now().minusDays(6), "customer", "/customer/offers", "bi-star-fill");

        createNotificationIfAbsent("Prado 4WD Maintenance Completed",
                "Your Toyota Land Cruiser Prado (CP CAA-1020) maintenance is finished. All fluids refreshed.",
                "Booking", "Read", LocalDateTime.now().minusDays(14), "customer2", "/customer/services", "bi-check2-circle");

        createNotificationIfAbsent("Special Offer: 15% Off Hybrid Care",
                "Unlock 15% discount on all hybrid battery and cooling checks this month using code HYBRIDCARE15.",
                "Offer", "Unread", LocalDateTime.now().minusDays(1), "customer2", "/customer/offers", "bi-tag-fill");

        createNotificationIfAbsent("Underground Storage Tank UST-3 Replenished",
                "Tank UST-3 received 15,000L of Lanka Auto Diesel from Ceylon Petroleum Corporation. Density and quality tested ok.",
                "Inventory", "Read", LocalDateTime.now().minusDays(1), null, "/fuel-inventory", "bi-fuel-pump");

        createNotificationIfAbsent("Low Stock Alert: Osram Headlight Bulbs",
                "Osram Night Breaker H4 bulbs have reached minimum stock threshold (4 units remaining). Reorder recommended.",
                "Alert", "Unread", LocalDateTime.now().minusHours(6), null, "/spare-parts", "bi-exclamation-triangle-fill");
    }

    private void createNotificationIfAbsent(String title, String msg, String type, String status,
                                            LocalDateTime date, String user, String url, String icon) {
        boolean exists = notificationRepository.findAll().stream().anyMatch(n -> title.equalsIgnoreCase(n.getTitle()) && (user == null || user.equalsIgnoreCase(n.getRecipientUsername())));
        if (!exists) {
            Notification n = new Notification();
            n.setTitle(title);
            n.setMessage(msg);
            n.setType(type);
            n.setStatus(status);
            n.setCreatedDate(date);
            n.setRecipientUsername(user);
            n.setActionUrl(url);
            n.setIcon(icon);
            notificationRepository.save(n);
        }
    }

    // -------------------------------------------------------------------------
    // 15. AUDIT LOGS (ADMIN SECURITY TRAIL)
    // -------------------------------------------------------------------------
    private void seedAuditLogs() {
        if (auditLogRepository.findAll().stream().noneMatch(a -> "INVENTORY_DELIVERY".equals(a.getAction()))) {
            createAuditLog("USER_LOGIN", "admin", "Admin", "Admin logged in successfully from workstation 192.168.1.10", "SUCCESS", LocalDateTime.now().minusHours(10));
            createAuditLog("PRICE_UPDATE", "admin", "Admin", "Updated Lanka Petrol 95 tariff board from 395.0 to 385.0 LKR", "SUCCESS", LocalDateTime.now().minusDays(1));
            createAuditLog("INVENTORY_DELIVERY", "manager", "Manager", "Received 15,000L Lanka Auto Diesel bulk tanker delivery (CPC Kolonnawa)", "SUCCESS", LocalDateTime.now().minusDays(2));
            createAuditLog("BOOKING_APPROVED", "manager", "Manager", "Approved service appointment for WP CBB-7788 (Nuwan Kulasekara)", "SUCCESS", LocalDateTime.now().minusHours(8));
            createAuditLog("PAYMENT_RECEIVED", "cashier", "Cashier", "Processed card payment LKR 24,750 for Invoice INV-2026-0811", "SUCCESS", LocalDateTime.now().minusDays(10));
            createAuditLog("REFUND_ISSUED", "admin", "Admin", "Authorized promotional adjustment refund LKR 5,000 on INV-2026-0870", "SUCCESS", LocalDateTime.now().minusDays(4));
            createAuditLog("USER_LOGIN", "customer", "Customer", "Customer Kasun Dias logged in via web portal", "SUCCESS", LocalDateTime.now().minusHours(2));
        }
    }

    private void createAuditLog(String action, String username, String role, String details, String status, LocalDateTime ts) {
        AuditLog logEntry = AuditLog.builder()
                .action(action)
                .username(username)
                .userRole(role)
                .details(details)
                .ipAddress("192.168.1.10")
                .status(status)
                .timestamp(ts)
                .build();
        auditLogRepository.save(logEntry);
    }
}
