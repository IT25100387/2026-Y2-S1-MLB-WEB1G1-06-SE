package com.fuelstation.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(UserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder);
        return authProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, DaoAuthenticationProvider authenticationProvider) throws Exception {
        http
            .authenticationProvider(authenticationProvider)
            .authorizeHttpRequests(auth -> auth
                // Static Assets & Public Pages
                .requestMatchers("/css/**", "/images/**", "/js/**", "/favicon.ico", "/login", "/signup", "/forgot-password", "/reset-password", "/error").permitAll()
                
                // User & Role Management & Audit (Admin, Manager)
                .requestMatchers("/users/**").hasRole("ADMIN")
                .requestMatchers("/customers/**", "/admin/**", "/audit-logs/**").hasAnyRole("ADMIN", "MANAGER")
                
                // Customer Portal (Customer, Admin)
                .requestMatchers("/customer/**").hasAnyRole("CUSTOMER", "ADMIN")

                // Fuel Tariffs (Customer, Cashier, Manager, Admin)
                .requestMatchers("/prices/**").hasAnyRole("ADMIN", "MANAGER", "CASHIER", "CUSTOMER")

                // Fuel & Inventory (Admin, Manager, Cashier)
                .requestMatchers("/sales/**", "/pumps/**", "/inventory/**", "/spare-parts/**")
                    .hasAnyRole("ADMIN", "MANAGER", "CASHIER")
                
                // Workshop & Service Operations (Admin, Manager, Mechanic)
                .requestMatchers("/workshop/**")
                    .hasAnyRole("ADMIN", "MANAGER", "MECHANIC")
                
                // Billing, Invoices & Suppliers (Admin, Manager, Cashier)
                .requestMatchers("/invoices/**", "/payments/**", "/suppliers/**", "/reports/**")
                    .hasAnyRole("ADMIN", "MANAGER", "CASHIER")
                
                // Staff & Shift Management (Admin, Manager, Cashier, Mechanic)
                .requestMatchers("/staff/**", "/shifts/**", "/leave/**", "/attendance/**")
                    .hasAnyRole("ADMIN", "MANAGER", "CASHIER", "MECHANIC")
                
                // Vehicles & Bookings & Feedback (Admin, Manager, Mechanic, Customer)
                .requestMatchers("/vehicles/**", "/bookings/**", "/service-history/**", "/feedback/**")
                    .hasAnyRole("ADMIN", "MANAGER", "MECHANIC", "CUSTOMER")
                
                // Dashboard & General Operations (All Authenticated Users)
                .requestMatchers("/", "/dashboard", "/notifications/**", "/settings/**", "/switch-role").authenticated()
                
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .usernameParameter("username")
                .passwordParameter("password")
                .defaultSuccessUrl("/", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            )
            .csrf(csrf -> csrf.disable()); // Form CSRF disabled for smooth multi-role demo forms

        return http.build();
    }
}
