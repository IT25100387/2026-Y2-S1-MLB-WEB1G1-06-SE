package com.fuelstation.service;

import com.fuelstation.model.LoyaltyReward;
import com.fuelstation.model.LoyaltyTransaction;
import java.util.List;

public interface LoyaltyService {
    List<LoyaltyReward> getActiveRewards();
    List<LoyaltyTransaction> getCustomerHistory(String customerUsername);
    int getCustomerPoints(String customerUsername);
    String getCustomerTier(String customerUsername);
    void awardPoints(String customerUsername, int points, String description);
    String redeemReward(String customerUsername, Long rewardId);
}
