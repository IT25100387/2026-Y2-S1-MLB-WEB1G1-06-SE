package com.fuelstation.service;

import com.fuelstation.model.CustomerFeedback;
import com.fuelstation.model.JobCard;
import com.fuelstation.model.ServiceBay;
import com.fuelstation.model.Staff;

import java.util.List;
import java.util.Optional;

public interface WorkshopService {
    List<JobCard> getAllJobCards();
    Optional<JobCard> getJobCardById(Long id);
    Optional<JobCard> getJobCardByBookingId(Long bookingId);
    JobCard createJobCard(Long bookingId, Long mechanicId, Long bayId);
    JobCard updateJobCard(Long id, String status, String mechanicNotes, String partsUsed);
    
    List<ServiceBay> getAllBays();
    ServiceBay addBay(ServiceBay bay);
    
    List<Staff> getAvailableMechanics();
    
    List<CustomerFeedback> getAllFeedbacks();
    CustomerFeedback submitFeedback(CustomerFeedback feedback);
}
