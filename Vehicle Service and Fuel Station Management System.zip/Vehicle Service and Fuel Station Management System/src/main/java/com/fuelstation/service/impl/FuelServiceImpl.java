package com.fuelstation.service.impl;

import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelPrice;
import com.fuelstation.model.FuelPump;
import com.fuelstation.model.FuelSale;
import com.fuelstation.repository.FuelInventoryRepository;
import com.fuelstation.repository.FuelPriceRepository;
import com.fuelstation.repository.FuelPumpRepository;
import com.fuelstation.repository.FuelSaleRepository;
import com.fuelstation.model.AppUser;
import com.fuelstation.model.Vehicle;
import com.fuelstation.service.FuelService;
import com.fuelstation.service.UserService;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
public class FuelServiceImpl implements FuelService {

    @Autowired
    private FuelSaleRepository saleRepository;

    @Autowired
    private FuelInventoryRepository inventoryRepository;

    @Autowired
    private FuelPumpRepository pumpRepository;

    @Autowired
    private FuelPriceRepository priceRepository;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private UserService userService;

    @Override
    @Transactional
    public FuelSale recordSale(FuelSale sale) {
        if (sale.getSaleDate() == null) {
            sale.setSaleDate(LocalDateTime.now());
        }

        if (sale.getReceiptNumber() == null || sale.getReceiptNumber().trim().isEmpty()) {
            sale.setReceiptNumber("REC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }

        if (sale.getPaymentStatus() == null || sale.getPaymentStatus().trim().isEmpty()) {
            sale.setPaymentStatus("PAID");
        }

        if (sale.getTransactionId() == null || sale.getTransactionId().trim().isEmpty()) {
            sale.setTransactionId("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }

        if (sale.getUnitPrice() == null && sale.getCurrentPrice() != null) {
            sale.setUnitPrice(sale.getCurrentPrice());
        } else if (sale.getCurrentPrice() == null && sale.getUnitPrice() != null) {
            sale.setCurrentPrice(sale.getUnitPrice());
        }

        // Find inventory for this fuel type
        FuelInventory inventory = inventoryRepository.findByFuelType(sale.getFuelType())
                .orElse(null);

        if (inventory != null) {
            // Check stock
            if (inventory.getCurrentStockLitres() < sale.getQuantityLitres()) {
                throw new RuntimeException("Insufficient fuel stock. Available: " + inventory.getCurrentStockLitres() + " L, Requested: " + sale.getQuantityLitres() + " L");
            }

            // Reduce stock
            inventory.setCurrentStockLitres(inventory.getCurrentStockLitres() - sale.getQuantityLitres());

            // Update status if below warning threshold
            if (inventory.getCurrentStockLitres() <= inventory.getMinStockWarning()) {
                inventory.setStatus("Low Stock");
            }

            inventoryRepository.save(inventory);
        }

        return saleRepository.save(sale);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FuelSale> getAllSales() {
        return saleRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public double getTotalRevenue() {
        return saleRepository.findAll().stream()
                .mapToDouble(s -> s.getTotalAmount() != null ? s.getTotalAmount() : 0.0)
                .sum();
    }

    @Override
    @Transactional(readOnly = true)
    public List<FuelPump> getAllPumps() {
        return pumpRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<FuelPump> getPumpById(Long id) {
        return pumpRepository.findById(id);
    }

    @Override
    @Transactional
    public FuelPump savePump(FuelPump pump) {
        if (pump.getStatus() == null || pump.getStatus().trim().isEmpty()) {
            pump.setStatus("Active");
        }
        return pumpRepository.save(pump);
    }

    @Override
    @Transactional
    public void deletePump(Long id) {
        pumpRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public long getPumpsCount() {
        return pumpRepository.count();
    }

    @Override
    @Transactional(readOnly = true)
    public List<FuelInventory> getAllInventories() {
        return inventoryRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<FuelInventory> getInventoryById(Long id) {
        return inventoryRepository.findById(id);
    }

    @Override
    @Transactional
    public FuelInventory saveInventory(FuelInventory inventory) {
        if (inventory.getStatus() == null || inventory.getStatus().trim().isEmpty()) {
            inventory.setStatus("Normal");
        }
        return inventoryRepository.save(inventory);
    }

    @Override
    @Transactional
    public void deleteInventory(Long id) {
        inventoryRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FuelPrice> getAllPrices() {
        return priceRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<FuelPrice> getPriceById(Long id) {
        return priceRepository.findById(id);
    }

    @Override
    @Transactional
    public FuelPrice savePrice(FuelPrice price) {
        if (price.getLastUpdated() == null) {
            price.setLastUpdated(LocalDateTime.now());
        }
        return priceRepository.save(price);
    }

    @Override
    @Transactional
    public void deletePrice(Long id) {
        priceRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<FuelSale> getSaleById(Long id) {
        return saleRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FuelSale> getCustomerFuelPurchases(String username) {
        if (username == null || username.trim().isEmpty()) {
            return List.of();
        }

        // Fetch owned vehicles for plate matching
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);
        List<String> vehiclePlates = customerVehicles.stream()
                .map(v -> v.getLicensePlate() != null ? v.getLicensePlate().trim().toUpperCase() : null)
                .filter(Objects::nonNull)
                .toList();

        // Fetch customer's full name
        String displayName = username;
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getFullName() != null && !userOpt.get().getFullName().isBlank()) {
            displayName = userOpt.get().getFullName().trim();
        }

        boolean hasPlates = !vehiclePlates.isEmpty();
        return saleRepository.findCustomerPurchases(
                username,
                displayName,
                hasPlates,
                hasPlates ? vehiclePlates : List.of("__NONE__")
        );
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isSaleAccessibleByCustomer(FuelSale sale, String username) {
        if (sale == null || username == null || username.trim().isEmpty()) {
            return false;
        }

        // Admin has universal operational oversight
        if ("admin".equalsIgnoreCase(username)) {
            return true;
        }

        // 1. Direct customer username match
        if (sale.getCustomerUsername() != null && sale.getCustomerUsername().equalsIgnoreCase(username)) {
            return true;
        }

        // 2. Vehicle license plate match against customer's garage
        List<Vehicle> customerVehicles = vehicleService.getVehiclesByOwner(username);
        if (sale.getVehicleNumber() != null && !sale.getVehicleNumber().trim().isEmpty()) {
            String salePlate = sale.getVehicleNumber().trim().toUpperCase();
            boolean plateMatch = customerVehicles.stream().anyMatch(v ->
                    v.getLicensePlate() != null && v.getLicensePlate().trim().equalsIgnoreCase(salePlate)
            );
            if (plateMatch) {
                return true;
            }
        }

        // 3. Customer full name match
        Optional<AppUser> userOpt = userService.getUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getFullName() != null && !userOpt.get().getFullName().isBlank()) {
            String fullName = userOpt.get().getFullName().trim();
            if (sale.getCustomerName() != null && sale.getCustomerName().trim().equalsIgnoreCase(fullName)) {
                return true;
            }
        }

        // 4. Customer username in customerName field
        if (sale.getCustomerName() != null && sale.getCustomerName().trim().equalsIgnoreCase(username)) {
            return true;
        }

        return false;
    }

    @Override
    @Transactional
    public void seedDefaultFuelDataIfEmpty() {
        // Ensure all 4 standard Sri Lankan fuel grades exist in price board
        ensureFuelPrice("Lanka Petrol 92", 340.0, 350.0);
        ensureFuelPrice("Lanka Petrol 95 (Euro 4)", 385.0, 395.0);
        ensureFuelPrice("Lanka Auto Diesel", 325.0, 335.0);
        ensureFuelPrice("Lanka Super Diesel (Euro 4)", 360.0, 370.0);

        // Ensure matching fuel tank inventories exist
        ensureFuelInventory("Lanka Petrol 92", 14500.0, 25000.0, 2500.0);
        ensureFuelInventory("Lanka Petrol 95 (Euro 4)", 10200.0, 20000.0, 2000.0);
        ensureFuelInventory("Lanka Auto Diesel", 18000.0, 30000.0, 3000.0);
        ensureFuelInventory("Lanka Super Diesel (Euro 4)", 9800.0, 18000.0, 1800.0);

        // Ensure dispensing pumps exist
        ensureFuelPump("Pump 01", "PUMP-01", "Lanka Petrol 92");
        ensureFuelPump("Pump 02", "PUMP-02", "Lanka Petrol 95 (Euro 4)");
        ensureFuelPump("Pump 03", "PUMP-03", "Lanka Auto Diesel");
        ensureFuelPump("Pump 04", "PUMP-04", "Lanka Super Diesel (Euro 4)");

        // Seed initial sample fuel sales if not already present
        if (saleRepository.findByReceiptNumber("REC-890214").isEmpty()) {
            // Customer 1 ("customer", Kasun Dias) purchases
            FuelSale s1 = new FuelSale();
            s1.setReceiptNumber("REC-890214");
            s1.setTransactionId("TXN-774129");
            s1.setSaleDate(LocalDateTime.now().minusDays(2).minusHours(3));
            s1.setPumpName("Pump 01");
            s1.setFuelType("Lanka Petrol 92");
            s1.setQuantityLitres(35.0);
            s1.setCurrentPrice(340.0);
            s1.setUnitPrice(340.0);
            s1.setTotalAmount(11900.0);
            s1.setCustomerUsername("customer");
            s1.setCustomerName("Kasun Dias");
            s1.setVehicleNumber("CAB-4521");
            s1.setPaymentMethod("Visa Card");
            s1.setPaymentStatus("PAID");
            s1.setCashier("Kamal Fernando");
            saleRepository.save(s1);

            FuelSale s2 = new FuelSale();
            s2.setReceiptNumber("REC-874312");
            s2.setTransactionId("TXN-761928");
            s2.setSaleDate(LocalDateTime.now().minusDays(6).minusHours(5));
            s2.setPumpName("Pump 02");
            s2.setFuelType("Lanka Petrol 95 (Euro 4)");
            s2.setQuantityLitres(40.0);
            s2.setCurrentPrice(385.0);
            s2.setUnitPrice(385.0);
            s2.setTotalAmount(15400.0);
            s2.setCustomerUsername("customer");
            s2.setCustomerName("Kasun Dias");
            s2.setVehicleNumber("WP-CAE-8921");
            s2.setPaymentMethod("Fuel Card");
            s2.setPaymentStatus("PAID");
            s2.setCashier("Kamal Fernando");
            saleRepository.save(s2);

            FuelSale s3 = new FuelSale();
            s3.setReceiptNumber("REC-861045");
            s3.setTransactionId("TXN-752103");
            s3.setSaleDate(LocalDateTime.now().minusDays(12).minusHours(1));
            s3.setPumpName("Pump 01");
            s3.setFuelType("Lanka Petrol 92");
            s3.setQuantityLitres(28.5);
            s3.setCurrentPrice(340.0);
            s3.setUnitPrice(340.0);
            s3.setTotalAmount(9690.0);
            s3.setCustomerUsername("customer");
            s3.setCustomerName("Kasun Dias");
            s3.setVehicleNumber("CAB-4521");
            s3.setPaymentMethod("Cash");
            s3.setPaymentStatus("PAID");
            s3.setCashier("Kamal Fernando");
            saleRepository.save(s3);

            // Customer 2 purchase (for data isolation testing)
            FuelSale s4 = new FuelSale();
            s4.setReceiptNumber("REC-771234");
            s4.setTransactionId("TXN-661298");
            s4.setSaleDate(LocalDateTime.now().minusDays(1));
            s4.setPumpName("Pump 04");
            s4.setFuelType("Lanka Super Diesel (Euro 4)");
            s4.setQuantityLitres(50.0);
            s4.setCurrentPrice(360.0);
            s4.setUnitPrice(360.0);
            s4.setTotalAmount(18000.0);
            s4.setCustomerUsername("customer2");
            s4.setCustomerName("Nuwan Kulasekara");
            s4.setVehicleNumber("WP-KQ-9988");
            s4.setPaymentMethod("MasterCard");
            s4.setPaymentStatus("PAID");
            s4.setCashier("Kamal Fernando");
            saleRepository.save(s4);
        }
    }

    private void ensureFuelPrice(String fuelType, Double currentPrice, Double previousPrice) {
        Optional<FuelPrice> opt = priceRepository.findByFuelTypeIgnoreCase(fuelType);
        if (opt.isEmpty()) {
            FuelPrice p = new FuelPrice();
            p.setFuelType(fuelType);
            p.setCurrentPrice(currentPrice);
            p.setPreviousPrice(previousPrice);
            p.setLastUpdated(LocalDateTime.now().minusDays(1));
            p.setUpdatedBy("Admin (Pricing Committee)");
            priceRepository.save(p);
        }
    }

    private void ensureFuelInventory(String fuelType, Double stock, Double maxCap, Double minWarning) {
        Optional<FuelInventory> opt = inventoryRepository.findByFuelType(fuelType);
        if (opt.isEmpty()) {
            FuelInventory inv = new FuelInventory();
            inv.setFuelType(fuelType);
            inv.setCurrentStockLitres(stock);
            inv.setMaxCapacityLitres(maxCap);
            inv.setMinStockWarning(minWarning);
            inv.setStatus("Normal");
            inventoryRepository.save(inv);
        }
    }

    private void ensureFuelPump(String name, String number, String fuelType) {
        boolean exists = pumpRepository.findAll().stream()
                .anyMatch(p -> name.equalsIgnoreCase(p.getPumpName()) || number.equalsIgnoreCase(p.getPumpNumber()));
        if (!exists) {
            FuelPump pump = new FuelPump();
            pump.setPumpName(name);
            pump.setPumpNumber(number);
            pump.setFuelType(fuelType);
            pump.setStatus("Active");
            pumpRepository.save(pump);
        }
    }
}
