package com.fuelstation.service.impl;

import com.fuelstation.model.Promotion;
import com.fuelstation.repository.PromotionRepository;
import com.fuelstation.service.PromotionService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PromotionServiceImpl implements PromotionService {

    @Autowired
    private PromotionRepository promotionRepository;

    @PostConstruct
    public void initDefaultPromotions() {
        if (promotionRepository.count() == 0) {
            Promotion p1 = new Promotion();
            p1.setCode("FUELGOLD10");
            p1.setTitle("10% Off Super Diesel & Octane 95 Refuels");
            p1.setDescription("Exclusive seasonal fuel discount on premium grade fuels for all registered FuelCore members.");
            p1.setDiscountPercent(10.0);
            p1.setCategory("Fuel");
            p1.setValidUntil(LocalDate.now().plusMonths(2));
            p1.setActive(true);
            p1.setBadgeText("POPULAR");
            p1.setTerms("Valid on minimum 20 Litre refuel. Single use per vehicle per week.");
            promotionRepository.save(p1);

            Promotion p2 = new Promotion();
            p2.setCode("SERVICE20");
            p2.setTitle("20% Off Full Mechanical Vehicle Service");
            p2.setDescription("Complete 50-point bumper-to-bumper vehicle inspection, computerized diagnostics, and fluid check.");
            p2.setDiscountPercent(20.0);
            p2.setCategory("Service");
            p2.setValidUntil(LocalDate.now().plusMonths(3));
            p2.setActive(true);
            p2.setBadgeText("LIMITED TIME");
            p2.setTerms("Applicable to Full Service bookings made via customer portal.");
            promotionRepository.save(p2);

            Promotion p3 = new Promotion();
            p3.setCode("SPARKWASH");
            p3.setTitle("Complimentary Foam Wash & Underbody Flush");
            p3.setDescription("Free automated undercarriage cleaning and ceramic shampoo foam wash with any general workshop repair.");
            p3.setDiscountAmount(2500.0);
            p3.setCategory("Wash");
            p3.setValidUntil(LocalDate.now().plusMonths(1));
            p3.setActive(true);
            p3.setBadgeText("COMPLIMENTARY");
            p3.setTerms("Redeemable at Bay 4 wash station after workshop service completion.");
            promotionRepository.save(p3);

            Promotion p4 = new Promotion();
            p4.setCode("SYNTHETIC500");
            p4.setTitle("LKR 500 Instant Voucher on Full Synthetic Oil");
            p4.setDescription("Direct cash rebate on genuine 5W-30 and 0W-20 OEM Mobil & Castrol synthetic engine lubricant cans.");
            p4.setDiscountAmount(500.0);
            p4.setCategory("Service");
            p4.setValidUntil(LocalDate.now().plusMonths(2));
            p4.setActive(true);
            p4.setBadgeText("BEST VALUE");
            p4.setTerms("Valid when engine oil change package is booked online.");
            promotionRepository.save(p4);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<Promotion> getActivePromotions() {
        return promotionRepository.findByActiveTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Promotion> getAllPromotions() {
        return promotionRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Promotion> getPromotionById(Long id) {
        return promotionRepository.findById(id);
    }

    @Override
    @Transactional
    public Promotion savePromotion(Promotion promotion) {
        if (promotion.getActive() == null) {
            promotion.setActive(true);
        }
        if (promotion.getCode() != null) {
            promotion.setCode(promotion.getCode().trim().toUpperCase());
        }
        return promotionRepository.save(promotion);
    }

    @Override
    @Transactional
    public void togglePromotion(Long id) {
        promotionRepository.findById(id).ifPresent(p -> {
            p.setActive(p.getActive() == null || !p.getActive());
            promotionRepository.save(p);
        });
    }

    @Override
    @Transactional
    public void deletePromotion(Long id) {
        promotionRepository.deleteById(id);
    }
}
