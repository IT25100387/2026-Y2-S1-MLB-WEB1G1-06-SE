package com.fuelstation.service;

import com.fuelstation.model.FuelSale;
import com.fuelstation.model.Invoice;
import com.fuelstation.model.PaymentRecord;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;

@Service
public class PdfReceiptService {

    private static final Color GOLD_ACCENT = new Color(217, 119, 6); // #D97706
    private static final Color CHARCOAL = new Color(30, 41, 59);     // #1E293B
    private static final Color LIGHT_BG = new Color(248, 250, 252);   // #F8FAFC
    private static final Color BORDER_COLOR = new Color(226, 232, 240); // #E2E8F0
    private static final Color GREEN_STATUS = new Color(22, 101, 52); // #166534

    public byte[] generateFuelReceiptPdf(FuelSale sale) {
        Document document = new Document(PageSize.A5, 28, 28, 28, 28);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Font definitions
            Font brandFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, GOLD_ACCENT);
            Font headerSub = FontFactory.getFont(FontFactory.HELVETICA, 8, CHARCOAL);
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, CHARCOAL);
            Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, CHARCOAL);
            Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 9, CHARCOAL);
            Font boldValueFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, CHARCOAL);
            Font totalFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, GOLD_ACCENT);
            Font statusFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, GREEN_STATUS);
            Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 7, Color.GRAY);

            // --- HEADER ---
            Paragraph brandPara = new Paragraph("FUELCORE ENERGY & PETROLEUM", brandFont);
            brandPara.setAlignment(Element.ALIGN_CENTER);
            document.add(brandPara);

            Paragraph subtitlePara = new Paragraph(
                    "High Level Road Terminal, Station #04, Colombo, Sri Lanka\n" +
                    "Tel: +94 11 234 5678 | Email: support@fuelcore.lk | Tax Reg: LK-VAT-892147",
                    headerSub
            );
            subtitlePara.setAlignment(Element.ALIGN_CENTER);
            subtitlePara.setSpacingAfter(8);
            document.add(subtitlePara);

            LineSeparator sep = new LineSeparator(1, 100, BORDER_COLOR, Element.ALIGN_CENTER, -2);
            document.add(sep);

            Paragraph docTitle = new Paragraph("OFFICIAL FUEL TRANSACTION E-RECEIPT", titleFont);
            docTitle.setAlignment(Element.ALIGN_CENTER);
            docTitle.setSpacingBefore(8);
            docTitle.setSpacingAfter(10);
            document.add(docTitle);

            // --- TRANSACTION DETAILS TABLE ---
            PdfPTable metaTable = new PdfPTable(2);
            metaTable.setWidthPercentage(100);
            metaTable.setWidths(new float[]{1f, 1f});

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String saleDateStr = sale.getSaleDate() != null ? sale.getSaleDate().format(dtf) : "N/A";
            String receiptNo = sale.getReceiptNumber() != null ? sale.getReceiptNumber() : "REC-000000";
            String txnId = sale.getEffectiveTransactionId();
            String pumpName = sale.getPumpName() != null ? sale.getPumpName() : "Dispenser 01";
            String cashier = sale.getCashier() != null ? sale.getCashier() : "Automated Forecourt Station";
            String custName = sale.getCustomerName() != null ? sale.getCustomerName() : "Valued Customer";
            String vehNo = sale.getVehicleNumber() != null && !sale.getVehicleNumber().trim().isEmpty()
                    ? sale.getVehicleNumber().trim().toUpperCase() : "Direct Fill (Unassigned)";
            String payMethod = sale.getPaymentMethod() != null ? sale.getPaymentMethod() : "Electronic Card";
            String payStatus = sale.getEffectivePaymentStatus();

            PdfPCell c1 = new PdfPCell();
            c1.setBorder(Rectangle.NO_BORDER);
            c1.addElement(new Paragraph("Receipt No: " + receiptNo, boldValueFont));
            c1.addElement(new Paragraph("Transaction ID: " + txnId, valueFont));
            c1.addElement(new Paragraph("Date & Time: " + saleDateStr, valueFont));
            c1.addElement(new Paragraph("Dispenser: " + pumpName, valueFont));
            c1.addElement(new Paragraph("Operator/Cashier: " + cashier, valueFont));
            metaTable.addCell(c1);

            PdfPCell c2 = new PdfPCell();
            c2.setBorder(Rectangle.NO_BORDER);
            c2.addElement(new Paragraph("Customer: " + custName, boldValueFont));
            c2.addElement(new Paragraph("Vehicle Plate: " + vehNo, valueFont));
            c2.addElement(new Paragraph("Payment Method: " + payMethod, valueFont));
            c2.addElement(new Paragraph("Payment Status: " + payStatus + " (VERIFIED)", statusFont));
            metaTable.addCell(c2);

            document.add(metaTable);

            // Spacing
            Paragraph pSpace = new Paragraph(" ");
            pSpace.setSpacingBefore(4);
            document.add(pSpace);

            // --- LINE ITEMS TABLE ---
            PdfPTable itemTable = new PdfPTable(4);
            itemTable.setWidthPercentage(100);
            itemTable.setWidths(new float[]{3.5f, 1.5f, 2f, 2f});
            itemTable.setSpacingBefore(6);

            // Header row
            addTableHeader(itemTable, "Fuel Grade / Item", labelFont);
            addTableHeader(itemTable, "Quantity", labelFont);
            addTableHeader(itemTable, "Unit Rate", labelFont);
            addTableHeader(itemTable, "Amount (LKR)", labelFont);

            // Fuel row
            double qty = sale.getQuantityLitres() != null ? sale.getQuantityLitres() : 0.0;
            double unitRate = sale.getEffectiveUnitPrice();
            double total = sale.getTotalAmount() != null ? sale.getTotalAmount() : (qty * unitRate);

            String fuelType = sale.getFuelType() != null ? sale.getFuelType() : "Standard Petroleum";

            addTableRow(itemTable, fuelType, valueFont, Element.ALIGN_LEFT);
            addTableRow(itemTable, String.format("%.2f L", qty), valueFont, Element.ALIGN_RIGHT);
            addTableRow(itemTable, String.format("Rs. %.2f", unitRate), valueFont, Element.ALIGN_RIGHT);
            addTableRow(itemTable, String.format("Rs. %.2f", total), boldValueFont, Element.ALIGN_RIGHT);

            document.add(itemTable);

            // --- FINANCIAL SUMMARY TABLE ---
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(100);
            summaryTable.setWidths(new float[]{2.5f, 1.5f});
            summaryTable.setSpacingBefore(8);

            addSummaryRow(summaryTable, "Fuel Subtotal:", String.format("Rs. %.2f", total), valueFont, false);
            addSummaryRow(summaryTable, "Government Fuel Excise/Tax (Included):", "Rs. 0.00", valueFont, false);
            addSummaryRow(summaryTable, "Net Amount Paid:", String.format("Rs. %.2f", total), totalFont, true);

            document.add(summaryTable);

            // --- FOOTER & VERIFICATION ---
            document.add(new Paragraph(" "));
            document.add(sep);

            Paragraph footerPara = new Paragraph(
                    "Thank you for choosing FuelCore! Drive safe.\n" +
                    "This is an official computer-generated e-receipt valid under Sri Lanka CPC guidelines.\n" +
                    "For tax and corporate expense claims, verify at https://fuelcore.lk/verify/" + receiptNo,
                    footerFont
            );
            footerPara.setAlignment(Element.ALIGN_CENTER);
            footerPara.setSpacingBefore(8);
            document.add(footerPara);

            document.close();
        } catch (DocumentException e) {
            throw new RuntimeException("Error generating PDF receipt: " + e.getMessage(), e);
        }

        return out.toByteArray();
    }

    private void addTableHeader(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(LIGHT_BG);
        cell.setBorderColor(BORDER_COLOR);
        cell.setPadding(6);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(cell);
    }

    private void addTableRow(PdfPTable table, String text, Font font, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBorderColor(BORDER_COLOR);
        cell.setPadding(6);
        cell.setHorizontalAlignment(alignment);
        table.addCell(cell);
    }

    private void addSummaryRow(PdfPTable table, String label, String value, Font font, boolean isTotal) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, font));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        labelCell.setPadding(3);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, font));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        valueCell.setPadding(3);

        if (isTotal) {
            labelCell.setBorder(Rectangle.TOP);
            valueCell.setBorder(Rectangle.TOP);
            labelCell.setBorderColor(BORDER_COLOR);
            valueCell.setBorderColor(BORDER_COLOR);
            labelCell.setPaddingTop(6);
            valueCell.setPaddingTop(6);
        }

        table.addCell(labelCell);
        table.addCell(valueCell);
    }

    public byte[] generateInvoicePdf(Invoice invoice, java.util.List<PaymentRecord> payments) {
        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Font brandFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, GOLD_ACCENT);
            Font headerSub = FontFactory.getFont(FontFactory.HELVETICA, 8, CHARCOAL);
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, CHARCOAL);
            Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, CHARCOAL);
            Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 9, CHARCOAL);
            Font boldValueFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, CHARCOAL);
            Font totalFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, GOLD_ACCENT);
            Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 8, Color.GRAY);

            // --- HEADER ---
            Paragraph brandPara = new Paragraph("FUELCORE ENTERPRISE STATION OS", brandFont);
            brandPara.setAlignment(Element.ALIGN_CENTER);
            document.add(brandPara);

            Paragraph subtitlePara = new Paragraph(
                    "High Level Road Terminal, Station #04, Colombo, Sri Lanka\n" +
                    "Tel: +94 11 234 5678 | Email: billing@fuelcore.lk | Tax Reg: LK-VAT-892147",
                    headerSub
            );
            subtitlePara.setAlignment(Element.ALIGN_CENTER);
            subtitlePara.setSpacingAfter(10);
            document.add(subtitlePara);

            LineSeparator sep = new LineSeparator(1, 100, BORDER_COLOR, Element.ALIGN_CENTER, -2);
            document.add(sep);

            Paragraph docTitle = new Paragraph("OFFICIAL SERVICE INVOICE & TAX RECEIPT", titleFont);
            docTitle.setAlignment(Element.ALIGN_CENTER);
            docTitle.setSpacingBefore(10);
            docTitle.setSpacingAfter(14);
            document.add(docTitle);

            // --- INVOICE & CLIENT INFO (2 Columns) ---
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setWidths(new float[]{1f, 1f});

            PdfPCell leftCell = new PdfPCell();
            leftCell.setBorder(Rectangle.NO_BORDER);
            leftCell.addElement(new Paragraph("Invoice No: " + invoice.getInvoiceNo(), boldValueFont));
            leftCell.addElement(new Paragraph("Date Issued: " + (invoice.getInvoiceDate() != null ? invoice.getInvoiceDate().toString() : "-"), valueFont));
            leftCell.addElement(new Paragraph("Due Date: " + (invoice.getDueDate() != null ? invoice.getDueDate().toString() : "-"), valueFont));
            leftCell.addElement(new Paragraph("Status: " + invoice.getStatus(), boldValueFont));
            infoTable.addCell(leftCell);

            PdfPCell rightCell = new PdfPCell();
            rightCell.setBorder(Rectangle.NO_BORDER);
            rightCell.addElement(new Paragraph("Billed To: " + (invoice.getCustomerName() != null ? invoice.getCustomerName() : "Valued Customer"), boldValueFont));
            if (invoice.getCustomerUsername() != null) {
                rightCell.addElement(new Paragraph("Account ID: @" + invoice.getCustomerUsername(), valueFont));
            }
            if (invoice.getLicensePlate() != null) {
                rightCell.addElement(new Paragraph("Vehicle Reg: " + invoice.getLicensePlate(), valueFont));
            }
            if (invoice.getReferenceNo() != null) {
                rightCell.addElement(new Paragraph("Reference No: " + invoice.getReferenceNo(), valueFont));
            }
            infoTable.addCell(rightCell);
            document.add(infoTable);

            document.add(new Paragraph(" "));

            // --- LINE ITEMS TABLE ---
            PdfPTable itemsTable = new PdfPTable(4);
            itemsTable.setWidthPercentage(100);
            itemsTable.setWidths(new float[]{4f, 2f, 1.5f, 2.5f});

            addTableCell(itemsTable, "Description", labelFont, LIGHT_BG, Element.ALIGN_LEFT);
            addTableCell(itemsTable, "Reference", labelFont, LIGHT_BG, Element.ALIGN_CENTER);
            addTableCell(itemsTable, "Qty / Unit", labelFont, LIGHT_BG, Element.ALIGN_CENTER);
            addTableCell(itemsTable, "Amount (LKR)", labelFont, LIGHT_BG, Element.ALIGN_RIGHT);

            String desc = invoice.getInvoiceName() != null ? invoice.getInvoiceName() : "Automotive Maintenance & Fuel Service";
            String ref = invoice.getReferenceNo() != null ? invoice.getReferenceNo() : "-";
            double gross = invoice.getGrossTotalAmount() != null ? invoice.getGrossTotalAmount() : 0.0;
            double fee = invoice.getConvenienceFee() != null ? invoice.getConvenienceFee() : 0.0;
            double net = invoice.getNetTotal() != null ? invoice.getNetTotal() : gross + fee;
            double paid = invoice.getAmountPaid() != null ? invoice.getAmountPaid() : 0.0;
            double balance = Math.max(0.0, net - paid);

            addTableCell(itemsTable, desc, valueFont, Color.WHITE, Element.ALIGN_LEFT);
            addTableCell(itemsTable, ref, valueFont, Color.WHITE, Element.ALIGN_CENTER);
            addTableCell(itemsTable, "1", valueFont, Color.WHITE, Element.ALIGN_CENTER);
            addTableCell(itemsTable, String.format("%,.2f", gross), valueFont, Color.WHITE, Element.ALIGN_RIGHT);

            document.add(itemsTable);

            // --- FINANCIAL SUMMARY TABLE ---
            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(45);
            summaryTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
            summaryTable.setSpacingBefore(12);

            addSummaryRow(summaryTable, "Subtotal:", String.format("LKR %,.2f", gross), labelFont, false);
            if (fee > 0.0) {
                addSummaryRow(summaryTable, "Convenience Fee:", String.format("LKR %,.2f", fee), labelFont, false);
            }
            addSummaryRow(summaryTable, "Net Total:", String.format("LKR %,.2f", net), totalFont, true);
            addSummaryRow(summaryTable, "Amount Paid:", String.format("LKR %,.2f", paid), labelFont, false);
            addSummaryRow(summaryTable, "Balance Due:", String.format("LKR %,.2f", balance), boldValueFont, false);

            document.add(summaryTable);

            // --- PAYMENTS BREAKDOWN (IF ANY) ---
            if (payments != null && !payments.isEmpty()) {
                Paragraph payTitle = new Paragraph("PAYMENT SETTLEMENT HISTORY", labelFont);
                payTitle.setSpacingBefore(16);
                payTitle.setSpacingAfter(6);
                document.add(payTitle);

                PdfPTable payTable = new PdfPTable(4);
                payTable.setWidthPercentage(100);
                payTable.setWidths(new float[]{2f, 2.5f, 2.5f, 2f});

                addTableCell(payTable, "Date", labelFont, LIGHT_BG, Element.ALIGN_LEFT);
                addTableCell(payTable, "Txn Reference", labelFont, LIGHT_BG, Element.ALIGN_CENTER);
                addTableCell(payTable, "Method", labelFont, LIGHT_BG, Element.ALIGN_CENTER);
                addTableCell(payTable, "Amount (LKR)", labelFont, LIGHT_BG, Element.ALIGN_RIGHT);

                for (PaymentRecord p : payments) {
                    addTableCell(payTable, p.getPaymentDate() != null ? p.getPaymentDate().toString() : "-", valueFont, Color.WHITE, Element.ALIGN_LEFT);
                    addTableCell(payTable, p.getTransactionRef() != null ? p.getTransactionRef() : ("PAY-" + p.getId()), valueFont, Color.WHITE, Element.ALIGN_CENTER);
                    addTableCell(payTable, p.getPaymentMethod() != null ? p.getPaymentMethod() : "Direct", valueFont, Color.WHITE, Element.ALIGN_CENTER);
                    addTableCell(payTable, String.format("%,.2f", p.getAmount() != null ? p.getAmount() : 0.0), valueFont, Color.WHITE, Element.ALIGN_RIGHT);
                }
                document.add(payTable);
            }

            // --- FOOTER ---
            document.add(new Paragraph(" "));
            document.add(sep);
            Paragraph footerPara = new Paragraph(
                    "Thank you for choosing FuelCore Energy & Vehicle Services.\n" +
                    "This is an electronically generated fiscal invoice. For disputes contact support@fuelcore.lk.",
                    footerFont
            );
            footerPara.setAlignment(Element.ALIGN_CENTER);
            footerPara.setSpacingBefore(8);
            document.add(footerPara);

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return out.toByteArray();
    }

    private void addTableCell(PdfPTable table, String text, Font font, Color bgColor, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text != null ? text : "", font));
        cell.setBackgroundColor(bgColor);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(6);
        cell.setBorderColor(BORDER_COLOR);
        table.addCell(cell);
    }
}
