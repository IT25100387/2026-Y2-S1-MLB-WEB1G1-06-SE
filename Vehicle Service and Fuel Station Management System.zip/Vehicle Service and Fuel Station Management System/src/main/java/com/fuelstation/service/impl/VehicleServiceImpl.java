package com.fuelstation.service.impl;

import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.Vehicle;
import com.fuelstation.repository.ServiceBookingRepository;
import com.fuelstation.repository.VehicleRepository;
import com.fuelstation.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class VehicleServiceImpl implements VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private ServiceBookingRepository bookingRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Vehicle> getVehicleById(Long id) {
        return vehicleRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Vehicle> getVehicleByLicensePlate(String licensePlate) {
        if (licensePlate == null || licensePlate.trim().isEmpty()) {
            return Optional.empty();
        }
        return vehicleRepository.findByLicensePlate(licensePlate.trim());
    }

    @Override
    @Transactional
    public Vehicle saveVehicle(Vehicle vehicle) {
        if (vehicle.getRegisteredDate() == null || vehicle.getRegisteredDate().trim().isEmpty()) {
            vehicle.setRegisteredDate(LocalDate.now().toString());
        }
        return vehicleRepository.save(vehicle);
    }

    @Override
    @Transactional
    public void deleteVehicle(Long id) {
        vehicleRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceBooking> getServiceHistory(String licensePlate) {
        if (licensePlate == null || licensePlate.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return bookingRepository.findByLicensePlateOrderByServiceDateDesc(licensePlate.trim());
    }

    // --- Phase 2: Customer Vehicle Management (My Garage) ---

    @Override
    @Transactional(readOnly = true)
    public List<Vehicle> getVehiclesByOwner(String username) {
        if (username == null || username.trim().isEmpty()) {
            return Collections.emptyList();
        }
        String cleanUser = username.trim();
        List<Vehicle> list = vehicleRepository.findByOwnerUsernameIgnoreCase(cleanUser);
        if (list.isEmpty()) {
            list = vehicleRepository.findByOwnerUsernameOrOwnerNameIgnoreCase(cleanUser, cleanUser);
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Vehicle> getVehicleForCustomer(Long id, String username) {
        if (id == null || username == null || username.trim().isEmpty()) {
            return Optional.empty();
        }
        Optional<Vehicle> opt = vehicleRepository.findById(id);
        if (opt.isPresent()) {
            Vehicle v = opt.get();
            if (isOwnedBy(v, username)) {
                return opt;
            }
        }
        return Optional.empty();
    }

    @Override
    @Transactional
    public Vehicle saveCustomerVehicle(Vehicle vehicle, String username, String ownerName, String ownerContact) {
        if (vehicle.getOwnerUsername() == null || vehicle.getOwnerUsername().trim().isEmpty()) {
            vehicle.setOwnerUsername(username);
        }
        if (vehicle.getOwnerName() == null || vehicle.getOwnerName().trim().isEmpty()) {
            vehicle.setOwnerName(ownerName != null ? ownerName : username);
        }
        if (vehicle.getOwnerContact() == null || vehicle.getOwnerContact().trim().isEmpty()) {
            if (ownerContact != null && !ownerContact.trim().isEmpty()) {
                vehicle.setOwnerContact(ownerContact.trim());
            } else {
                vehicle.setOwnerContact("Customer");
            }
        }
        if (vehicle.getRegisteredDate() == null || vehicle.getRegisteredDate().trim().isEmpty()) {
            vehicle.setRegisteredDate(LocalDate.now().toString());
        }
        return vehicleRepository.save(vehicle);
    }

    @Override
    @Transactional
    public boolean deleteCustomerVehicle(Long id, String username) {
        Optional<Vehicle> opt = getVehicleForCustomer(id, username);
        if (opt.isPresent()) {
            vehicleRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isVehicleOwnedByUser(Long id, String username) {
        return getVehicleForCustomer(id, username).isPresent();
    }

    private boolean isOwnedBy(Vehicle v, String username) {
        if (v == null || username == null) return false;
        String cleanUser = username.trim();
        if (v.getOwnerUsername() != null && v.getOwnerUsername().equalsIgnoreCase(cleanUser)) {
            return true;
        }
        if (v.getOwnerUsername() == null && v.getOwnerName() != null && v.getOwnerName().equalsIgnoreCase(cleanUser)) {
            return true;
        }
        return false;
    }
}
