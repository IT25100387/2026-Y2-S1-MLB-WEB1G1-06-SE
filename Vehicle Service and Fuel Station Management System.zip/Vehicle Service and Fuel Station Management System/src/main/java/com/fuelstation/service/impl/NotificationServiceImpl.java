package com.fuelstation.service.impl;

import com.fuelstation.model.Notification;
import com.fuelstation.repository.NotificationRepository;
import com.fuelstation.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    @Transactional
    public void createNotification(String title, String message, String type) {
        Notification notif = new Notification();
        notif.setTitle(title);
        notif.setMessage(message);
        notif.setType(type);
        notif.setStatus("Unread");
        notif.setCreatedDate(LocalDateTime.now());
        notificationRepository.save(notif);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Notification> getAllNotifications() {
        return notificationRepository.findAllByOrderByCreatedDateDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Notification> getTopRecentNotifications(int limit) {
        return notificationRepository.findAllByOrderByCreatedDateDesc().stream()
                .limit(limit)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public long getUnreadCount() {
        return notificationRepository.countByStatus("Unread");
    }

    @Override
    @Transactional
    public void markAsRead(Long id) {
        notificationRepository.findById(id).ifPresent(notif -> {
            notif.setStatus("Read");
            notificationRepository.save(notif);
        });
    }

    @Override
    @Transactional
    public void deleteNotification(Long id) {
        notificationRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void createCustomerNotification(String recipientUsername, String title, String message, String type, String actionUrl, String icon) {
        Notification notif = new Notification();
        notif.setRecipientUsername(recipientUsername);
        notif.setTitle(title);
        notif.setMessage(message);
        notif.setType(type != null ? type : "General");
        notif.setActionUrl(actionUrl);
        notif.setIcon(icon != null ? icon : "fa-bell");
        notif.setStatus("Unread");
        notif.setCreatedDate(LocalDateTime.now());
        notificationRepository.save(notif);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Notification> getNotificationsForCustomer(String username) {
        if (username == null || username.isBlank()) {
            return java.util.Collections.emptyList();
        }
        return notificationRepository.findByRecipientUsernameOrderByCreatedDateDesc(username.trim());
    }

    @Override
    @Transactional(readOnly = true)
    public long getUnreadCountForCustomer(String username) {
        if (username == null || username.isBlank()) return 0;
        return notificationRepository.countByRecipientUsernameAndStatus(username.trim(), "Unread");
    }

    @Override
    @Transactional
    public void markAllReadForCustomer(String username) {
        if (username == null || username.isBlank()) return;
        List<Notification> list = notificationRepository.findByRecipientUsernameOrderByCreatedDateDesc(username.trim());
        for (Notification n : list) {
            if ("Unread".equalsIgnoreCase(n.getStatus())) {
                n.setStatus("Read");
            }
        }
        notificationRepository.saveAll(list);
    }
}
