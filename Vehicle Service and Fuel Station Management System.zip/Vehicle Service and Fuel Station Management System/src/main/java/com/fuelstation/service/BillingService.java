package com.fuelstation.service;

import com.fuelstation.model.Invoice;
import com.fuelstation.model.PaymentRecord;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.SparePart;
import com.fuelstation.model.Supplier;

import java.util.List;
import java.util.Optional;

public interface BillingService {
    // Invoices
    List<Invoice> getAllInvoices();
    Optional<Invoice> getInvoiceById(Long id);
    Invoice saveInvoice(Invoice invoice);
    Invoice createAdvanceInvoice(ServiceBooking booking, double amount);
    List<Invoice> getInvoicesByCustomer(String customerUsername);
    Optional<Invoice> getInvoiceForCustomer(Long id, String customerUsername);

    // Payments
    PaymentRecord processPayment(PaymentRecord payment);
    List<PaymentRecord> getPaymentsByInvoiceId(Long invoiceId);
    List<PaymentRecord> getPaymentsByCustomer(String customerUsername);
    List<PaymentRecord> getAllPayments();
    PaymentRecord processCustomerPayment(Long invoiceId, String customerUsername, String paymentMethod, Double amount);
    boolean refundPayment(Long paymentId, String reason);
    PaymentRecord updatePaymentStatus(Long paymentId, String status);

    // Suppliers
    List<Supplier> getAllSuppliers();
    Optional<Supplier> getSupplierById(Long id);
    Supplier saveSupplier(Supplier supplier);
    void deleteSupplier(Long id);

    // Spare Parts
    List<SparePart> getAllSpareParts();
    Optional<SparePart> getSparePartById(Long id);
    SparePart saveSparePart(SparePart part);
    void deleteSparePart(Long id);
}
