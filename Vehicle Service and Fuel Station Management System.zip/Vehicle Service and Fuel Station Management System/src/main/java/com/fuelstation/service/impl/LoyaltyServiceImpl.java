package com.fuelstation.service.impl;

import com.fuelstation.model.AppUser;
import com.fuelstation.model.LoyaltyReward;
import com.fuelstation.model.LoyaltyTransaction;
import com.fuelstation.repository.AppUserRepository;
import com.fuelstation.repository.LoyaltyRewardRepository;
import com.fuelstation.repository.LoyaltyTransactionRepository;
import com.fuelstation.service.LoyaltyService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class LoyaltyServiceImpl implements LoyaltyService {

    @Autowired
    private LoyaltyRewardRepository rewardRepository;

    @Autowired
    private LoyaltyTransactionRepository transactionRepository;

    @Autowired
    private AppUserRepository userRepository;

    @PostConstruct
    public void initDefaultRewards() {
        if (rewardRepository.count() == 0) {
            LoyaltyReward r1 = new LoyaltyReward();
            r1.setTitle("High-Pressure Foam Car Wash");
            r1.setDescription("Complimentary express exterior foam wash and tire shine at Station Bay 4.");
            r1.setPointsRequired(150);
            r1.setCategory("CarWash");
            r1.setIcon("fa-soap");
            r1.setActive(true);
            r1.setVoucherPrefix("WASH");
            rewardRepository.save(r1);

            LoyaltyReward r2 = new LoyaltyReward();
            r2.setTitle("LKR 500 Fuel Discount Voucher");
            r2.setDescription("Direct LKR 500 discount on your next fuel purchase at any pump dispenser.");
            r2.setPointsRequired(300);
            r2.setCategory("Fuel");
            r2.setIcon("fa-gas-pump");
            r2.setActive(true);
            r2.setVoucherPrefix("FUEL");
            rewardRepository.save(r2);

            LoyaltyReward r3 = new LoyaltyReward();
            r3.setTitle("Free 1L Genuine Engine Oil");
            r3.setDescription("1 Litre OEM top-up bottle of 5W-30 synthetic lubricant during workshop service.");
            r3.setPointsRequired(450);
            r3.setCategory("Service");
            r3.setIcon("fa-oil-can");
            r3.setActive(true);
            r3.setVoucherPrefix("LUBE");
            rewardRepository.save(r3);

            LoyaltyReward r4 = new LoyaltyReward();
            r4.setTitle("Computerized 4-Wheel Laser Alignment");
            r4.setDescription("Precision digital 4-wheel alignment and suspension steering angle calibration.");
            r4.setPointsRequired(650);
            r4.setCategory("Service");
            r4.setIcon("fa-compact-disc");
            r4.setActive(true);
            r4.setVoucherPrefix("ALIGN");
            rewardRepository.save(r4);

            LoyaltyReward r5 = new LoyaltyReward();
            r5.setTitle("VIP Interior Sanitization & Detailing");
            r5.setDescription("Complete antibacterial ozone cabin treatment, vacuuming, and leather upholstery condition.");
            r5.setPointsRequired(1000);
            r5.setCategory("Service");
            r5.setIcon("fa-crown");
            r5.setActive(true);
            r5.setVoucherPrefix("VIP");
            rewardRepository.save(r5);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<LoyaltyReward> getActiveRewards() {
        return rewardRepository.findByActiveTrueOrderByPointsRequiredAsc();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LoyaltyTransaction> getCustomerHistory(String customerUsername) {
        if (customerUsername == null || customerUsername.isBlank()) {
            return Collections.emptyList();
        }
        return transactionRepository.findByCustomerUsernameOrderByTransactionDateDesc(customerUsername.trim());
    }

    @Override
    @Transactional(readOnly = true)
    public int getCustomerPoints(String customerUsername) {
        if (customerUsername == null) return 0;
        return userRepository.findByUsername(customerUsername.trim())
                .map(u -> u.getLoyaltyPoints() != null ? u.getLoyaltyPoints() : 0)
                .orElse(0);
    }

    @Override
    @Transactional(readOnly = true)
    public String getCustomerTier(String customerUsername) {
        int pts = getCustomerPoints(customerUsername);
        if (pts >= 1500) return "Platinum VIP";
        if (pts >= 700) return "Gold Executive";
        if (pts >= 300) return "Silver Member";
        return "Bronze Club";
    }

    @Override
    @Transactional
    public void awardPoints(String customerUsername, int points, String description) {
        if (customerUsername == null || points <= 0) return;
        userRepository.findByUsername(customerUsername.trim()).ifPresent(user -> {
            int current = user.getLoyaltyPoints() != null ? user.getLoyaltyPoints() : 0;
            int updated = current + points;
            user.setLoyaltyPoints(updated);
            user.setMembershipTier(calculateTier(updated));
            userRepository.save(user);

            LoyaltyTransaction txn = new LoyaltyTransaction();
            txn.setCustomerUsername(customerUsername.trim());
            txn.setPoints(points);
            txn.setType("EARNED");
            txn.setDescription(description != null ? description : "Points Earned");
            txn.setTransactionDate(LocalDateTime.now());
            transactionRepository.save(txn);
        });
    }

    @Override
    @Transactional
    public String redeemReward(String customerUsername, Long rewardId) {
        if (customerUsername == null || rewardId == null) return null;

        Optional<AppUser> userOpt = userRepository.findByUsername(customerUsername.trim());
        Optional<LoyaltyReward> rewardOpt = rewardRepository.findById(rewardId);

        if (userOpt.isEmpty() || rewardOpt.isEmpty()) {
            return null;
        }

        AppUser user = userOpt.get();
        LoyaltyReward reward = rewardOpt.get();

        int current = user.getLoyaltyPoints() != null ? user.getLoyaltyPoints() : 0;
        int required = reward.getPointsRequired() != null ? reward.getPointsRequired() : 0;

        if (current < required) {
            return null; // Insufficient points
        }

        int updated = current - required;
        user.setLoyaltyPoints(updated);
        user.setMembershipTier(calculateTier(updated));
        userRepository.save(user);

        String voucher = "FC-" + (reward.getVoucherPrefix() != null ? reward.getVoucherPrefix() : "RWD") + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        LoyaltyTransaction txn = new LoyaltyTransaction();
        txn.setCustomerUsername(customerUsername.trim());
        txn.setPoints(-required);
        txn.setType("REDEEMED");
        txn.setDescription("Redeemed: " + reward.getTitle());
        txn.setVoucherCode(voucher);
        txn.setTransactionDate(LocalDateTime.now());
        transactionRepository.save(txn);

        return voucher;
    }

    private String calculateTier(int pts) {
        if (pts >= 1500) return "Platinum VIP";
        if (pts >= 700) return "Gold Executive";
        if (pts >= 300) return "Silver Member";
        return "Bronze Club";
    }
}
