package com.fuelstation.service.impl;

import com.fuelstation.model.SupportTicket;
import com.fuelstation.repository.SupportTicketRepository;
import com.fuelstation.service.NotificationService;
import com.fuelstation.service.SupportTicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class SupportTicketServiceImpl implements SupportTicketService {

    @Autowired
    private SupportTicketRepository ticketRepository;

    @Autowired
    private NotificationService notificationService;

    @Override
    @Transactional
    public SupportTicket createTicket(SupportTicket ticket, String username) {
        ticket.setCustomerUsername(username);
        ticket.setTicketNumber("TCK-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase());
        ticket.setStatus("OPEN");
        ticket.setCreatedDate(LocalDateTime.now());
        if (ticket.getPriority() == null || ticket.getPriority().isBlank()) {
            ticket.setPriority("Medium");
        }
        SupportTicket saved = ticketRepository.save(ticket);

        try {
            notificationService.createCustomerNotification(
                    username,
                    "Support Inquiry Received (" + saved.getTicketNumber() + ")",
                    "Your help ticket '" + saved.getSubject() + "' has been logged. Our workshop desk will review and respond shortly.",
                    "Support",
                    "/customer/support",
                    "fa-headset"
            );
        } catch (Exception ignored) {}

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public List<SupportTicket> getTicketsForCustomer(String username) {
        if (username == null || username.isBlank()) {
            return Collections.emptyList();
        }
        return ticketRepository.findByCustomerUsernameOrderByCreatedDateDesc(username.trim());
    }

    @Override
    @Transactional(readOnly = true)
    public List<SupportTicket> getAllTickets() {
        return ticketRepository.findAllByOrderByCreatedDateDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<SupportTicket> getTicketById(Long id) {
        return ticketRepository.findById(id);
    }

    @Override
    @Transactional
    public void resolveTicket(Long id, String reply, String status) {
        ticketRepository.findById(id).ifPresent(ticket -> {
            ticket.setAdminReply(reply);
            ticket.setStatus(status != null ? status : "RESOLVED");
            ticket.setResolvedDate(LocalDateTime.now());
            ticketRepository.save(ticket);

            if (ticket.getCustomerUsername() != null) {
                try {
                    notificationService.createCustomerNotification(
                            ticket.getCustomerUsername(),
                            "Support Ticket Resolved (" + ticket.getTicketNumber() + ")",
                            "Workshop response: " + (reply.length() > 60 ? reply.substring(0, 57) + "..." : reply),
                            "Support",
                            "/customer/support",
                            "fa-circle-check"
                    );
                } catch (Exception ignored) {}
            }
        });
    }

    @Override
    @Transactional(readOnly = true)
    public long getOpenTicketsCount() {
        return ticketRepository.countByStatus("OPEN");
    }
}
