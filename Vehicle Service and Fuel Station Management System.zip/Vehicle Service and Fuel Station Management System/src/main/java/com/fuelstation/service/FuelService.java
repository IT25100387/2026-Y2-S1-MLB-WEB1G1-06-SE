package com.fuelstation.service;

import com.fuelstation.model.FuelInventory;
import com.fuelstation.model.FuelPrice;
import com.fuelstation.model.FuelPump;
import com.fuelstation.model.FuelSale;

import java.util.List;
import java.util.Optional;

public interface FuelService {
    // Sales
    FuelSale recordSale(FuelSale sale);
    List<FuelSale> getAllSales();
    double getTotalRevenue();

    // Pumps
    List<FuelPump> getAllPumps();
    Optional<FuelPump> getPumpById(Long id);
    FuelPump savePump(FuelPump pump);
    void deletePump(Long id);
    long getPumpsCount();

    // Inventory
    List<FuelInventory> getAllInventories();
    Optional<FuelInventory> getInventoryById(Long id);
    FuelInventory saveInventory(FuelInventory inventory);
    void deleteInventory(Long id);

    // Prices
    List<FuelPrice> getAllPrices();
    Optional<FuelPrice> getPriceById(Long id);
    FuelPrice savePrice(FuelPrice price);
    void deletePrice(Long id);

    // Customer Fuel History & E-Receipts (Phase 4)
    Optional<FuelSale> getSaleById(Long id);
    List<FuelSale> getCustomerFuelPurchases(String username);
    boolean isSaleAccessibleByCustomer(FuelSale sale, String username);
    void seedDefaultFuelDataIfEmpty();
}
