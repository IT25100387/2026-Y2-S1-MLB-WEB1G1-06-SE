package com.fuelstation.service.impl;

import com.fuelstation.model.Invoice;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.repository.InvoiceRepository;
import com.fuelstation.repository.ServiceBookingRepository;
import com.fuelstation.service.BookingService;
import com.fuelstation.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private ServiceBookingRepository bookingRepository;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ServiceBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ServiceBooking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isSlotAvailable(LocalDate serviceDate, String timeSlot) {
        return !bookingRepository.existsByServiceDateAndTimeSlotAndStatusNot(serviceDate, timeSlot, "Cancelled");
    }

    @Override
    @Transactional
    public ServiceBooking createBooking(ServiceBooking booking) {
        // Business Rule: Validate slot availability
        if (!isSlotAvailable(booking.getServiceDate(), booking.getTimeSlot())) {
            throw new IllegalStateException("That time slot is already booked! Please select a different time.");
        }

        if (booking.getStatus() == null || booking.getStatus().trim().isEmpty()) {
            booking.setStatus("Pending");
        }

        ServiceBooking saved = bookingRepository.save(booking);

        // Automated notification
        notificationService.createNotification(
                "Booking Confirmed",
                "Service booked for " + saved.getCustomerName() + " (Vehicle: " + saved.getLicensePlate() + ") on " + saved.getServiceDate() + " at " + saved.getTimeSlot(),
                "Booking"
        );

        // Advance payment logic for major services
        if ("Full Service".equalsIgnoreCase(saved.getServiceType()) || "Repair".equalsIgnoreCase(saved.getServiceType())) {
            Invoice inv = new Invoice();
            inv.setInvoiceNo("INV-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase());
            inv.setInvoiceName("Advance Payment: " + saved.getServiceType());
            inv.setReferenceNo("BKG-" + saved.getId());
            inv.setCustomerName(saved.getCustomerName());
            inv.setInvoiceDate(LocalDate.now());
            inv.setDueDate(saved.getServiceDate());
            inv.setGrossTotalAmount(5000.0);
            inv.setConvenienceFee(0.0);
            inv.setNetTotal(5000.0);
            inv.setAmountPaid(0.0);
            inv.setStatus("OVERDUE");
            invoiceRepository.save(inv);
        }

        return saved;
    }

    @Override
    @Transactional
    public void cancelBooking(Long id) {
        bookingRepository.findById(id).ifPresent(booking -> {
            booking.setStatus("Cancelled");
            bookingRepository.save(booking);

            notificationService.createNotification(
                    "Booking Cancelled",
                    "The service booking for vehicle " + booking.getLicensePlate() + " on " + booking.getServiceDate() + " has been cancelled.",
                    "Alert"
            );
        });
    }

    @Override
    @Transactional
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public long getPendingBookingsCount() {
        return bookingRepository.findAll().stream()
                .filter(b -> "Pending".equals(b.getStatus()))
                .count();
    }

    @Override
    @Transactional(readOnly = true)
    public long getCompletedBookingsCount() {
        return bookingRepository.findAll().stream()
                .filter(b -> "Completed".equals(b.getStatus()))
                .count();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceBooking> getPendingBookings() {
        return bookingRepository.findAll().stream()
                .filter(b -> "Pending".equals(b.getStatus()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceBooking> getBookingsByCustomer(String username) {
        if (username == null || username.isBlank()) {
            return List.of();
        }
        return bookingRepository.findByCustomerUsernameOrCustomerNameIgnoreCaseOrderByServiceDateDesc(username, username);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ServiceBooking> getBookingForCustomer(Long id, String username) {
        if (id == null || username == null) {
            return Optional.empty();
        }
        Optional<ServiceBooking> opt = bookingRepository.findById(id);
        if (opt.isEmpty()) {
            return Optional.empty();
        }
        ServiceBooking booking = opt.get();
        boolean matches = (booking.getCustomerUsername() != null && booking.getCustomerUsername().equalsIgnoreCase(username)) ||
                          (booking.getCustomerUsername() == null && booking.getCustomerName() != null && booking.getCustomerName().equalsIgnoreCase(username));
        return matches ? Optional.of(booking) : Optional.empty();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isBookingOwnedByUser(Long id, String username) {
        return getBookingForCustomer(id, username).isPresent();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isSlotAvailableForReschedule(LocalDate serviceDate, String timeSlot, Long bookingId) {
        return !bookingRepository.existsByServiceDateAndTimeSlotAndStatusNotAndIdNot(serviceDate, timeSlot, "Cancelled", bookingId);
    }

    @Override
    @Transactional
    public ServiceBooking rescheduleBooking(Long id, LocalDate newDate, String newSlot, String username) {
        Optional<ServiceBooking> opt = getBookingForCustomer(id, username);
        if (opt.isEmpty()) {
            throw new IllegalArgumentException("Booking not found or access denied for user: " + username);
        }
        ServiceBooking booking = opt.get();
        if (!isSlotAvailableForReschedule(newDate, newSlot, id)) {
            throw new IllegalStateException("Selected time slot is already booked! Please select another date or time slot.");
        }
        booking.setServiceDate(newDate);
        booking.setTimeSlot(newSlot);
        if ("Cancelled".equalsIgnoreCase(booking.getStatus())) {
            booking.setStatus("Pending");
        }
        ServiceBooking saved = bookingRepository.save(booking);

        notificationService.createNotification(
                "Appointment Rescheduled",
                "Service booking #" + saved.getId() + " (" + saved.getLicensePlate() + ") rescheduled to " + newDate + " at " + newSlot,
                "Booking"
        );
        return saved;
    }

    @Override
    @Transactional
    public void cancelBookingForCustomer(Long id, String username) {
        Optional<ServiceBooking> opt = getBookingForCustomer(id, username);
        if (opt.isEmpty()) {
            throw new IllegalArgumentException("Booking not found or access denied for user: " + username);
        }
        cancelBooking(id);
    }

    @Override
    @Transactional
    public ServiceBooking updateBookingStatus(Long id, String status) {
        ServiceBooking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found: " + id));

        booking.setStatus(status);
        if ("Approved".equalsIgnoreCase(status)) {
            booking.setTrackingStage("Booking Confirmed");
        } else if ("Assigned".equalsIgnoreCase(status)) {
            booking.setTrackingStage("Vehicle Received");
        } else if ("In Progress".equalsIgnoreCase(status)) {
            booking.setTrackingStage("Repair / Service");
        } else if ("Completed".equalsIgnoreCase(status)) {
            booking.setTrackingStage("Completed & Ready");
        } else if ("Cancelled".equalsIgnoreCase(status)) {
            booking.setTrackingStage("Cancelled");
        }

        ServiceBooking saved = bookingRepository.save(booking);

        notificationService.createNotification(
                "Booking Status Updated",
                "Service booking #" + saved.getId() + " (" + saved.getLicensePlate() + ") status changed to " + status,
                "Booking"
        );
        return saved;
    }
}
