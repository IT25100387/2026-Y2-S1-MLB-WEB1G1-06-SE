package com.fuelstation.service;

import com.fuelstation.model.Promotion;
import java.util.List;
import java.util.Optional;

public interface PromotionService {
    List<Promotion> getActivePromotions();
    List<Promotion> getAllPromotions();
    Optional<Promotion> getPromotionById(Long id);
    Promotion savePromotion(Promotion promotion);
    void togglePromotion(Long id);
    void deletePromotion(Long id);
}
