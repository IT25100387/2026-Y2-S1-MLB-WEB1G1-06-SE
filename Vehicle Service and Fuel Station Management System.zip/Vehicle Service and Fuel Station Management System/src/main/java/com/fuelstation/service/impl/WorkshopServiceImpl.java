package com.fuelstation.service.impl;

import com.fuelstation.model.CustomerFeedback;
import com.fuelstation.model.JobCard;
import com.fuelstation.model.ServiceBay;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.Staff;
import com.fuelstation.repository.CustomerFeedbackRepository;
import com.fuelstation.repository.JobCardRepository;
import com.fuelstation.repository.ServiceBayRepository;
import com.fuelstation.repository.ServiceBookingRepository;
import com.fuelstation.repository.StaffRepository;
import com.fuelstation.service.NotificationService;
import com.fuelstation.service.WorkshopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class WorkshopServiceImpl implements WorkshopService {

    @Autowired
    private JobCardRepository jobCardRepository;

    @Autowired
    private ServiceBayRepository bayRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private ServiceBookingRepository bookingRepository;

    @Autowired
    private CustomerFeedbackRepository feedbackRepository;

    @Autowired
    private NotificationService notificationService;

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getAllJobCards() {
        return jobCardRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<JobCard> getJobCardById(Long id) {
        return jobCardRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<JobCard> getJobCardByBookingId(Long bookingId) {
        if (bookingId == null) {
            return Optional.empty();
        }
        return jobCardRepository.findFirstByBookingIdOrderByIdDesc(bookingId);
    }

    @Override
    @Transactional
    public JobCard createJobCard(Long bookingId, Long mechanicId, Long bayId) {
        ServiceBooking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found: " + bookingId));
        Staff mechanic = staffRepository.findById(mechanicId)
                .orElseThrow(() -> new IllegalArgumentException("Mechanic not found: " + mechanicId));
        ServiceBay bay = bayRepository.findById(bayId)
                .orElseThrow(() -> new IllegalArgumentException("Bay not found: " + bayId));

        JobCard job = new JobCard();
        job.setBookingId(booking.getId());
        job.setLicensePlate(booking.getLicensePlate());
        job.setCustomerName(booking.getCustomerName());
        job.setServiceType(booking.getServiceType());

        job.setMechanicId(mechanic.getId());
        job.setMechanicName(mechanic.getName());

        job.setBayId(bay.getId());
        job.setBayName(bay.getBayName());

        job.setStatus("In Progress");
        JobCard saved = jobCardRepository.save(job);

        // Update Booking Status and Tracking Stage
        booking.setStatus("In Progress");
        booking.setTrackingStage("Repair / Service");
        bookingRepository.save(booking);

        // Update Bay Status
        bay.setStatus("Occupied");
        bayRepository.save(bay);

        return saved;
    }

    @Override
    @Transactional
    public JobCard updateJobCard(Long id, String status, String mechanicNotes, String partsUsed) {
        JobCard job = jobCardRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("JobCard not found: " + id));

        job.setStatus(status);
        if (mechanicNotes != null) {
            job.setMechanicNotes(mechanicNotes);
        }
        if (partsUsed != null) {
            job.setPartsUsed(partsUsed);
        }
        JobCard saved = jobCardRepository.save(job);

        // Update Booking Status & Live Tracking Stage
        if (job.getBookingId() != null) {
            bookingRepository.findById(job.getBookingId()).ifPresent(booking -> {
                if ("Quality Check".equalsIgnoreCase(status)) {
                    booking.setStatus("In Progress");
                    booking.setTrackingStage("Quality Check");
                    bookingRepository.save(booking);
                } else if ("In Progress".equalsIgnoreCase(status) || "Waiting for Parts".equalsIgnoreCase(status)) {
                    booking.setStatus("In Progress");
                    booking.setTrackingStage("Repair / Service");
                    bookingRepository.save(booking);
                }
            });
        }

        if ("Completed".equalsIgnoreCase(status)) {
            // Free the bay
            if (job.getBayId() != null) {
                bayRepository.findById(job.getBayId()).ifPresent(bay -> {
                    bay.setStatus("Available");
                    bayRepository.save(bay);
                });
            }

            // Update Booking Status & Live Tracking Stage
            if (job.getBookingId() != null) {
                bookingRepository.findById(job.getBookingId()).ifPresent(booking -> {
                    booking.setStatus("Completed");
                    booking.setTrackingStage("Completed");
                    bookingRepository.save(booking);
                });
            }

            // Automated Notification
            notificationService.createNotification(
                    "Job Completed",
                    "Service completed for vehicle " + job.getLicensePlate(),
                    "Service"
            );
        }

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceBay> getAllBays() {
        return bayRepository.findAll();
    }

    @Override
    @Transactional
    public ServiceBay addBay(ServiceBay bay) {
        if (bay.getStatus() == null || bay.getStatus().trim().isEmpty()) {
            bay.setStatus("Available");
        }
        return bayRepository.save(bay);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Staff> getAvailableMechanics() {
        return staffRepository.findAll().stream()
                .filter(s -> "Mechanic".equalsIgnoreCase(s.getRole()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerFeedback> getAllFeedbacks() {
        return feedbackRepository.findAllByOrderBySubmissionDateDesc();
    }

    @Override
    @Transactional
    public CustomerFeedback submitFeedback(CustomerFeedback feedback) {
        feedback.setSubmissionDate(LocalDateTime.now());
        feedback.setNeedsAttention(feedback.getRating() != null && feedback.getRating() < 3);
        CustomerFeedback saved = feedbackRepository.save(feedback);

        if (Boolean.TRUE.equals(saved.getNeedsAttention())) {
            notificationService.createNotification(
                    "Low Rating Alert",
                    "Customer " + saved.getCustomerName() + " submitted a rating of " + saved.getRating() + ".",
                    "Alert"
            );
        }

        return saved;
    }
}
