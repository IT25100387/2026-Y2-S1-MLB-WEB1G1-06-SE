package com.fuelstation.service;

import com.fuelstation.model.ServiceBooking;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BookingService {
    List<ServiceBooking> getAllBookings();
    Optional<ServiceBooking> getBookingById(Long id);
    boolean isSlotAvailable(LocalDate serviceDate, String timeSlot);
    ServiceBooking createBooking(ServiceBooking booking);
    void cancelBooking(Long id);
    void deleteBooking(Long id);
    long getPendingBookingsCount();
    long getCompletedBookingsCount();
    List<ServiceBooking> getPendingBookings();

    // Phase 3 Customer Methods
    List<ServiceBooking> getBookingsByCustomer(String username);
    Optional<ServiceBooking> getBookingForCustomer(Long id, String username);
    boolean isBookingOwnedByUser(Long id, String username);
    boolean isSlotAvailableForReschedule(LocalDate serviceDate, String timeSlot, Long bookingId);
    ServiceBooking rescheduleBooking(Long id, LocalDate newDate, String newSlot, String username);
    void cancelBookingForCustomer(Long id, String username);
    ServiceBooking updateBookingStatus(Long id, String status);
}
