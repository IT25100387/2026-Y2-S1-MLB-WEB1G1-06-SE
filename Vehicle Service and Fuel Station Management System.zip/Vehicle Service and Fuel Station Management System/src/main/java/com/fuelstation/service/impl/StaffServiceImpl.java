package com.fuelstation.service.impl;

import com.fuelstation.model.AttendanceRecord;
import com.fuelstation.model.LeaveRequest;
import com.fuelstation.model.ShiftSchedule;
import com.fuelstation.model.Staff;
import com.fuelstation.repository.AttendanceRecordRepository;
import com.fuelstation.repository.LeaveRequestRepository;
import com.fuelstation.repository.ShiftScheduleRepository;
import com.fuelstation.repository.StaffRepository;
import com.fuelstation.service.NotificationService;
import com.fuelstation.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class StaffServiceImpl implements StaffService {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private ShiftScheduleRepository shiftRepository;

    @Autowired
    private AttendanceRecordRepository attendanceRepository;

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Autowired
    private NotificationService notificationService;

    // --- Staff ---
    @Override
    @Transactional(readOnly = true)
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Staff> getStaffById(Long id) {
        return staffRepository.findById(id);
    }

    @Override
    @Transactional
    public Staff saveStaff(Staff staff) {
        if (staff.getEmploymentStatus() == null || staff.getEmploymentStatus().trim().isEmpty()) {
            staff.setEmploymentStatus("Active");
        }
        return staffRepository.save(staff);
    }

    @Override
    @Transactional
    public void deactivateStaff(Long id) {
        staffRepository.findById(id).ifPresent(staff -> {
            staff.setEmploymentStatus("Inactive"); // Soft delete
            staffRepository.save(staff);
        });
    }

    // --- Shifts ---
    @Override
    @Transactional(readOnly = true)
    public List<ShiftSchedule> getAllShifts() {
        return shiftRepository.findAll();
    }

    @Override
    @Transactional
    public ShiftSchedule saveShift(ShiftSchedule shift) {
        if (shift.getStatus() == null || shift.getStatus().trim().isEmpty()) {
            shift.setStatus("Scheduled");
        }
        if (shift.getStaffId() != null) {
            staffRepository.findById(shift.getStaffId()).ifPresent(staff -> {
                shift.setStaffName(staff.getName());
            });
        }
        return shiftRepository.save(shift);
    }

    @Override
    @Transactional
    public void deleteShift(Long id) {
        shiftRepository.deleteById(id);
    }

    // --- Attendance ---
    @Override
    @Transactional(readOnly = true)
    public List<AttendanceRecord> getAllAttendanceRecords() {
        return attendanceRepository.findAll();
    }

    @Override
    @Transactional
    public AttendanceRecord clockIn(Long staffId) {
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new IllegalArgumentException("Staff not found: " + staffId));

        AttendanceRecord record = new AttendanceRecord();
        record.setStaffId(staff.getId());
        record.setStaffName(staff.getName());
        record.setAttendanceDate(LocalDate.now());
        record.setClockInTime(LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("hh:mm a")));
        record.setStatus("Present");

        return attendanceRepository.save(record);
    }

    // --- Leave ---
    @Override
    @Transactional(readOnly = true)
    public List<LeaveRequest> getAllLeaveRequests() {
        return leaveRepository.findAll();
    }

    @Override
    @Transactional
    public LeaveRequest submitLeaveRequest(LeaveRequest leave) {
        leave.setStatus("Pending");
        if (leave.getStaffId() != null) {
            staffRepository.findById(leave.getStaffId()).ifPresent(staff -> {
                leave.setStaffName(staff.getName());
            });
        }
        return leaveRepository.save(leave);
    }

    @Override
    @Transactional
    public LeaveRequest processLeaveAction(Long id, String action) {
        LeaveRequest leave = leaveRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Leave request not found: " + id));

        leave.setStatus(action);
        LeaveRequest saved = leaveRepository.save(leave);

        notificationService.createNotification(
                "Leave " + action,
                "Leave request for " + saved.getStaffName() + " has been " + action + ".",
                "Alert"
        );

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public long getPendingLeavesCount() {
        return leaveRepository.findAll().stream()
                .filter(l -> "Pending".equalsIgnoreCase(l.getStatus()))
                .count();
    }
}
