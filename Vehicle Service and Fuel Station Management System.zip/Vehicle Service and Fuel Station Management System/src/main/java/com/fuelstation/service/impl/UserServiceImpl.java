package com.fuelstation.service.impl;

import com.fuelstation.model.AppUser;
import com.fuelstation.repository.AppUserRepository;
import com.fuelstation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private AppUserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private com.fuelstation.service.AuditLogService auditLogService;

    @Override
    @Transactional(readOnly = true)
    public List<AppUser> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AppUser> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AppUser> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    @Transactional
    public AppUser registerOrUpdateUser(AppUser user) {
        if (user.getStatus() == null || user.getStatus().trim().isEmpty()) {
            user.setStatus("Active");
        }
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(java.time.LocalDateTime.now());
        }

        // Hash password with BCrypt if raw password is provided
        if (user.getPassword() != null && !user.getPassword().trim().isEmpty()) {
            String pwd = user.getPassword().trim();
            if (!pwd.startsWith("$2a$") && !pwd.startsWith("$2b$") && !pwd.startsWith("$2y$")) {
                user.setPassword(passwordEncoder.encode(pwd));
            }
        }

        return userRepository.save(user);
    }

    @Override
    @Transactional
    public AppUser createUser(AppUser user) {
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            throw new IllegalArgumentException("Username is required.");
        }
        String cleanUsername = user.getUsername().trim();
        if (userRepository.existsByUsernameIgnoreCase(cleanUsername)) {
            throw new IllegalArgumentException("Username '" + cleanUsername + "' is already registered.");
        }

        user.setUsername(cleanUsername);
        if (user.getStatus() == null || user.getStatus().trim().isEmpty()) {
            user.setStatus("Active");
        }
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(java.time.LocalDateTime.now());
        }

        if (user.getPassword() != null && !user.getPassword().trim().isEmpty()) {
            String pwd = user.getPassword().trim();
            if (!pwd.startsWith("$2a$") && !pwd.startsWith("$2b$") && !pwd.startsWith("$2y$")) {
                user.setPassword(passwordEncoder.encode(pwd));
            }
        }

        AppUser saved = userRepository.save(user);
        try {
            auditLogService.record("USER_CREATED", saved.getUsername(), saved.getRole(),
                    "Provisioned account for " + saved.getFullName() + " (" + saved.getRole() + ")", "SUCCESS");
        } catch (Exception ignored) {}
        return saved;
    }

    @Override
    @Transactional
    public AppUser updateUser(Long id, AppUser updatedUser, String newPassword) {
        AppUser existing = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + id));

        if (updatedUser.getFullName() != null && !updatedUser.getFullName().isBlank()) {
            existing.setFullName(updatedUser.getFullName().trim());
        }
        if (updatedUser.getEmail() != null && !updatedUser.getEmail().isBlank()) {
            existing.setEmail(updatedUser.getEmail().trim());
        }
        if (updatedUser.getPhoneNumber() != null) {
            existing.setPhoneNumber(updatedUser.getPhoneNumber().trim());
        }
        if (updatedUser.getAddress() != null) {
            existing.setAddress(updatedUser.getAddress().trim());
        }
        if (updatedUser.getCity() != null) {
            existing.setCity(updatedUser.getCity().trim());
        }
        if (updatedUser.getRole() != null && !updatedUser.getRole().isBlank()) {
            existing.setRole(updatedUser.getRole().trim());
        }
        if (updatedUser.getStatus() != null && !updatedUser.getStatus().isBlank()) {
            existing.setStatus(updatedUser.getStatus().trim());
        }

        if (newPassword != null && !newPassword.trim().isEmpty()) {
            existing.setPassword(passwordEncoder.encode(newPassword.trim()));
        }

        AppUser saved = userRepository.save(existing);
        try {
            auditLogService.record("USER_UPDATED", saved.getUsername(), saved.getRole(),
                    "Updated profile details for " + saved.getFullName() + " (Status: " + saved.getStatus() + ")", "SUCCESS");
        } catch (Exception ignored) {}
        return saved;
    }

    @Override
    @Transactional
    public void deactivateUser(Long id) {
        userRepository.findById(id).ifPresent(user -> {
            if ("admin".equalsIgnoreCase(user.getUsername())) {
                return; // Root admin account is protected from deactivation
            }
            user.setStatus("Deactivated");
            userRepository.save(user);
            try {
                auditLogService.record("USER_DEACTIVATED", user.getUsername(), user.getRole(),
                        "Deactivated account #" + id + " (@" + user.getUsername() + ")", "SUCCESS");
            } catch (Exception ignored) {}
        });
    }

    @Override
    @Transactional
    public void reactivateUser(Long id) {
        userRepository.findById(id).ifPresent(user -> {
            user.setStatus("Active");
            userRepository.save(user);
            try {
                auditLogService.record("USER_REACTIVATED", user.getUsername(), user.getRole(),
                        "Reactivated account #" + id + " (@" + user.getUsername() + ")", "SUCCESS");
            } catch (Exception ignored) {}
        });
    }

    @Override
    @Transactional
    public void toggleUserStatus(Long id) {
        userRepository.findById(id).ifPresent(user -> {
            if ("admin".equalsIgnoreCase(user.getUsername())) {
                return; // Root admin account is protected from deactivation
            }
            if ("Active".equalsIgnoreCase(user.getStatus())) {
                user.setStatus("Deactivated");
            } else {
                user.setStatus("Active");
            }
            userRepository.save(user);
            try {
                auditLogService.record("USER_STATUS_TOGGLED", user.getUsername(), user.getRole(),
                        "Toggled status to " + user.getStatus() + " for account #" + id, "SUCCESS");
            } catch (Exception ignored) {}
        });
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppUser> searchUsers(String query, String role, String status) {
        String cleanQuery = (query != null) ? query.trim().toLowerCase() : "";
        String cleanRole = (role != null) ? role.trim() : "ALL";
        String cleanStatus = (status != null) ? status.trim() : "ALL";

        return userRepository.findAll().stream().filter(u -> {
            boolean matchesQuery = cleanQuery.isEmpty() ||
                    (u.getFullName() != null && u.getFullName().toLowerCase().contains(cleanQuery)) ||
                    (u.getUsername() != null && u.getUsername().toLowerCase().contains(cleanQuery)) ||
                    (u.getEmail() != null && u.getEmail().toLowerCase().contains(cleanQuery));

            boolean matchesRole = cleanRole.equalsIgnoreCase("ALL") ||
                    (u.getRole() != null && u.getRole().equalsIgnoreCase(cleanRole));

            boolean matchesStatus = cleanStatus.equalsIgnoreCase("ALL") ||
                    (u.getStatus() != null && u.getStatus().equalsIgnoreCase(cleanStatus));

            return matchesQuery && matchesRole && matchesStatus;
        }).toList();
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        userRepository.findById(id).ifPresent(user -> {
            if ("admin".equalsIgnoreCase(user.getUsername())) {
                return; // Root admin account is protected
            }
            user.setStatus("Deactivated");
            userRepository.save(user);
            try {
                auditLogService.record("USER_DEACTIVATED", user.getUsername(), user.getRole(),
                        "Soft deleted / deactivated user account #" + id, "SUCCESS");
            } catch (Exception ignored) {}
        });
    }

    @Override
    @Transactional
    public AppUser updateProfile(String username, String fullName, String email, String phone, String address, String city) {
        AppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        if (fullName != null && !fullName.trim().isEmpty()) {
            user.setFullName(fullName.trim());
        }
        if (email != null && !email.trim().isEmpty()) {
            user.setEmail(email.trim());
        }
        user.setPhoneNumber(phone != null ? phone.trim() : null);
        user.setAddress(address != null ? address.trim() : null);
        user.setCity(city != null ? city.trim() : null);

        return userRepository.save(user);
    }

    @Override
    @Transactional
    public AppUser updateSettings(String username, boolean emailNotif, boolean smsNotif) {
        AppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));
        user.setEmailNotifications(emailNotif);
        user.setSmsNotifications(smsNotif);
        return userRepository.save(user);
    }

    @Override
    @Transactional
    public boolean changePassword(String username, String currentPassword, String newPassword) {
        AppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            return false;
        }

        user.setPassword(passwordEncoder.encode(newPassword.trim()));
        userRepository.save(user);
        try {
            auditLogService.record("PASSWORD_CHANGED", username, user.getRole(),
                    "User updated account password via BCrypt verification", "SUCCESS");
        } catch (Exception ignored) {}
        return true;
    }

    @Override
    @Transactional
    public String generatePasswordResetToken(String identifier) {
        if (identifier == null || identifier.trim().isEmpty()) return null;
        String clean = identifier.trim();

        Optional<AppUser> userOpt = userRepository.findByEmailIgnoreCase(clean);
        if (userOpt.isEmpty()) {
            userOpt = userRepository.findByUsernameIgnoreCase(clean);
        }

        if (userOpt.isPresent()) {
            AppUser user = userOpt.get();
            String token = java.util.UUID.randomUUID().toString();
            user.setResetToken(token);
            user.setResetTokenExpiry(java.time.LocalDateTime.now().plusHours(2));
            userRepository.save(user);
            try {
                auditLogService.record("PASSWORD_RESET_REQUESTED", user.getUsername(), user.getRole(),
                        "Generated password reset token for account recovery", "SUCCESS");
            } catch (Exception ignored) {}
            return token;
        }
        return null;
    }

    @Override
    @Transactional
    public boolean resetPasswordWithToken(String token, String newPassword) {
        if (token == null || token.trim().isEmpty()) return false;
        Optional<AppUser> userOpt = userRepository.findByResetToken(token.trim());
        if (userOpt.isEmpty()) return false;

        AppUser user = userOpt.get();
        if (user.getResetTokenExpiry() == null || user.getResetTokenExpiry().isBefore(java.time.LocalDateTime.now())) {
            return false;
        }

        user.setPassword(passwordEncoder.encode(newPassword.trim()));
        user.setResetToken(null);
        user.setResetTokenExpiry(null);
        userRepository.save(user);
        try {
            auditLogService.record("PASSWORD_RESET_SUCCESS", user.getUsername(), user.getRole(),
                    "Account password successfully reset via token authorization", "SUCCESS");
        } catch (Exception ignored) {}
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppUser> getCustomersOnly() {
        return userRepository.findAll().stream()
                .filter(u -> "Customer".equalsIgnoreCase(u.getRole()) || "ROLE_CUSTOMER".equalsIgnoreCase(u.getRole()))
                .toList();
    }
}
