package com.fuelstation.service.impl;

import com.fuelstation.model.Invoice;
import com.fuelstation.model.PaymentRecord;
import com.fuelstation.model.ServiceBooking;
import com.fuelstation.model.SparePart;
import com.fuelstation.model.Supplier;
import com.fuelstation.repository.InvoiceRepository;
import com.fuelstation.repository.PaymentRecordRepository;
import com.fuelstation.repository.SparePartRepository;
import com.fuelstation.repository.SupplierRepository;
import com.fuelstation.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BillingServiceImpl implements BillingService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private PaymentRecordRepository paymentRecordRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private SparePartRepository sparePartRepository;

    // --- Invoices ---
    @Override
    @Transactional(readOnly = true)
    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Invoice> getInvoiceById(Long id) {
        return invoiceRepository.findById(id);
    }

    @Override
    @Transactional
    public Invoice saveInvoice(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional
    public Invoice createAdvanceInvoice(ServiceBooking booking, double amount) {
        Invoice inv = new Invoice();
        inv.setInvoiceNo("INV-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase());
        inv.setInvoiceName("Service: " + booking.getServiceType());
        inv.setReferenceNo("BKG-" + booking.getId());
        inv.setCustomerName(booking.getCustomerName());
        inv.setCustomerUsername(booking.getCustomerUsername());
        inv.setLicensePlate(booking.getLicensePlate());
        inv.setBookingId(booking.getId());
        inv.setInvoiceDate(LocalDate.now());
        inv.setDueDate(booking.getServiceDate());
        inv.setGrossTotalAmount(amount);
        inv.setConvenienceFee(0.0);
        inv.setNetTotal(amount);
        inv.setAmountPaid(0.0);
        inv.setStatus("PENDING");
        return invoiceRepository.save(inv);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Invoice> getInvoicesByCustomer(String customerUsername) {
        if (customerUsername == null || customerUsername.isBlank()) {
            return Collections.emptyList();
        }
        return invoiceRepository.findByCustomerUsernameOrderByInvoiceDateDesc(customerUsername.trim());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Invoice> getInvoiceForCustomer(Long id, String customerUsername) {
        if (id == null || customerUsername == null) {
            return Optional.empty();
        }
        return invoiceRepository.findById(id)
                .filter(inv -> customerUsername.equalsIgnoreCase(inv.getCustomerUsername()));
    }

    // --- Payments ---
    @Override
    @Transactional
    public PaymentRecord processPayment(PaymentRecord payment) {
        if (payment.getPaymentDate() == null) {
            payment.setPaymentDate(LocalDate.now());
        }
        if (payment.getStatus() == null) {
            payment.setStatus("SUCCESS");
        }
        if (payment.getTransactionRef() == null) {
            payment.setTransactionRef("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        PaymentRecord saved = paymentRecordRepository.save(payment);

        // Update Invoice status & track split payments
        if (payment.getInvoiceId() != null) {
            invoiceRepository.findById(payment.getInvoiceId()).ifPresent(inv -> {
                double currentPaid = inv.getAmountPaid() != null ? inv.getAmountPaid() : 0.0;
                double paymentAmount = payment.getAmount() != null ? payment.getAmount() : 0.0;
                double newAmountPaid = currentPaid + paymentAmount;
                inv.setAmountPaid(newAmountPaid);

                if (inv.getNetTotal() != null && newAmountPaid >= inv.getNetTotal()) {
                    inv.setStatus("PAID");
                } else {
                    inv.setStatus("PARTIAL");
                }
                invoiceRepository.save(inv);
            });
        }

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PaymentRecord> getPaymentsByCustomer(String customerUsername) {
        if (customerUsername == null || customerUsername.isBlank()) {
            return Collections.emptyList();
        }
        return paymentRecordRepository.findByCustomerUsernameOrderByPaymentDateDesc(customerUsername.trim());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PaymentRecord> getAllPayments() {
        return paymentRecordRepository.findAllByOrderByPaymentDateDesc();
    }

    @Override
    @Transactional
    public PaymentRecord processCustomerPayment(Long invoiceId, String customerUsername, String paymentMethod, Double amount) {
        Invoice invoice = getInvoiceForCustomer(invoiceId, customerUsername)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found or unauthorized"));

        PaymentRecord record = new PaymentRecord();
        record.setInvoiceId(invoice.getId());
        record.setPaymentDate(LocalDate.now());
        record.setPaidOccupant(invoice.getCustomerName() != null ? invoice.getCustomerName() : customerUsername);
        record.setCustomerUsername(customerUsername);
        record.setPaymentMethod(paymentMethod != null ? paymentMethod : "Credit Card");
        double balanceDue = invoice.getNetTotal() - (invoice.getAmountPaid() != null ? invoice.getAmountPaid() : 0.0);
        record.setAmount(amount != null && amount > 0 ? amount : Math.max(0.0, balanceDue));
        record.setStatus("SUCCESS");
        record.setTransactionRef("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        record.setNotes("Online settlement via customer portal");

        return processPayment(record);
    }

    @Override
    @Transactional
    public boolean refundPayment(Long paymentId, String reason) {
        Optional<PaymentRecord> opt = paymentRecordRepository.findById(paymentId);
        if (opt.isPresent()) {
            PaymentRecord payment = opt.get();
            payment.setStatus("REFUNDED");
            payment.setNotes((payment.getNotes() != null ? payment.getNotes() + " | " : "") + "Refunded: " + reason);
            paymentRecordRepository.save(payment);

            if (payment.getInvoiceId() != null) {
                invoiceRepository.findById(payment.getInvoiceId()).ifPresent(inv -> {
                    double currentPaid = inv.getAmountPaid() != null ? inv.getAmountPaid() : 0.0;
                    double refundAmount = payment.getAmount() != null ? payment.getAmount() : 0.0;
                    inv.setAmountPaid(Math.max(0.0, currentPaid - refundAmount));
                    if (inv.getAmountPaid() <= 0.0) {
                        inv.setStatus("PENDING");
                    } else {
                        inv.setStatus("PARTIAL");
                    }
                    invoiceRepository.save(inv);
                });
            }
            return true;
        }
        return false;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PaymentRecord> getPaymentsByInvoiceId(Long invoiceId) {
        if (invoiceId == null) {
            return Collections.emptyList();
        }
        return paymentRecordRepository.findByInvoiceId(invoiceId);
    }

    @Override
    @Transactional
    public PaymentRecord updatePaymentStatus(Long paymentId, String status) {
        PaymentRecord p = paymentRecordRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment record not found: " + paymentId));
        p.setStatus(status);
        return paymentRecordRepository.save(p);
    }

    // --- Suppliers ---
    @Override
    @Transactional(readOnly = true)
    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Supplier> getSupplierById(Long id) {
        return supplierRepository.findById(id);
    }

    @Override
    @Transactional
    public Supplier saveSupplier(Supplier supplier) {
        return supplierRepository.save(supplier);
    }

    @Override
    @Transactional
    public void deleteSupplier(Long id) {
        supplierRepository.deleteById(id);
    }

    // --- Spare Parts ---
    @Override
    @Transactional(readOnly = true)
    public List<SparePart> getAllSpareParts() {
        return sparePartRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<SparePart> getSparePartById(Long id) {
        return sparePartRepository.findById(id);
    }

    @Override
    @Transactional
    public SparePart saveSparePart(SparePart part) {
        return sparePartRepository.save(part);
    }

    @Override
    @Transactional
    public void deleteSparePart(Long id) {
        sparePartRepository.deleteById(id);
    }
}
