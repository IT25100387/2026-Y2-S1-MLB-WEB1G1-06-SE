package com.fuelstation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ServicePackageInfo {
    private String id;
    private String name;
    private String icon;
    private String category;
    private Double estimatedCost;
    private String estimatedDuration;
    private String shortDescription;
    private List<String> highlights;
    private boolean popular;
}
