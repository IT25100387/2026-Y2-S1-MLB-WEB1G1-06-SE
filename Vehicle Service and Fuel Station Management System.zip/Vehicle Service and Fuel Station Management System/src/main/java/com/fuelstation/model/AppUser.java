package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class AppUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String role; // Admin, Manager, Cashier, Mechanic, Customer
    private String status; // Active, Deactivated

    // Extended Profile & Customer Account fields
    private String phoneNumber;
    private String address;
    private String city;
    private Integer loyaltyPoints;
    private String membershipTier; // Standard, Silver, Gold, Platinum
    private Boolean emailNotifications;
    private Boolean smsNotifications;
    
    // Password Reset
    private String resetToken;
    private java.time.LocalDateTime resetTokenExpiry;

    private java.time.LocalDateTime createdAt;

    @jakarta.persistence.PrePersist
    public void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = java.time.LocalDateTime.now();
        }
        if (this.status == null || this.status.isBlank()) {
            this.status = "Active";
        }
    }

    public int getEffectiveLoyaltyPoints() {
        return loyaltyPoints != null ? loyaltyPoints : 0;
    }

    public String getEffectiveTier() {
        return (membershipTier != null && !membershipTier.isBlank()) ? membershipTier : "Gold Member";
    }
}
