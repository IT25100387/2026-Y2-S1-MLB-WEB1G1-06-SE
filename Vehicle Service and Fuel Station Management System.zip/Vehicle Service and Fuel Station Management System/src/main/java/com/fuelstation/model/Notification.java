package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title;
    private String message;
    private String type; // e.g., Booking, Alert, Report
    private String status; // Unread, Read
    private LocalDateTime createdDate;

    // Customer Extensions
    private String recipientUsername; // null = System / Staff; or username of customer
    private String actionUrl;
    private String icon;
}
