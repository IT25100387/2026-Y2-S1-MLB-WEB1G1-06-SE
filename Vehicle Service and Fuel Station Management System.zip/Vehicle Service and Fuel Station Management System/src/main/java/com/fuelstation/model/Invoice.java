package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String invoiceNo;
    private String invoiceName;
    private String referenceNo;
    private String customerName; // "Paid Occupant"
    
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    
    private Double grossTotalAmount;
    private Double convenienceFee;
    private Double netTotal;
    
    private Double amountPaid; // To track split payments
    
    private String status; // PAID, OVERDUE, PARTIAL, PENDING

    // Customer & Service References
    private String customerUsername;
    private String licensePlate;
    private Long bookingId;
    private String notes;

    public Double getTotalAmount() {
        return netTotal != null ? netTotal : (grossTotalAmount != null ? grossTotalAmount : 0.0);
    }
}
