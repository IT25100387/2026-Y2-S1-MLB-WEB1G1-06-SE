package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class Promotion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String code; // e.g., "FUELGOLD10"
    private String title;
    private String description;
    private Double discountPercent;
    private Double discountAmount;
    private String category; // Fuel, Service, Wash, Store
    private LocalDate validUntil;
    private Boolean active;
    private String terms;
    private String badgeText;
}
