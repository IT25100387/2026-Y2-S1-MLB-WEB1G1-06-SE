package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class LoyaltyTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerUsername;
    private Integer points; // Positive for earned, negative for redeemed
    private String type; // EARNED, REDEEMED
    private String description;
    private String voucherCode; // If redeemed
    private LocalDateTime transactionDate;
}
