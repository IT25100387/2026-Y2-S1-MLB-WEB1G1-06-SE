package com.fuelstation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class PaymentRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long invoiceId;
    
    private LocalDate paymentDate;
    private String paidOccupant;
    private String paymentMethod; // Cash, Cheque, Bank Deposit, Other, Credit Card, Wallet
    private Double amount;
    
    private String customerUsername;
    private String status; // SUCCESS, PENDING, FAILED, REFUNDED
    private String transactionRef;
    private String notes;
}
