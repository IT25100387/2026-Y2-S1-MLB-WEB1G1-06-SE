import requests
import re
import sys

BASE_URL = "http://localhost:8080"

class TestReport:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.tests = []

    def log_pass(self, name, detail=""):
        self.passed += 1
        self.tests.append(("PASS", name, detail))
        print(f"  [PASS] {name}" + (f" - {detail}" if detail else ""))

    def log_fail(self, name, error=""):
        self.failed += 1
        self.tests.append(("FAIL", name, error))
        print(f"  [FAIL] {name} - ERROR: {error}")

def login(session, username, password):
    login_page = session.get(f"{BASE_URL}/login")
    if login_page.status_code != 200:
        return False, f"Login page returned {login_page.status_code}"
    
    # Extract CSRF token if present
    csrf_token = None
    m = re.search(r'name="_csrf"\s+value="([^"]+)"', login_page.text)
    if not m:
        m = re.search(r'value="([^"]+)"\s+name="_csrf"', login_page.text)
    if m:
        csrf_token = m.group(1)

    data = {"username": username, "password": password}
    if csrf_token:
        data["_csrf"] = csrf_token

    resp = session.post(f"{BASE_URL}/login", data=data, allow_redirects=False)
    if resp.status_code in (302, 303):
        redirect_to = resp.headers.get("Location", "")
        if "error" in redirect_to:
            return False, f"Login failed for {username}: redirected to {redirect_to}"
        return True, f"Logged in as {username} (redirect: {redirect_to})"
    return False, f"Unexpected response code {resp.status_code}"

def get_csrf(session, url):
    resp = session.get(url)
    m = re.search(r'name="_csrf"\s+value="([^"]+)"', resp.text)
    if not m:
        m = re.search(r'value="([^"]+)"\s+name="_csrf"', resp.text)
    return m.group(1) if m else None

def run_e2e():
    report = TestReport()
    print("==================================================================")
    print("      FUELCORE MASTER E2E VERIFICATION TEST SUITE                 ")
    print("==================================================================")

    # -------------------------------------------------------------------------
    # SUITE 1: PUBLIC PAGES & AUTHENTICATION
    # -------------------------------------------------------------------------
    print("\n--- SUITE 1: Public Pages & Security ---")
    s_anon = requests.Session()
    for path, expected_text in [
        ("/login", "FuelCore"),
        ("/signup", "Create"),
        ("/forgot-password", "Reset"),
    ]:
        resp = s_anon.get(f"{BASE_URL}{path}")
        if resp.status_code == 200 and expected_text.lower() in resp.text.lower():
            report.log_pass(f"Public route {path}", f"200 OK, found '{expected_text}'")
        else:
            report.log_fail(f"Public route {path}", f"status={resp.status_code}")

    # Test invalid login
    ok, detail = login(requests.Session(), "invalid_user", "wrong_pass")
    if not ok:
        report.log_pass("Invalid login blocked", "Correctly rejected")
    else:
        report.log_fail("Invalid login allowed", detail)

    # -------------------------------------------------------------------------
    # SUITE 2: ADMIN AUTH & OPERATIONAL NOC
    # -------------------------------------------------------------------------
    print("\n--- SUITE 2: Admin Operations & Management ---")
    s_admin = requests.Session()
    ok, detail = login(s_admin, "admin", "Admin@123")
    if ok:
        report.log_pass("Admin Authentication", detail)
    else:
        report.log_fail("Admin Authentication", detail)
        return report

    # Test Admin Dashboard (Operational View)
    resp = s_admin.get(f"{BASE_URL}/")
    if resp.status_code == 200 and ("operations" in resp.text.lower() or "fuelcore" in resp.text.lower()):
        report.log_pass("Admin NOC Dashboard", "Loaded operational dashboard")
    else:
        report.log_fail("Admin NOC Dashboard", f"status={resp.status_code}")

    # Test Admin Routes
    for r in ["/users", "/customers", "/pumps", "/prices", "/inventory", "/spare-parts", "/workshop", "/invoices", "/payments", "/suppliers", "/reports", "/admin/support"]:
        resp = s_admin.get(f"{BASE_URL}{r}")
        if resp.status_code == 200:
            report.log_pass(f"Admin Page {r}", "200 OK")
        else:
            report.log_fail(f"Admin Page {r}", f"status={resp.status_code}")

    # Admin records a fuel sale for Customer 1 (WP-TEST-8899)
    import random
    csrf_admin_sale = get_csrf(s_admin, f"{BASE_URL}/sales")
    sale_data = {
        "receiptNumber": "REC-QA-" + str(random.randint(1000, 9999)),
        "transactionId": "TXN-FUEL-" + str(random.randint(1000, 9999)),
        "pumpName": "Pump 1",
        "fuelType": "Lanka Petrol 92",
        "vehicleNumber": "WP-TEST-8899",
        "customerName": "Kasun Dias",
        "customerUsername": "customer",
        "quantityLitres": "25.0",
        "unitPrice": "340.0",
        "totalAmount": "8500.0",
        "netAmount": "8500.0",
        "paymentMethod": "Credit Card",
        "paymentStatus": "Paid"
    }
    if csrf_admin_sale:
        sale_data["_csrf"] = csrf_admin_sale
    admin_sale_resp = s_admin.post(f"{BASE_URL}/sales/add", data=sale_data, allow_redirects=True)
    if admin_sale_resp.status_code == 200:
        report.log_pass("Admin POS Fuel Sale", "Recorded 25L fuel sale linked to WP-TEST-8899")
    else:
        report.log_fail("Admin POS Fuel Sale", f"status={admin_sale_resp.status_code}")

    # -------------------------------------------------------------------------
    # SUITE 3: CUSTOMER 1 PORTAL (Kasun Dias)
    # -------------------------------------------------------------------------
    print("\n--- SUITE 3: Customer 1 Portal (Kasun Dias) ---")
    s_c1 = requests.Session()
    ok, detail = login(s_c1, "customer", "customer123")
    if ok:
        report.log_pass("Customer 1 Authentication", detail)
    else:
        report.log_fail("Customer 1 Authentication", detail)
        return report

    # Check Customer Dashboard
    resp = s_c1.get(f"{BASE_URL}/")
    if resp.status_code == 200 and "my registered vehicles" in resp.text.lower():
        report.log_pass("Customer 1 Dashboard", "200 OK, correctly loaded Customer Portal")
    else:
        report.log_fail("Customer 1 Dashboard", f"status={resp.status_code}")

    # Customer Pages
    customer_pages = [
        ("/customer/profile", "Customer Profile"),
        ("/customer/vehicles", "My Garage"),
        ("/customer/services", "Service Catalogue"),
        ("/customer/book", "Book Service Slot"),
        ("/customer/appointments", "My Appointments"),
        ("/customer/service-history", "Service History"),
        ("/customer/fuel-prices", "Live Fuel Prices"),
        ("/customer/fuel-history", "Fuel Purchase History"),
        ("/customer/invoices", "My Invoices"),
        ("/customer/payments", "Payment Ledger"),
        ("/customer/notifications", "Notification Center"),
        ("/customer/offers", "Offers & Promotions"),
        ("/customer/loyalty", "Loyalty & Rewards"),
        ("/customer/support", "Help & Support Desk")
    ]

    for path, name in customer_pages:
        resp = s_c1.get(f"{BASE_URL}{path}")
        if resp.status_code == 200:
            report.log_pass(f"Customer 1: {name} ({path})", "200 OK")
        else:
            report.log_fail(f"Customer 1: {name} ({path})", f"status={resp.status_code}")

    # -------------------------------------------------------------------------
    # SUITE 4: CUSTOMER WORKFLOW ACTIONS (CRUD & TRANSACTIONAL)
    # -------------------------------------------------------------------------
    print("\n--- SUITE 4: Customer Workflow Operations ---")

    # 1. Add Vehicle to My Garage
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/vehicles")
    vehicle_data = {
        "licensePlate": "WP-TEST-8899",
        "make": "Honda",
        "model": "Civic RS",
        "manufactureYear": "2023",
        "fuelType": "Petrol 95",
        "mileage": "15400",
        "engineNumber": "L15B7-123456",
        "chassisNumber": "FC1-987654"
    }
    if csrf:
        vehicle_data["_csrf"] = csrf
    resp = s_c1.post(f"{BASE_URL}/customer/vehicles/add", data=vehicle_data, allow_redirects=True)
    if resp.status_code == 200 and "WP-TEST-8899" in resp.text:
        report.log_pass("Customer Vehicle Registration", "Successfully added WP-TEST-8899 to garage")
    else:
        report.log_fail("Customer Vehicle Registration", f"status={resp.status_code}")

    # 2. Book an Appointment
    import random
    from datetime import date, timedelta
    future_date = (date.today() + timedelta(days=random.randint(15, 180))).strftime("%Y-%m-%d")
    booking_data = {
        "licensePlate": "WP-TEST-8899",
        "serviceType": "Engine oil change",
        "serviceDate": future_date,
        "timeSlot": "04:00 PM",
        "notes": "Automated E2E QA Booking Test"
    }
    if csrf:
        booking_data["_csrf"] = csrf
    resp = s_c1.post(f"{BASE_URL}/customer/book", data=booking_data, allow_redirects=True)
    if resp.status_code == 200 and "appointments" in resp.url and "error=" not in resp.url:
        report.log_pass("Customer Service Booking", f"Successfully booked service on {future_date}")
    else:
        report.log_fail("Customer Service Booking", f"status={resp.status_code}, url={resp.url}")

    # 3. Create Support Ticket
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/support")
    ticket_data = {
        "customerName": "Kasun Dias",
        "customerEmail": "kasun@example.com",
        "customerPhone": "+94 77 123 4567",
        "category": "INQUIRY",
        "subject": "Automated QA Support Inquiry",
        "message": "Testing customer support ticket integration end-to-end."
    }
    if csrf:
        ticket_data["_csrf"] = csrf
    resp = s_c1.post(f"{BASE_URL}/customer/support/create", data=ticket_data, allow_redirects=True)
    if resp.status_code == 200 and "opened successfully" in resp.text.lower():
        report.log_pass("Customer Support Ticket Creation", "Ticket submitted and confirmation displayed")
    else:
        report.log_fail("Customer Support Ticket Creation", f"status={resp.status_code}")

    # 4. Invoices & PDF Generation
    invoices_resp = s_c1.get(f"{BASE_URL}/customer/invoices")
    m = re.search(r'/customer/invoices/(\d+)', invoices_resp.text)
    if m:
        inv_id = m.group(1)
        # View HTML invoice
        inv_view = s_c1.get(f"{BASE_URL}/customer/invoices/{inv_id}")
        if inv_view.status_code == 200 and "invoice" in inv_view.text.lower():
            report.log_pass(f"Customer Invoice View #{inv_id}", "HTML tax invoice loaded")
        else:
            report.log_fail(f"Customer Invoice View #{inv_id}", f"status={inv_view.status_code}")

        # Download PDF invoice
        pdf_resp = s_c1.get(f"{BASE_URL}/customer/invoices/{inv_id}/pdf")
        if pdf_resp.status_code == 200 and pdf_resp.headers.get("content-type") == "application/pdf" and len(pdf_resp.content) > 500:
            report.log_pass(f"Customer Invoice PDF #{inv_id}", f"PDF streamed ({len(pdf_resp.content)} bytes)")
        else:
            report.log_fail(f"Customer Invoice PDF #{inv_id}", f"status={pdf_resp.status_code}")

        # Pay Invoice
        csrf = get_csrf(s_c1, f"{BASE_URL}/customer/invoices/{inv_id}")
        pay_data = {
            "amount": "1000.00",
            "paymentMethod": "Visa / Master Online",
            "transactionRef": "TEST-CARD-TXN-999"
        }
        if csrf:
            pay_data["_csrf"] = csrf
        pay_resp = s_c1.post(f"{BASE_URL}/customer/invoices/{inv_id}/pay", data=pay_data, allow_redirects=True)
        if pay_resp.status_code == 200 and ("completed" in pay_resp.text.lower() or "paid" in pay_resp.text.lower() or "receipt" in pay_resp.text.lower()):
            report.log_pass(f"Customer Payment Settlement #{inv_id}", "Payment successfully recorded")
        else:
            report.log_fail(f"Customer Payment Settlement #{inv_id}", f"status={pay_resp.status_code}")
    else:
        report.log_pass("Customer Invoices", "No invoices currently pending for this customer")

    # 5. Fuel Purchase PDF Slip
    fuel_resp = s_c1.get(f"{BASE_URL}/customer/fuel-history")
    m_fuel = re.search(r'/customer/receipt/(\d+)/pdf', fuel_resp.text)
    if m_fuel:
        sale_id = m_fuel.group(1)
        pdf_fuel = s_c1.get(f"{BASE_URL}/customer/receipt/{sale_id}/pdf")
        if pdf_fuel.status_code == 200 and pdf_fuel.headers.get("content-type") == "application/pdf" and len(pdf_fuel.content) > 500:
            report.log_pass(f"Customer Fuel E-Receipt PDF #{sale_id}", f"PDF streamed ({len(pdf_fuel.content)} bytes)")
        else:
            report.log_fail(f"Customer Fuel E-Receipt PDF #{sale_id}", f"status={pdf_fuel.status_code}")
    else:
        report.log_pass("Customer Fuel PDF", "No fuel transactions found to download")

    # -------------------------------------------------------------------------
    # SUITE 5: MULTI-TENANT RBAC ISOLATION (Customer 1 vs Customer 2)
    # -------------------------------------------------------------------------
    print("\n--- SUITE 5: Multi-Tenant RBAC & Security Isolation ---")
    s_c2 = requests.Session()
    ok, detail = login(s_c2, "customer2", "customer123")
    if ok:
        report.log_pass("Customer 2 Authentication", detail)
    else:
        report.log_fail("Customer 2 Authentication", detail)

    # Customer 2's garage should NOT contain Customer 1's vehicle WP-TEST-8899
    resp_c2_garage = s_c2.get(f"{BASE_URL}/customer/vehicles")
    if "WP-TEST-8899" not in resp_c2_garage.text:
        report.log_pass("Garage Vehicle Isolation", "Customer 2 cannot see Customer 1's vehicles")
    else:
        report.log_fail("Garage Vehicle Isolation", "LEAK DETECTED: Customer 2 sees Customer 1's vehicle!")

    # Customer 1 cannot access Admin User Management
    resp_c1_admin = s_c1.get(f"{BASE_URL}/users")
    if resp_c1_admin.status_code in (403, 302):
        report.log_pass("RBAC Security: Admin /users blocked for Customer", f"Status {resp_c1_admin.status_code}")
    else:
        report.log_fail("RBAC Security: Admin /users", f"Allowed unexpectedly with status {resp_c1_admin.status_code}")

    # Customer 1 cannot access Admin Customers Directory
    resp_c1_custdir = s_c1.get(f"{BASE_URL}/customers")
    if resp_c1_custdir.status_code in (403, 302):
        report.log_pass("RBAC Security: /customers blocked for Customer", f"Status {resp_c1_custdir.status_code}")
    else:
        report.log_fail("RBAC Security: /customers", f"Allowed unexpectedly with status {resp_c1_custdir.status_code}")

    print("\n==================================================================")
    print(f"  TEST SUMMARY: {report.passed} PASSED, {report.failed} FAILED")
    print("==================================================================")
    return report

if __name__ == "__main__":
    report = run_e2e()
    if report.failed > 0:
        sys.exit(1)
    else:
        sys.exit(0)
