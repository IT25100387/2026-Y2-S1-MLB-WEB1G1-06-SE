import sys
import requests
import re
import time

BASE_URL = "http://localhost:8080"

def wait_for_server(timeout=45):
    print("Waiting for server to become healthy...")
    start = time.time()
    while time.time() - start < timeout:
        try:
            r = requests.get(f"{BASE_URL}/login", timeout=2)
            if r.status_code == 200:
                print(f"Server is up and responding (took {time.time() - start:.1f}s)")
                return True
        except Exception:
            pass
        time.sleep(2)
    print("Timed out waiting for server.")
    return False

def run_tests():
    if not wait_for_server():
        print("ERROR: Server not ready on port 8080.")
        sys.exit(1)

    print("\n=======================================================")
    print("  TEST 1: Customer Login Authentication")
    print("=======================================================")
    session = requests.Session()
    
    # Fetch login page to capture any CSRF token if needed
    login_page = session.get(f"{BASE_URL}/login")
    assert login_page.status_code == 200, f"Expected 200 on /login, got {login_page.status_code}"
    
    login_resp = session.post(f"{BASE_URL}/login", data={
        "username": "customer",
        "password": "customer123"
    }, allow_redirects=True)
    
    assert login_resp.status_code == 200, f"Expected 200 after customer login, got {login_resp.status_code}"
    assert "Customer Portal" in login_resp.text or "Welcome" in login_resp.text, "Customer portal hero not found after login"
    print("SUCCESS: Customer logged in and reached Customer Portal dashboard.")

    print("\n=======================================================")
    print("  TEST 2: Verify Customer Dashboard Navigation Elements")
    print("=======================================================")
    dash_html = login_resp.text
    assert "userProfileDropdownWrap" in dash_html, "Dropdown wrap 'userProfileDropdownWrap' not found in navbar"
    assert "userProfileDropdownMenu" in dash_html, "Dropdown menu 'userProfileDropdownMenu' not found in navbar"
    assert "View Profile" in dash_html, "'View Profile' link not found in navbar dropdown"
    assert "Change Password" in dash_html, "'Change Password' link not found in navbar dropdown"
    assert "My Account &amp; Profile" in dash_html or "My Account & Profile" in dash_html, "Profile card not found in dashboard"
    assert "/customer/profile" in dash_html, "Link to /customer/profile not found in dashboard"
    assert "/customer/change-password" in dash_html, "Link to /customer/change-password not found in dashboard"
    print("SUCCESS: All top-right dropdown, hero, and dashboard profile navigation elements are present.")

    print("\n=======================================================")
    print("  TEST 3: View Customer Profile Page")
    print("=======================================================")
    prof_resp = session.get(f"{BASE_URL}/customer/profile")
    assert prof_resp.status_code == 200, f"Expected 200 on /customer/profile, got {prof_resp.status_code}"
    prof_html = prof_resp.text
    assert "Account Profile &amp; Security" in prof_html or "Account Profile & Security" in prof_html, "Profile header missing"
    assert 'name="fullName"' in prof_html, "fullName field missing"
    assert 'name="email"' in prof_html, "email field missing"
    assert 'name="phoneNumber"' in prof_html, "phoneNumber field missing"
    assert 'name="address"' in prof_html, "address field missing"
    assert 'name="city"' in prof_html, "city field missing"
    assert 'id="edit-profile"' in prof_html, "edit-profile anchor id missing"
    assert "/customer/change-password" in prof_html, "Link to dedicated change-password missing on profile page"
    print("SUCCESS: View Profile page loaded with complete personal details and anchors.")

    print("\n=======================================================")
    print("  TEST 4: Update Personal Profile Details")
    print("=======================================================")
    update_data = {
        "fullName": "Kasun Dias Verified",
        "email": "kasun.dias@fuelcore.lk",
        "phoneNumber": "+94 77 123 9999",
        "address": "No. 77, Galle Road",
        "city": "Colombo 03"
    }
    update_resp = session.post(f"{BASE_URL}/customer/profile/update", data=update_data, allow_redirects=True)
    assert update_resp.status_code == 200, f"Expected 200 after update, got {update_resp.status_code}"
    assert "Profile information updated successfully!" in update_resp.text, "Success message not found after profile update"
    assert "Kasun Dias Verified" in update_resp.text, "Updated name not reflected on profile page"
    assert "kasun.dias@fuelcore.lk" in update_resp.text, "Updated email not reflected on profile page"
    assert "+94 77 123 9999" in update_resp.text, "Updated phone not reflected on profile page"
    print("SUCCESS: Customer personal details (name, email, phone, address, city) updated and persisted.")

    print("\n=======================================================")
    print("  TEST 5: View Dedicated Change Password Page")
    print("=======================================================")
    cp_resp = session.get(f"{BASE_URL}/customer/change-password")
    assert cp_resp.status_code == 200, f"Expected 200 on /customer/change-password, got {cp_resp.status_code}"
    cp_html = cp_resp.text
    assert "Change Account Password" in cp_html, "Change password header missing"
    assert 'name="currentPassword"' in cp_html, "currentPassword input missing"
    assert 'name="newPassword"' in cp_html, "newPassword input missing"
    assert 'name="confirmPassword"' in cp_html, "confirmPassword input missing"
    assert "BCrypt" in cp_html, "BCrypt protection information missing"
    print("SUCCESS: Dedicated Change Password page loaded with secure fields and guidance.")

    print("\n=======================================================")
    print("  TEST 6: Password Change Verification & Validation")
    print("=======================================================")
    # 6A: Wrong current password
    bad_curr = session.post(f"{BASE_URL}/customer/change-password", data={
        "currentPassword": "wrongPassword@999",
        "newPassword": "newSecretPassword123",
        "confirmPassword": "newSecretPassword123"
    }, allow_redirects=True)
    assert bad_curr.status_code == 200
    assert "Current password verification failed" in bad_curr.text, "Failed to reject invalid current password"
    print("  6A: Invalid current password was properly rejected by BCrypt check.")

    # 6B: Password confirmation mismatch
    mismatch = session.post(f"{BASE_URL}/customer/change-password", data={
        "currentPassword": "customer123",
        "newPassword": "newSecretPassword123",
        "confirmPassword": "mismatchPassword456"
    }, allow_redirects=True)
    assert mismatch.status_code == 200
    assert "do not match" in mismatch.text, "Failed to reject password mismatch"
    print("  6B: Mismatched new password and confirmation was properly rejected.")

    # 6C: Password length too short
    too_short = session.post(f"{BASE_URL}/customer/change-password", data={
        "currentPassword": "customer123",
        "newPassword": "123",
        "confirmPassword": "123"
    }, allow_redirects=True)
    assert too_short.status_code == 200
    assert "at least 6 characters" in too_short.text, "Failed to reject short password"
    print("  6C: Short password (<6 chars) was properly rejected.")

    # 6D: Valid password update
    new_pw = "CustomerUpdated@2026"
    valid_cp = session.post(f"{BASE_URL}/customer/change-password", data={
        "currentPassword": "customer123",
        "newPassword": new_pw,
        "confirmPassword": new_pw
    }, allow_redirects=True)
    assert valid_cp.status_code == 200
    assert "Security credentials updated" in valid_cp.text or "password_changed" in valid_cp.url, "Success banner not found after valid password change"
    print(f"  6D: Password successfully updated to '{new_pw}'.")

    print("\n=======================================================")
    print("  TEST 7: Verify Authentication with Updated Password")
    print("=======================================================")
    # Try old password - MUST FAIL
    s_old = requests.Session()
    fail_login = s_old.post(f"{BASE_URL}/login", data={
        "username": "customer",
        "password": "customer123"
    }, allow_redirects=True)
    assert "Invalid username or password" in fail_login.text or "error=true" in fail_login.url, "Old password still worked!"
    print("SUCCESS: Old password 'customer123' is no longer accepted.")

    # Try new password - MUST SUCCEED
    s_new = requests.Session()
    success_login = s_new.post(f"{BASE_URL}/login", data={
        "username": "customer",
        "password": new_pw
    }, allow_redirects=True)
    assert success_login.status_code == 200
    assert "Customer Portal" in success_login.text or "Welcome" in success_login.text, "Failed to login with new password"
    print("SUCCESS: New password successfully authenticated via BCrypt!")

    print("\n=======================================================")
    print("  TEST 8: Reset Password Back to Default (customer123)")
    print("=======================================================")
    restore_pw = s_new.post(f"{BASE_URL}/customer/change-password", data={
        "currentPassword": new_pw,
        "newPassword": "customer123",
        "confirmPassword": "customer123"
    }, allow_redirects=True)
    assert restore_pw.status_code == 200
    assert "Security credentials updated" in restore_pw.text or "password_changed" in restore_pw.url

    # Verify default login works again
    s_restored = requests.Session()
    check_restored = s_restored.post(f"{BASE_URL}/login", data={
        "username": "customer",
        "password": "customer123"
    }, allow_redirects=True)
    assert check_restored.status_code == 200 and ("Customer Portal" in check_restored.text or "Welcome" in check_restored.text)
    print("SUCCESS: Password restored to 'customer123' and verified.")

    print("\n=======================================================")
    print("  TEST 9: Admin Regression Test")
    print("=======================================================")
    s_admin = requests.Session()
    admin_login = s_admin.post(f"{BASE_URL}/login", data={
        "username": "admin",
        "password": "Admin@123"
    }, allow_redirects=True)
    assert admin_login.status_code == 200
    assert "ADMIN" in admin_login.text.upper() or "Forecourt" in admin_login.text or "Management" in admin_login.text
    print("SUCCESS: Admin login (admin / Admin@123) functional without regression.")

    print("\n=======================================================")
    print("  ALL TESTS PASSED SUCCESSFULLY!")
    print("=======================================================")

if __name__ == "__main__":
    run_tests()
