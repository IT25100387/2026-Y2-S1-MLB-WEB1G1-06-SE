import requests
import re
import sys
import time
from datetime import datetime

BASE_URL = "http://localhost:8080"

class TestReport:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []

    def check(self, name, condition, details=""):
        if condition:
            self.passed += 1
            print(f"  [PASS] {name}")
        else:
            self.failed += 1
            msg = f"  [FAIL] {name}"
            if details:
                msg += f" - {details}"
            print(msg)
            self.errors.append(name + (f": {details}" if details else ""))

report = TestReport()

def login(session, username, password):
    res = session.post(f"{BASE_URL}/login", data={'username': username, 'password': password}, allow_redirects=True)
    return res

print("=" * 80)
print("FUELCORE - MODULE IT25100399 COMPREHENSIVE VERIFICATION SUITE")
print("User & Customer Management + Authentication + Login + RBAC + Password Management")
print("=" * 80)

# ==============================================================================
# 1. AUTHENTICATION & LOGIN AUDIT ACROSS ALL 5 ROLES
# ==============================================================================
print("\n--- 1. AUTHENTICATION AUDIT (ALL 5 ROLES) ---")

roles_credentials = [
    ("ADMIN", "admin", "Admin@123"),
    ("MANAGER", "manager", "manager123"),
    ("CASHIER", "cashier", "cashier123"),
    ("MECHANIC", "mechanic", "mechanic123"),
    ("CUSTOMER", "customer", "customer123"),
]

for role_name, uname, pwd in roles_credentials:
    s = requests.Session()
    r = login(s, uname, pwd)
    report.check(f"Authentication success for role {role_name} ('{uname}')", r.status_code == 200 and "Invalid username" not in r.text)

# Invalid password handling
s_bad = requests.Session()
r_bad = s_bad.post(f"{BASE_URL}/login", data={'username': 'admin', 'password': 'WrongPassword123'}, allow_redirects=False)
report.check("Invalid password rejected with redirect to login?error", r_bad.status_code == 302 and "error" in r_bad.headers.get("Location", ""))

# Logout
s_logout = requests.Session()
login(s_logout, "customer", "customer123")
r_logout = s_logout.post(f"{BASE_URL}/logout", allow_redirects=False)
report.check("Logout terminates session and redirects to login?logout", r_logout.status_code == 302 and "logout" in r_logout.headers.get("Location", ""))

# ==============================================================================
# 2. USER MANAGEMENT CRUD (ADMIN WORKFLOW)
# ==============================================================================
print("\n--- 2. COMPLETE USER MANAGEMENT CRUD (ADMIN) ---")
s_admin = requests.Session()
login(s_admin, "admin", "Admin@123")

# 2.1 CREATE: Admin provisions a new Customer user
ts = int(time.time())
test_cust_uname = f"test_cust_{ts % 10000}"
test_cust_email = f"{test_cust_uname}@fuelstation.lk"

r_add_cust = s_admin.post(f"{BASE_URL}/users/add", data={
    'fullName': f"Test Customer {ts % 10000}",
    'username': test_cust_uname,
    'password': "Password@123",
    'email': test_cust_email,
    'phoneNumber': "+94 77 999 8888",
    'address': "123 Galle Road, Colombo 04",
    'role': "Customer",
    'status': "Active"
}, allow_redirects=True)
report.check("Admin: Create Customer Account (POST /users/add)", r_add_cust.status_code == 200)

# Verify newly created customer can log in immediately
s_new_cust = requests.Session()
r_new_login = login(s_new_cust, test_cust_uname, "Password@123")
report.check(f"New customer '{test_cust_uname}' can authenticate immediately", r_new_login.status_code == 200 and "Invalid" not in r_new_login.text)

# 2.2 CREATE: Admin provisions a new Staff user (Mechanic)
test_staff_uname = f"test_mech_{ts % 10000}"
test_staff_email = f"{test_staff_uname}@fuelstation.lk"

r_add_staff = s_admin.post(f"{BASE_URL}/users/new", data={
    'fullName': f"Master Tech {ts % 10000}",
    'username': test_staff_uname,
    'password': "Password@123",
    'email': test_staff_email,
    'phoneNumber': "+94 71 888 7777",
    'address': "Workshop Bay Diagnostic Center",
    'role': "Mechanic",
    'status': "Active"
}, allow_redirects=True)
report.check("Admin: Create Staff Account (Mechanic) (POST /users/new)", r_add_staff.status_code == 200)

# 2.3 READ: View User Directory & extract user ID
r_users_list = s_admin.get(f"{BASE_URL}/users")
report.check("Admin: View User Directory (/users)", r_users_list.status_code == 200)
report.check("Admin: Created Customer listed in User Directory", test_cust_uname in r_users_list.text)
report.check("Admin: Created Staff listed in User Directory", test_staff_uname in r_users_list.text)

# Extract customer ID
cust_id = None
m_card = re.search(r'data-username="' + re.escape(test_cust_uname.lower()) + r'".*?href="/users/view/(\d+)"', r_users_list.text, re.DOTALL)
if m_card:
    cust_id = m_card.group(1)
if not cust_id:
    for row in re.split(r'</tr\s*>', r_users_list.text, flags=re.IGNORECASE):
        if test_cust_uname in row:
            m = re.search(r'/users/(?:view|edit)/(\d+)', row)
            if m:
                cust_id = m.group(1)
                break

report.check("Admin: Located User ID for newly created user", cust_id is not None, f"User ID: {cust_id}")

if cust_id:
    # 2.4 READ: View User Details Page
    r_details = s_admin.get(f"{BASE_URL}/users/view/{cust_id}")
    report.check("Admin: Access User Details Page (/users/view/{id})", r_details.status_code == 200)
    report.check("User Details displays Full Name", f"Test Customer {ts % 10000}" in r_details.text)
    report.check("User Details displays Username", test_cust_uname in r_details.text)
    report.check("User Details displays Email", test_cust_email in r_details.text)
    report.check("User Details displays Phone Number", "+94 77 999 8888" in r_details.text)
    report.check("User Details displays Address", "123 Galle Road" in r_details.text)
    report.check("User Details displays Role", "Customer" in r_details.text)
    report.check("User Details displays Status", "Active" in r_details.text)
    report.check("User Details displays Created Date", "2026-" in r_details.text)

    # 2.5 UPDATE: Admin accesses Edit User form
    r_edit_page = s_admin.get(f"{BASE_URL}/users/edit/{cust_id}")
    report.check("Admin: Access Edit User Page (/users/edit/{id})", r_edit_page.status_code == 200)

    # Admin updates user details
    updated_name = f"Kasun Dias Updated {ts % 1000}"
    updated_phone = "+94 77 111 2233"
    updated_address = "99 Marine Drive, Colombo 03"
    r_save_edit = s_admin.post(f"{BASE_URL}/users/edit/{cust_id}", data={
        'fullName': updated_name,
        'email': test_cust_email,
        'phoneNumber': updated_phone,
        'address': updated_address,
        'city': "Colombo",
        'role': "Customer",
        'status': "Active"
    }, allow_redirects=True)
    report.check("Admin: Save User Changes (POST /users/edit/{id})", r_save_edit.status_code == 200)

    # Verify updates in database & view
    r_details_upd = s_admin.get(f"{BASE_URL}/users/view/{cust_id}")
    report.check("Verified updated Full Name in database", updated_name in r_details_upd.text)
    report.check("Verified updated Phone Number in database", updated_phone in r_details_upd.text)
    report.check("Verified updated Address in database", updated_address in r_details_upd.text)

    # 2.6 DELETE / SOFT DELETE: Deactivate user
    r_deact = s_admin.post(f"{BASE_URL}/users/deactivate/{cust_id}", allow_redirects=True)
    report.check("Admin: Safe Soft Delete / Deactivate User (POST /users/deactivate/{id})", r_deact.status_code == 200)

    # Verify status changed to Deactivated
    r_details_deact = s_admin.get(f"{BASE_URL}/users/view/{cust_id}")
    report.check("User status reflected as Deactivated", "Deactivated" in r_details_deact.text)

    # 2.7 REACTIVATE: Reactivate user
    r_react = s_admin.post(f"{BASE_URL}/users/reactivate/{cust_id}", allow_redirects=True)
    report.check("Admin: Reactivate User (POST /users/reactivate/{id})", r_react.status_code == 200)

    r_details_react = s_admin.get(f"{BASE_URL}/users/view/{cust_id}")
    report.check("User status reflected as Active after reactivation", "Active" in r_details_react.text)

# Root protection check: verify admin cannot be deactivated
r_root_deact = s_admin.post(f"{BASE_URL}/users/delete/1", allow_redirects=True)
r_admin_check = s_admin.get(f"{BASE_URL}/users/view/1")
report.check("Root admin account is protected from deactivation", "Active" in r_admin_check.text)

# ==============================================================================
# 3. SEARCH AND FILTER FUNCTIONALITY
# ==============================================================================
print("\n--- 3. USER SEARCH AND FILTER ---")

# Search by Name
r_s_name = s_admin.get(f"{BASE_URL}/users", params={'search': 'Kasun Dias'})
report.check("Search by Name returns matching results", "Kasun Dias" in r_s_name.text)

# Search by Username
r_s_user = s_admin.get(f"{BASE_URL}/users", params={'search': 'customer'})
report.check("Search by Username returns matching results", "customer" in r_s_user.text)

# Search by Email
r_s_email = s_admin.get(f"{BASE_URL}/users", params={'search': test_cust_email})
report.check("Search by Email returns matching results", test_cust_email in r_s_email.text)

# Filter by Role: Mechanic
r_f_mech = s_admin.get(f"{BASE_URL}/users", params={'role': 'Mechanic'})
mech_roles = set(re.findall(r'data-role="([^"]+)"', r_f_mech.text))
report.check("Filter by Role (Mechanic)", r_f_mech.status_code == 200 and mech_roles == {"Mechanic"})

# Filter by Status: Active
r_f_act = s_admin.get(f"{BASE_URL}/users", params={'status': 'Active'})
report.check("Filter by Status (Active)", r_f_act.status_code == 200)

# ==============================================================================
# 4. CUSTOMER ACCOUNT MANAGEMENT (SELF-SERVICE)
# ==============================================================================
print("\n--- 4. CUSTOMER ACCOUNT MANAGEMENT ---")
s_cust = requests.Session()
login(s_cust, "customer", "customer123")

# 4.1 View Profile
r_prof = s_cust.get(f"{BASE_URL}/customer/profile")
report.check("Customer: View Profile (/customer/profile)", r_prof.status_code == 200)
report.check("Profile displays legal name", "Kasun Dias" in r_prof.text)
report.check("Profile displays username", "customer" in r_prof.text)

# 4.2 Edit Profile
r_upd_prof = s_cust.post(f"{BASE_URL}/customer/profile/update", data={
    'fullName': "Kasun Dias",
    'email': "kasun.dias@gmail.com",
    'phoneNumber': "+94 77 123 4567",
    'address': "45/2 Galle Road",
    'city': "Colombo 03"
}, allow_redirects=True)
report.check("Customer: Edit Profile (POST /customer/profile/update)", r_upd_prof.status_code == 200)

# 4.3 Notification & Communication Settings
r_settings_view = s_cust.get(f"{BASE_URL}/customer/settings")
report.check("Customer: View Account Settings (/customer/settings)", r_settings_view.status_code == 200)
report.check("Settings includes Email Notification toggle", "Email Notifications" in r_settings_view.text)
report.check("Settings includes SMS Alerts toggle", "SMS" in r_settings_view.text)

# Update notification preferences
r_settings_save = s_cust.post(f"{BASE_URL}/customer/settings/update", data={
    'emailNotifications': 'true',
    'smsNotifications': 'true'
}, allow_redirects=True)
report.check("Customer: Save Notification Settings (POST /customer/settings/update)", r_settings_save.status_code == 200)

# ==============================================================================
# 5. PASSWORD MANAGEMENT (BCRYPT VERIFICATION)
# ==============================================================================
print("\n--- 5. PASSWORD MANAGEMENT ---")

# 5.1 Test password change page
r_pwd_page = s_cust.get(f"{BASE_URL}/customer/change-password")
report.check("Customer: Access Change Password Page", r_pwd_page.status_code == 200)

# 5.2 Invalid current password rejected
r_pwd_bad = s_cust.post(f"{BASE_URL}/customer/change-password", data={
    'currentPassword': 'WrongCurrentPassword',
    'newPassword': 'NewSecurePass@123',
    'confirmPassword': 'NewSecurePass@123'
}, allow_redirects=True)
report.check("Password Change: Invalid current password rejected", "error=invalid_current" in r_pwd_bad.url or "failed" in r_pwd_bad.text.lower())

# 5.3 Password mismatch rejected
r_pwd_mis = s_cust.post(f"{BASE_URL}/customer/change-password", data={
    'currentPassword': 'customer123',
    'newPassword': 'NewSecurePass@123',
    'confirmPassword': 'DifferentPassword@123'
}, allow_redirects=True)
report.check("Password Change: Password mismatch rejected", "error=mismatch" in r_pwd_mis.url or "not match" in r_pwd_mis.text.lower())

# 5.4 Successful password change (use user_1864 or temporary test customer so customer123 remains constant)
s_temp = requests.Session()
temp_user = f"pw_user_{ts % 10000}"
s_admin.post(f"{BASE_URL}/users/add", data={
    'fullName': "Password Test User",
    'username': temp_user,
    'password': "InitialPass@123",
    'email': f"{temp_user}@test.lk",
    'phoneNumber': "+94 77 000 1111",
    'address': "Kandy Road",
    'role': "Customer",
    'status': "Active"
})

login(s_temp, temp_user, "InitialPass@123")
r_pwd_ok = s_temp.post(f"{BASE_URL}/customer/change-password", data={
    'currentPassword': 'InitialPass@123',
    'newPassword': 'UpdatedSecret@999',
    'confirmPassword': 'UpdatedSecret@999'
}, allow_redirects=True)
report.check("Password Change: Valid password successfully updated", "success=password_changed" in r_pwd_ok.url or "updated" in r_pwd_ok.text.lower())

# Authenticate with NEW BCrypt password
s_new_auth = requests.Session()
r_auth_new = login(s_new_auth, temp_user, "UpdatedSecret@999")
report.check("Authentication with newly updated BCrypt password succeeds", r_auth_new.status_code == 200 and "Invalid" not in r_auth_new.text)

# Old password must now fail
s_old_auth = requests.Session()
r_auth_old = login(s_old_auth, temp_user, "InitialPass@123")
report.check("Authentication with old password fails after change", "error" in r_auth_old.url or "Invalid" in r_auth_old.text)

# ==============================================================================
# 6. FORGOT PASSWORD & RESET RECOVERY SYSTEM
# ==============================================================================
print("\n--- 6. FORGOT PASSWORD SYSTEM ---")

# 6.1 Access forgot password page
s_anon = requests.Session()
r_forgot_page = s_anon.get(f"{BASE_URL}/forgot-password")
report.check("Access Forgot Password Page (/forgot-password)", r_forgot_page.status_code == 200)

# 6.2 Submit username/email for recovery
r_token_req = s_anon.post(f"{BASE_URL}/forgot-password", data={'identifier': temp_user}, allow_redirects=True)
report.check("Submit identifier generates reset authorization token", r_token_req.status_code == 200 and "reset-password" in r_token_req.text)

# Extract reset token from response
m_tok = re.search(r'token=([a-f0-9\-]+)', r_token_req.text)
reset_token = m_tok.group(1) if m_tok else None
report.check("Reset token extracted from recovery flow", reset_token is not None, f"Token: {reset_token}")

if reset_token:
    # 6.3 Access reset password page
    r_reset_page = s_anon.get(f"{BASE_URL}/reset-password", params={'token': reset_token})
    report.check("Access Reset Password page with valid token", r_reset_page.status_code == 200 and "Set New Password" in r_reset_page.text)

    # 6.4 Save new encrypted password
    r_reset_sub = s_anon.post(f"{BASE_URL}/reset-password", data={
        'token': reset_token,
        'newPassword': 'BrandNewPass@777',
        'confirmPassword': 'BrandNewPass@777'
    }, allow_redirects=True)
    report.check("Reset Password: Save new encrypted password", "resetSuccess" in r_reset_sub.url or "reset successfully" in r_reset_sub.text.lower())

    # 6.5 Authenticate with recovered password
    s_reset_auth = requests.Session()
    r_reset_login = login(s_reset_auth, temp_user, "BrandNewPass@777")
    report.check("Authentication with recovered password succeeds", r_reset_login.status_code == 200 and "Invalid" not in r_reset_login.text)

# ==============================================================================
# 7. ROLE BASED ACCESS CONTROL & DATA ISOLATION
# ==============================================================================
print("\n--- 7. ROLE BASED ACCESS CONTROL (RBAC) ---")

# Customer cannot access Admin User Management
r_c_users = s_cust.get(f"{BASE_URL}/users", allow_redirects=False)
report.check("RBAC: Customer denied from /users (User Management)", r_c_users.status_code in [403, 302])

# Customer cannot access Customer Directory
r_c_custs = s_cust.get(f"{BASE_URL}/customers", allow_redirects=False)
report.check("RBAC: Customer denied from /customers (Customer Directory)", r_c_custs.status_code in [403, 302])

# Customer cannot access Audit Logs
r_c_audit = s_cust.get(f"{BASE_URL}/audit-logs", allow_redirects=False)
report.check("RBAC: Customer denied from /audit-logs", r_c_audit.status_code in [403, 302])

# Customer cannot access Reports
r_c_rep = s_cust.get(f"{BASE_URL}/reports", allow_redirects=False)
report.check("RBAC: Customer denied from /reports", r_c_rep.status_code in [403, 302])

# Customer A cannot modify Customer B's vehicle or appointments
s_cust2 = requests.Session()
login(s_cust2, "customer2", "customer123")
r_steal_veh = s_cust2.post(f"{BASE_URL}/customer/vehicles/update/1", data={
    'licensePlate': 'WP CAB-4521',
    'brand': 'Hacked',
    'model': 'Vehicle'
}, allow_redirects=False)
report.check("Customer Data Security: Customer 2 cannot update Customer 1 vehicle", r_steal_veh.status_code in [302, 403])

# ==============================================================================
# 8. AUDIT LOGGING OF USER ACTIVITIES
# ==============================================================================
print("\n--- 8. AUDIT LOGGING OF USER ACTIVITIES ---")
r_audit_page = s_admin.get(f"{BASE_URL}/audit-logs")
report.check("Admin: Access Security Audit Logs (/audit-logs)", r_audit_page.status_code == 200)

report.check("Audit Log records User Created action", "USER_CREATED" in r_audit_page.text or "Created" in r_audit_page.text)
report.check("Audit Log records User Updated action", "USER_UPDATED" in r_audit_page.text or "Updated" in r_audit_page.text)
report.check("Audit Log records User Deactivated action", "USER_DEACTIVATED" in r_audit_page.text or "Deactivated" in r_audit_page.text)
report.check("Audit Log records User Reactivated action", "USER_REACTIVATED" in r_audit_page.text or "Reactivated" in r_audit_page.text)
report.check("Audit Log records Password Changed action", "PASSWORD_CHANGED" in r_audit_page.text or "PASSWORD" in r_audit_page.text)
report.check("Audit Log records Login Attempts", "LOGIN_SUCCESS" in r_audit_page.text or "USER_LOGIN" in r_audit_page.text)

print("\n" + "=" * 80)
print(f"IT25100399 MODULE VERIFICATION SUMMARY: {report.passed} PASSED, {report.failed} FAILED")
print("=" * 80)

if report.failed > 0:
    print("\nFAILURES:")
    for err in report.errors:
        print(f" - {err}")
    sys.exit(1)
else:
    print("\nALL MODULE IT25100399 SPECIFICATIONS & ENTERPRISE AUDIT CHECKS PASSED 100%!")
    sys.exit(0)
