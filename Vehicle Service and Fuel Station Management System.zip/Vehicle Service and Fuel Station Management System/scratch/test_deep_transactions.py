import requests
import re
import sys

BASE_URL = "http://localhost:8080"

def login(session, username, password):
    login_page = session.get(f"{BASE_URL}/login")
    csrf_token = None
    m = re.search(r'name="_csrf"\s+value="([^"]+)"', login_page.text)
    if not m:
        m = re.search(r'value="([^"]+)"\s+name="_csrf"', login_page.text)
    if m:
        csrf_token = m.group(1)

    data = {"username": username, "password": password}
    if csrf_token:
        data["_csrf"] = csrf_token

    resp = session.post(f"{BASE_URL}/login", data=data, allow_redirects=False)
    return resp.status_code in (302, 303) and "error" not in resp.headers.get("Location", "")

def get_csrf(session, url):
    resp = session.get(url)
    m = re.search(r'name="_csrf"\s+value="([^"]+)"', resp.text)
    if not m:
        m = re.search(r'value="([^"]+)"\s+name="_csrf"', resp.text)
    return m.group(1) if m else None

def run_deep_test():
    print("==================================================================")
    print("      DEEP LIFECYCLE, PDF STREAMING & WORKFLOW TEST               ")
    print("==================================================================")

    s_c1 = requests.Session()
    assert login(s_c1, "customer", "customer123"), "Customer login failed"

    # Step 1: Ensure customer has vehicle WP-LUBE-001
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/vehicles")
    veh_data = {
        "licensePlate": "WP-LUBE-001",
        "make": "Toyota",
        "model": "Aqua",
        "manufactureYear": "2021",
        "fuelType": "Petrol 92",
        "mileage": "32000",
        "engineNumber": "1NZ-FXE-9988",
        "chassisNumber": "NHP10-5544"
    }
    if csrf:
        veh_data["_csrf"] = csrf
    s_c1.post(f"{BASE_URL}/customer/vehicles/add", data=veh_data, allow_redirects=True)
    print("  [PASS] Vehicle WP-LUBE-001 ensured in Customer Garage")

    # Step 2: Book "Engine oil change" which creates an advance invoice automatically
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/book")
    bkg_data = {
        "licensePlate": "WP-LUBE-001",
        "serviceType": "Engine oil change",
        "serviceDate": "2026-09-28",
        "timeSlot": "02:00 PM",
        "notes": "Full synthetic oil change request"
    }
    if csrf:
        bkg_data["_csrf"] = csrf
    bkg_resp = s_c1.post(f"{BASE_URL}/customer/book", data=bkg_data, allow_redirects=True)
    assert bkg_resp.status_code == 200, f"Booking request failed: {bkg_resp.status_code}"
    print("  [PASS] Booked 'Engine oil change' (Advance Invoice Triggered)")

    # Step 3: Verify Invoice in Customer Invoices List
    inv_resp = s_c1.get(f"{BASE_URL}/customer/invoices")
    assert inv_resp.status_code == 200, "Failed to load /customer/invoices"
    inv_ids = re.findall(r'/customer/invoices/(\d+)', inv_resp.text)
    assert len(inv_ids) > 0, "No invoices found for customer after booking"
    inv_id = inv_ids[0]
    print(f"  [PASS] Invoice #{inv_id} found on Customer Invoices ledger")

    # Step 4: Verify HTML Tax Invoice View
    v_resp = s_c1.get(f"{BASE_URL}/customer/invoices/{inv_id}")
    assert v_resp.status_code == 200, f"HTML invoice view failed: {v_resp.status_code}"
    assert "invoice" in v_resp.text.lower(), "Invoice text missing from invoice view"
    assert "WP-LUBE-001" in v_resp.text or "Engine oil change" in v_resp.text
    print(f"  [PASS] Tax Invoice Statement #{inv_id} HTML view verified")

    # Step 5: Verify OpenPDF Stream Generation
    pdf_resp = s_c1.get(f"{BASE_URL}/customer/invoices/{inv_id}/pdf")
    assert pdf_resp.status_code == 200, f"PDF download returned {pdf_resp.status_code}"
    assert pdf_resp.headers.get("content-type") == "application/pdf", f"Invalid content type: {pdf_resp.headers.get('content-type')}"
    assert len(pdf_resp.content) > 1000, f"PDF byte stream too small: {len(pdf_resp.content)}"
    print(f"  [PASS] OpenPDF streaming successfully generated: {len(pdf_resp.content)} bytes (Content-Type: application/pdf)")

    # Step 6: Customer Settle Payment on Invoice
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/invoices/{inv_id}")
    pay_data = {
        "amount": "6500.00",
        "paymentMethod": "Visa / Master Online",
        "transactionRef": f"VISA-TXN-{inv_id}-SUCCESS"
    }
    if csrf:
        pay_data["_csrf"] = csrf
    pay_resp = s_c1.post(f"{BASE_URL}/customer/invoices/{inv_id}/pay", data=pay_data, allow_redirects=True)
    assert pay_resp.status_code == 200, f"Payment settlement failed: {pay_resp.status_code}"
    assert "settled" in pay_resp.text.lower() or "paid" in pay_resp.text.lower()
    print(f"  [PASS] Invoice #{inv_id} settled online via card payment")

    # Step 7: Customer Payment Ledger contains the settlement
    payments_resp = s_c1.get(f"{BASE_URL}/customer/payments")
    assert payments_resp.status_code == 200
    assert f"VISA-TXN-{inv_id}-SUCCESS" in payments_resp.text or "6,500.00" in payments_resp.text
    print("  [PASS] Customer Payment Ledger verified with new settlement record")

    # Step 8: Support Ticket & Admin Resolution Loop
    csrf = get_csrf(s_c1, f"{BASE_URL}/customer/support")
    tkt_data = {
        "customerName": "Kasun Dias",
        "customerEmail": "kasun@example.com",
        "customerPhone": "+94 77 123 4567",
        "category": "INQUIRY",
        "subject": "Oil Filter Brand Inquiry",
        "message": "Do you stock genuine Toyota OEM filters for Aqua hybrid models?"
    }
    if csrf:
        tkt_data["_csrf"] = csrf
    tkt_resp = s_c1.post(f"{BASE_URL}/customer/support/create", data=tkt_data, allow_redirects=True)
    assert tkt_resp.status_code == 200
    print("  [PASS] Support ticket submitted by customer")

    # Admin checks tickets & replies
    s_admin = requests.Session()
    assert login(s_admin, "admin", "Admin@123")
    admin_desk = s_admin.get(f"{BASE_URL}/admin/support")
    ticket_ids = re.findall(r'data-id="(\d+)"', admin_desk.text)
    assert len(ticket_ids) > 0, "Admin support desk has no tickets"
    target_tid = ticket_ids[0]

    csrf = get_csrf(s_admin, f"{BASE_URL}/admin/support")
    reply_data = {
        "adminReply": "Yes, we have 100% genuine Denso/Toyota OEM filters in stock at our Colombo-03 facility.",
        "status": "RESOLVED"
    }
    if csrf:
        reply_data["_csrf"] = csrf
    reply_resp = s_admin.post(f"{BASE_URL}/admin/support/reply/{target_tid}", data=reply_data, allow_redirects=True)
    assert reply_resp.status_code == 200
    assert "resolved" in reply_resp.text.lower()
    print(f"  [PASS] Admin replied and marked Ticket #{target_tid} as RESOLVED")

    # Step 9: Customer Notifications Center has the resolution notification
    notifs_resp = s_c1.get(f"{BASE_URL}/customer/notifications")
    assert notifs_resp.status_code == 200
    assert "resolved" in notifs_resp.text.lower() or "support" in notifs_resp.text.lower()
    print("  [PASS] Notification center alerted customer regarding resolved ticket")

    # Step 10: Loyalty Points & Reward Voucher Redemption
    loyalty_resp = s_c1.get(f"{BASE_URL}/customer/loyalty")
    assert loyalty_resp.status_code == 200
    r_ids = re.findall(r'/customer/loyalty/redeem/(\d+)', loyalty_resp.text)
    if r_ids:
        r_id = r_ids[0]
        csrf = get_csrf(s_c1, f"{BASE_URL}/customer/loyalty")
        red_data = {}
        if csrf:
            red_data["_csrf"] = csrf
        red_resp = s_c1.post(f"{BASE_URL}/customer/loyalty/redeem/{r_id}", data=red_data, allow_redirects=True)
        assert red_resp.status_code == 200
        print(f"  [PASS] Loyalty voucher #{r_id} redemption workflow validated")

    print("\n==================================================================")
    print("   COMPLETE 10-STEP LIFECYCLE & TRANSACTION TEST PASSED 100%!    ")
    print("==================================================================")

if __name__ == "__main__":
    run_deep_test()
