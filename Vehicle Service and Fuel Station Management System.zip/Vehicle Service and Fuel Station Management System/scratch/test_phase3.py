import requests
import re
import sys
from bs4 import BeautifulSoup

BASE_URL = "http://localhost:8080"

def get_csrf(session, url):
    resp = session.get(url)
    soup = BeautifulSoup(resp.text, 'html.parser')
    csrf = soup.find('input', {'name': '_csrf'})
    return csrf['value'] if csrf else None

def login(username, password):
    s = requests.Session()
    login_page = s.get(f"{BASE_URL}/login")
    if login_page.status_code != 200:
        raise Exception(f"Failed to load login page: {login_page.status_code}")
    
    soup = BeautifulSoup(login_page.text, 'html.parser')
    csrf = soup.find('input', {'name': '_csrf'})
    data = {'username': username, 'password': password}
    if csrf:
        data['_csrf'] = csrf['value']
    
    resp = s.post(f"{BASE_URL}/login", data=data, allow_redirects=True)
    if "Invalid username or password" in resp.text:
        raise Exception(f"Login failed for user {username}")
    return s

def run_tests():
    print("==================================================")
    print("     FUELCORE PHASE 3 QA VERIFICATION SUITE       ")
    print("==================================================")
    
    # 1. TEST ADMIN ACCESS (CONTINUITY)
    print("\n[TEST 1] Admin Authentication & Workshop Access...")
    admin_session = login("admin", "Admin@123")
    r = admin_session.get(f"{BASE_URL}/")
    assert r.status_code == 200, "Admin root access failed"
    assert "Live Forecourt Fuel Metering" in r.text or "Active Job Cards" in r.text or "Total Revenue" in r.text, "Admin operational dashboard missing"
    
    r_workshop = admin_session.get(f"{BASE_URL}/workshop")
    assert r_workshop.status_code == 200, "Admin workshop access failed"
    assert "Workshop Operations" in r_workshop.text, "Admin workshop jobs table missing"
    
    r_bookings = admin_session.get(f"{BASE_URL}/bookings")
    assert r_bookings.status_code == 200, "Admin bookings view failed"
    assert "Master Service Bookings Registry" in r_bookings.text or "Service Bookings" in r_bookings.text
    print("  -> PASS: Admin full operational access & workshop continuity verified.")

    # 2. TEST CUSTOMER 1 LOGIN & REDIRECTION
    print("\n[TEST 2] Customer 1 Authentication & Redirection...")
    c1_session = login("customer", "customer123")
    r = c1_session.get(f"{BASE_URL}/")
    assert r.status_code == 200
    assert "My Garage" in r.text or "My Registered Vehicles" in r.text, "Customer dashboard missing customer branding"
    assert "Live Forecourt Fuel Metering" not in r.text, "Admin NOC leaked to customer!"
    
    # Verify /bookings redirects customer to /customer/appointments
    r_bkg = c1_session.get(f"{BASE_URL}/bookings", allow_redirects=False)
    assert r_bkg.status_code == 302 and "/customer/appointments" in r_bkg.headers.get("Location", ""), "Customer /bookings did not redirect to /customer/appointments"
    print("  -> PASS: Customer dashboard isolated and /bookings correctly redirects to /customer/appointments.")

    # 3. TEST SERVICE CATALOGUE (8 PACKAGES)
    print("\n[TEST 3] Customer Service Catalogue Inspection...")
    r_cat = c1_session.get(f"{BASE_URL}/customer/services")
    assert r_cat.status_code == 200, "Service catalogue failed to load"
    soup_cat = BeautifulSoup(r_cat.text, 'html.parser')
    
    expected_packages = [
        "Engine oil change",
        "Full service",
        "Brake inspection",
        "Battery check",
        "Tire service",
        "Vehicle wash",
        "AC service",
        "General repairs"
    ]
    for pkg in expected_packages:
        assert pkg.lower() in r_cat.text.lower(), f"Service package missing from catalogue: {pkg}"
    print(f"  -> PASS: All 8 required service packages present with transparent pricing & durations.")

    # Ensure Customer 1 has at least 1 vehicle in My Garage
    print("\n[TEST 4] Ensuring Customer 1 Garage Vehicle...")
    r_garage = c1_session.get(f"{BASE_URL}/customer/vehicles")
    soup_garage = BeautifulSoup(r_garage.text, 'html.parser')
    plate = "WP-PH3-1111"
    if plate not in r_garage.text:
        # Add vehicle
        v_data = {
            'licensePlate': plate,
            'make': 'Honda',
            'model': 'Civic Turbo',
            'manufactureYear': 2022,
            'fuelType': 'Petrol 95 Euro 4',
            'mileage': 25000,
            'engineNumber': 'L15B7-8910',
            'chassisNumber': 'FC1-778899',
            'ownerContact': '0771234567'
        }
        r_add_v = c1_session.post(f"{BASE_URL}/customer/vehicles/add", data=v_data, allow_redirects=True)
        assert r_add_v.status_code == 200
    print(f"  -> PASS: Customer 1 vehicle verified: {plate}")

    # 4. TEST SERVICE BOOKING WIZARD
    print("\n[TEST 5] Testing 5-Step Service Booking Workflow...")
    r_book_page = c1_session.get(f"{BASE_URL}/customer/book?serviceType=Full+service&plate={plate}")
    assert r_book_page.status_code == 200
    assert "5-Step Service Reservation" in r_book_page.text
    
    import datetime
    import time
    days_ahead = 20 + (int(time.time()) % 20)
    booking_date = (datetime.date.today() + datetime.timedelta(days=days_ahead)).strftime("%Y-%m-%d")
    booking_slot = "10:00 AM"
    booking_data = {
        'licensePlate': plate,
        'serviceType': 'Full service',
        'serviceDate': booking_date,
        'timeSlot': booking_slot,
        'problemDescription': '10,000 km routine service, slight squeak in front brakes.'
    }
    r_book = c1_session.post(f"{BASE_URL}/customer/book", data=booking_data, allow_redirects=True)
    assert r_book.status_code == 200
    assert "Service appointment scheduled successfully" in r_book.text or "Active & Upcoming Bookings" in r_book.text
    print("  -> PASS: Service booking created successfully.")

    # Find the created booking ID
    soup_app = BeautifulSoup(r_book.text, 'html.parser')
    booking_id = None
    for tr in soup_app.find_all('tr'):
        if plate in tr.text and booking_slot in tr.text and booking_date in tr.text:
            ref_match = re.search(r'#BKG-(\d+)', tr.text)
            if ref_match:
                booking_id = int(ref_match.group(1))
                break
    
    if not booking_id:
        # Fallback to last booking ref for plate
        for tr in soup_app.find_all('tr'):
            if plate in tr.text:
                ref_match = re.search(r'#BKG-(\d+)', tr.text)
                if ref_match:
                    booking_id = int(ref_match.group(1))
    
    assert booking_id is not None, "Could not find created booking ID in appointments list!"
    print(f"  -> PASS: Identified created booking ID: #{booking_id}")

    # 5. TEST DOUBLE-BOOKING PREVENTING
    print("\n[TEST 6] Testing Double-Booking Prevention on Same Slot & Date...")
    r_dup = c1_session.post(f"{BASE_URL}/customer/book", data=booking_data, allow_redirects=True)
    assert "already booked" in r_dup.text or "slot_taken" in r_dup.url, "Double-booking was not prevented!"
    print("  -> PASS: Slot conflict correctly caught and prevented.")

    # 6. TEST LIVE SERVICE TRACKER (READ-ONLY 5-STAGE VIEW)
    print(f"\n[TEST 7] Testing Live Service Tracker for Booking #{booking_id}...")
    r_track = c1_session.get(f"{BASE_URL}/customer/track/{booking_id}")
    assert r_track.status_code == 200
    assert "Live Workshop Service Progress Tracker" in r_track.text
    assert "1. Received" in r_track.text
    assert "2. Inspection" in r_track.text
    assert "3. Service Bay" in r_track.text
    assert "4. Quality Check" in r_track.text
    assert "5. Ready" in r_track.text
    assert plate in r_track.text
    # Ensure no admin/internal workshop buttons exist on tracking page
    assert "Create Job Card" not in r_track.text
    assert "Delete Booking" not in r_track.text
    print("  -> PASS: 5-stage live tracker rendered with read-only customer security.")

    # 7. TEST RESCHEDULING
    print(f"\n[TEST 8] Testing Reschedule Workflow for Booking #{booking_id}...")
    new_date = (datetime.date.today() + datetime.timedelta(days=days_ahead + 15)).strftime("%Y-%m-%d")
    new_slot = "03:00 PM"
    reschedule_data = {
        'serviceDate': new_date,
        'timeSlot': new_slot
    }
    r_resched = c1_session.post(f"{BASE_URL}/customer/appointments/reschedule/{booking_id}", data=reschedule_data, allow_redirects=True)
    assert r_resched.status_code == 200
    assert "Appointment has been successfully rescheduled" in r_resched.text
    print(f"  -> PASS: Appointment successfully rescheduled to {new_date} at {new_slot}.")

    # 8. TEST CROSS-CUSTOMER ISOLATION (SECURITY)
    print("\n[TEST 9] Testing Multi-Tenant Ownership Isolation (Customer 2)...")
    c2_session = login("customer2", "customer123")
    
    # Customer 2 attempts to view Customer 1's tracker
    r_c2_track = c2_session.get(f"{BASE_URL}/customer/track/{booking_id}", allow_redirects=False)
    assert r_c2_track.status_code == 302 and "access_denied" in r_c2_track.headers.get("Location", ""), "Customer 2 was NOT blocked from Customer 1's live tracker!"
    
    # Customer 2 attempts to reschedule Customer 1's booking
    r_c2_resched = c2_session.post(f"{BASE_URL}/customer/appointments/reschedule/{booking_id}", data={'serviceDate': '2026-10-20', 'timeSlot': '09:00 AM'}, allow_redirects=False)
    assert r_c2_resched.status_code == 302 and "access_denied" in r_c2_resched.headers.get("Location", ""), "Customer 2 was NOT blocked from rescheduling Customer 1's booking!"

    # Customer 2 attempts to cancel Customer 1's booking
    r_c2_cancel = c2_session.post(f"{BASE_URL}/customer/appointments/cancel/{booking_id}", allow_redirects=False)
    assert r_c2_cancel.status_code == 302 and "access_denied" in r_c2_cancel.headers.get("Location", ""), "Customer 2 was NOT blocked from cancelling Customer 1's booking!"

    # Customer 2 attempts to book with Customer 1's vehicle
    c2_hijack = {
        'licensePlate': plate,
        'serviceType': 'Engine oil change',
        'serviceDate': '2026-10-25',
        'timeSlot': '11:00 AM',
        'problemDescription': 'Attempting unauthorized vehicle booking'
    }
    r_c2_book = c2_session.post(f"{BASE_URL}/customer/book", data=c2_hijack, allow_redirects=False)
    assert r_c2_book.status_code == 302 and "unauthorized_vehicle" in r_c2_book.headers.get("Location", ""), "Customer 2 was allowed to book with someone else's vehicle!"
    print("  -> PASS: 100% strict cross-customer isolation enforced across tracking, rescheduling, cancelling, and booking.")

    # 9. TEST CANCELLATION & SLOT RELEASE
    print(f"\n[TEST 10] Testing Appointment Cancellation for Booking #{booking_id}...")
    r_cancel = c1_session.post(f"{BASE_URL}/customer/appointments/cancel/{booking_id}", allow_redirects=True)
    assert r_cancel.status_code == 200
    assert "Service appointment was cancelled" in r_cancel.text
    
    # Now that slot (2026-10-16 02:00 PM) is cancelled, verify it is immediately available again
    test_free_slot = {
        'licensePlate': plate,
        'serviceType': 'Engine oil change',
        'serviceDate': new_date,
        'timeSlot': new_slot,
        'problemDescription': 'Testing freed slot re-booking'
    }
    r_rebook = c1_session.post(f"{BASE_URL}/customer/book", data=test_free_slot, allow_redirects=True)
    assert r_rebook.status_code == 200
    assert "already booked" not in r_rebook.text
    print("  -> PASS: Cancellation successful and previously booked time slot immediately released.")

    print("\n==================================================")
    print("  ALL PHASE 3 REQUIREMENTS VERIFIED SUCCESSFULLY! ")
    print("==================================================")

if __name__ == "__main__":
    run_tests()
