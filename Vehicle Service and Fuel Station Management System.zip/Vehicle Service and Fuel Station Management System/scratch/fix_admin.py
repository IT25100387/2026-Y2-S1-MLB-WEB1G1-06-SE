import pyodbc

try:
    conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=fuelstationdb;Trusted_Connection=yes;')
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, status FROM app_user WHERE username='admin'")
    rows = cur.fetchall()
    print("Current admin record:", rows)
    cur.execute("UPDATE app_user SET status='Active' WHERE username='admin'")
    conn.commit()
    print("Admin status successfully updated to Active.")
except Exception as e:
    print("Error:", e)
